#!/usr/bin/env python3
"""Diagnostic build: blank the 5x8 Tiny glyph table while retaining its descriptor."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261005-1725-main-percent-v2.hex')
OUT = Path('work/port-20261005-1739-tiny-test-v1.hex')
SOURCE_SHA256 = 'd3f75a27db5b45b9896510e14e1cdd6ea9cab93da08c29cb137cb81551ae1989'
TINY = 0x0800F9D4
TINY_BYTES = 12 * 16
DESCRIPTOR = 0x0800FD10

def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 0xFF:
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError('record outside firmware image')
            image[off:off+n] = data
        elif typ == 1:
            break
    return image

def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 0xFF])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])

if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
    raise ValueError('main-percent-v2 SHA-256 mismatch')
image = decode(SOURCE)
original = bytes(image)
off = TINY - FLASH
desc_off = DESCRIPTOR - FLASH
assert image[desc_off:desc_off+8] == bytes.fromhex('05 08 00 00 D4 F9 00 08')
image[off:off+TINY_BYTES] = bytes(TINY_BYTES)
OUT.write_text(encode(image))
check = decode(OUT)
assert check == image, 'Intel HEX round-trip mismatch'
for line in OUT.read_text().splitlines():
    assert not (sum(bytes.fromhex(line[1:])) & 0xFF), 'bad Intel HEX checksum'
assert check[off:off+TINY_BYTES] == bytes(TINY_BYTES)
assert check[desc_off:desc_off+8] == original[desc_off:desc_off+8], 'descriptor changed'
changed = {i for i, (a, b) in enumerate(zip(original, check)) if a != b}
assert changed <= set(range(off, off+TINY_BYTES)), f'unexpected changes: {sorted(changed-set(range(off,off+TINY_BYTES)))}'
print('output:', OUT)
print('blanked 5x8 Tiny glyph table:', hex(TINY), 'through', hex(TINY+TINY_BYTES-1))
print('kept descriptor at', hex(DESCRIPTOR), 'and all other bytes unchanged')
print('changed bytes:', len(changed))
print('sha256:', hashlib.sha256(OUT.read_bytes()).hexdigest())
