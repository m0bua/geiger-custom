#!/usr/bin/env python3
"""Enlarge only the active ink of the shared Medium 11x18 digits by 2x."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261005-1751-energy-stats-5x8-v2.hex')
OUT = Path('work/port-20261005-2135-medium-font-v1.hex')
SOURCE_SHA256 = 'caa155761d4a3fa452ce0cb4f992f79e5698d1a38c3cb89c3caab9915f8febd1'
MEDIUM_TABLE = 0x0800F0A8
DIGITS = MEDIUM_TABLE + (0x30 - 0x20) * 36


def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 255:
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError('record outside image')
            image[off:off+n] = data
        elif typ == 1:
            break
    return image


def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])


def unpack(data):
    rows = []
    for y in range(18):
        word = int.from_bytes(data[y*2:y*2+2], 'little')
        rows.append([bool(word & (0x8000 >> x)) for x in range(11)])
    return rows


def scale_2x(rows):
    ys = [y for y, row in enumerate(rows) if any(row)]
    xs = [x for x in range(11) if any(rows[y][x] for y in ys)]
    out = [[False] * 11 for _ in range(18)]
    if not xs or not ys:
        return out
    x0, x1 = min(xs), max(xs) + 1
    y0, y1 = min(ys), max(ys) + 1
    src = [row[x0:x1] for row in rows[y0:y1]]
    sw, sh = len(src[0]), len(src)
    dw, dh = min(11, sw * 2), min(18, sh * 2)
    scaled = [[src[min(sh-1, int((y+0.5)*sh/dh))][min(sw-1, int((x+0.5)*sw/dw))]
               for x in range(dw)] for y in range(dh)]
    xo, yo = (11-dw)//2, (18-dh)//2
    for y, row in enumerate(scaled):
        out[yo+y][xo:xo+dw] = row
    return out


def pack(rows):
    out = bytearray()
    for row in rows:
        word = sum(bool(pixel) << (15-x) for x, pixel in enumerate(row))
        out.extend(word.to_bytes(2, 'little'))
    return bytes(out)


if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
    raise ValueError('accepted base SHA mismatch')
image = decode(SOURCE)
original = bytes(image)
assert image[0x0800FCF8-FLASH:0x0800FD00-FLASH] == bytes.fromhex('0B 12 00 00 A8 F0 00 08')
assert image[0x0800FD00-FLASH:0x0800FD08-FLASH] == bytes.fromhex('0B 12 00 00 A8 F0 00 08')
for i in range(10):
    off = DIGITS-FLASH+i*36
    image[off:off+36] = pack(scale_2x(unpack(image[off:off+36])))

OUT.write_text(encode(image))
check = decode(OUT)
assert check == image
for line in OUT.read_text().splitlines():
    assert not (sum(bytes.fromhex(line[1:])) & 255)
changed = {i for i, (a, b) in enumerate(zip(original, check)) if a != b}
allowed = set(range(DIGITS-FLASH, DIGITS-FLASH+10*36))
assert changed and changed <= allowed, 'changes escaped the ten Medium digit glyphs'
for code in [*range(0x20, 0x30), *range(0x3A, 0x48)]:
    off = MEDIUM_TABLE-FLASH+(code-0x20)*36
    assert check[off:off+36] == original[off:off+36], f'protected Medium glyph {code:#x} changed'
assert check[0x0800F648-FLASH:0x0800FC00-FLASH] == original[0x0800F648-FLASH:0x0800FC00-FLASH]
assert check[0x0800FCF8-FLASH:0x0800FD18-FLASH] == original[0x0800FCF8-FLASH:0x0800FD18-FLASH]
print('output:', OUT)
print('Scaled only Medium 11x18 digit glyphs 0-9 by 2x inside their existing cells.')
print('Small/Tiny fonts, punctuation, letters, descriptors, and all other bytes unchanged.')
print('changed bytes:', len(changed), 'sha256:', hashlib.sha256(OUT.read_bytes()).hexdigest())
