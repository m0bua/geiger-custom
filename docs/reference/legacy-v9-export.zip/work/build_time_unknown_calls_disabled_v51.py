#!/usr/bin/env python3
"""Disable only the two unresolved TIME-menu raster calls from approved v25."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('upload/03-port-20261005-0850-settings-icon-sun-v25.hex')
OUT = Path('work/port-20261005-1350-time-unknown-calls-disabled-v51.hex')
SOURCE_SHA256 = '6b68bc567c0504c9f3d6977ca0bf65227ec5b932fd3530903093fd0c68df7e6f'
NOP = bytes.fromhex('00 BF 00 BF')
DISABLE = {
    0x0800D2B2: 'unknown raster call in time-menu selection 2',
    0x0800DA68: 'unknown raster call in time-menu selection 5',
}
PRESERVE = 0x0800B6A4  # confirmed units icon in SETTINGS

def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 0xFF:
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError('record outside firmware image')
            image[off:off+n] = data
        elif typ == 1:
            break
    return image

def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 0xFF, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 0xFF])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])

def is_thumb_bl(image, addr):
    off = addr - FLASH
    a = int.from_bytes(image[off:off+2], 'little')
    b = int.from_bytes(image[off+2:off+4], 'little')
    return (a & 0xF800) == 0xF000 and (b & 0xD000) == 0xD000

if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
    raise ValueError('v25 SHA-256 mismatch')
image = decode(SOURCE)
original = bytes(image)
assert is_thumb_bl(image, PRESERVE), 'units icon call missing from v25'
for addr in DISABLE:
    assert is_thumb_bl(image, addr), f'not a Thumb BL: {addr:#x}'
    off = addr - FLASH
    image[off:off+4] = NOP
OUT.write_text(encode(image))
check = decode(OUT)
assert check == image, 'Intel HEX round-trip mismatch'
for line in OUT.read_text().splitlines():
    assert not (sum(bytes.fromhex(line[1:])) & 0xFF), 'bad Intel HEX checksum'
assert check[PRESERVE-FLASH:PRESERVE-FLASH+4] == original[PRESERVE-FLASH:PRESERVE-FLASH+4]
for addr in DISABLE:
    assert check[addr-FLASH:addr-FLASH+4] == NOP
changed = {i for i,(a,b) in enumerate(zip(original,check)) if a != b}
allowed = set()
for addr in DISABLE:
    allowed.update(range(addr-FLASH, addr-FLASH+4))
assert changed <= allowed, f'unexpected changes: {sorted(changed-allowed)}'
print('output:', OUT)
print('disabled:', ', '.join(hex(x) for x in DISABLE))
print('preserved:', hex(PRESERVE))
print('changed bytes:', len(changed))
print('reusable instruction slots:', len(DISABLE)*4, 'bytes')
print('sha256:', hashlib.sha256(OUT.read_bytes()).hexdigest())
