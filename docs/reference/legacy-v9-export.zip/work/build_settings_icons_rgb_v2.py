from pathlib import Path
import hashlib

FLASH=0x08000000
SOURCE=Path('work/port-20261006-0756-settings-icons-v1.hex')
OUT=Path('work/port-20261006-0808-settings-icons-rgb-v2.hex')
BASE_SHA='8b26ccc205ed6e8d634f4c45d642fb7d9c571c5d4e35eee9ac32f3ba8f427a7c'
CALLS=(0x0800B9EE,0x0800BA0A,0x0800BA26)
FILL=0x0800F91E

def decode(path):
    im=bytearray([255])*0x10000; upper=0
    for line in path.read_text().splitlines():
        if not line.startswith(':'): continue
        r=bytes.fromhex(line[1:]); n,h,lo,t=r[:4]; d=r[4:-1]
        if len(d)!=n or sum(r)&255: raise ValueError('bad Intel HEX')
        if t==4: upper=int.from_bytes(d,'big')<<16
        elif t==0:
            o=upper+(h<<8)+lo-FLASH; im[o:o+n]=d
        elif t==1: break
    return im

def encode(im):
    out=[':020000040800F2']
    for o in range(0,len(im),16):
        d=bytes(im[o:o+16]).ljust(16,b'\xff'); b=bytes((16,o>>8,o&255,0))+d
        out.append(':'+ (b+bytes(((-sum(b))&255,))).hex().upper())
    return '\n'.join(out+[':00000001FF',''])

def thumb_bl(at,target):
    delta=target-(at+4)
    if delta&1 or not -(1<<24)<=delta<(1<<24): raise ValueError('BL range')
    imm=delta&0x1ffffff; s=(imm>>24)&1
    i1=(imm>>23)&1; i2=(imm>>22)&1; j1=1^((i1)^s); j2=1^((i2)^s)
    return ((0xf000|(s<<10)|((imm>>12)&0x3ff)).to_bytes(2,'little')+
            (0xd000|(j1<<13)|(j2<<11)|((imm>>1)&0x7ff)).to_bytes(2,'little'))

assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=decode(SOURCE); before=bytes(im)
for addr in CALLS:
    o=addr-FLASH
    assert im[o:o+4]==bytes.fromhex('FF F7 F9 FA' if addr==CALLS[0] else 'FF F7 EB FA' if addr==CALLS[1] else 'FF F7 DD FA')
    im[o:o+4]=thumb_bl(addr,FILL)
OUT.write_text(encode(im)); check=decode(OUT)
assert check==im and all(sum(bytes.fromhex(x[1:]))&255==0 for x in OUT.read_text().splitlines())
changed={i for i,(a,b) in enumerate(zip(before,check)) if a!=b}
assert len(changed)==12,changed
print(OUT)
print('sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
print('direct raster calls B9EE/BA0A/BA26 -> fill helper F91E')
