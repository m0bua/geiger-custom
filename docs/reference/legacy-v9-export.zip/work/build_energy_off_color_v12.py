from pathlib import Path
import hashlib
FLASH=0x08000000
SOURCE=Path('work/port-20261005-1751-energy-stats-5x8-v2.hex')
OUT=Path('work/port-20261006-0015-energy-off-color-v12.hex')
BASE_SHA='caa155761d4a3fa452ce0cb4f992f79e5698d1a38c3cb89c3caab9915f8febd1'
DRAW=0x08008E48; FILL=0x08008ECC; HELPER=0x0800F118
# Five untested text-render calls, each marked in a distinct color.
CANDIDATES=[
 (0x0800CF38,0, 'red',       31,11,0),
 (0x0800CF5C,25,'green',    126, 4,0),
 (0x0800D158,50,'blue',      31, 0,0),
 (0x0800D17E,75,'pink',      31,11,31),
 (0x0800D1A4,100,'dark-yellow',255,8,224),
]
def decode(path):
 im=bytearray([255])*0x10000; upper=0
 for line in path.read_text().splitlines():
  if not line.startswith(':'):continue
  rec=bytes.fromhex(line[1:]);n,hi,lo,typ=rec[:4];data=rec[4:-1]
  if n!=len(data) or sum(rec)&255:raise ValueError('invalid HEX record')
  if typ==4:upper=int.from_bytes(data,'big')<<16
  elif typ==0:
   off=upper+(hi<<8)+lo-FLASH
   if off<0 or off+n>len(im):raise ValueError('record out of range')
   im[off:off+n]=data
  elif typ==1:break
 return im
def encode(im):
 out=[':020000040800F2']
 for off in range(0,len(im),16):
  rec=bytes([16,off>>8,off&255,0])+im[off:off+16]
  out.append(':'+(rec+bytes([(-sum(rec))&255])).hex().upper())
 return '\n'.join(out+[':00000001FF',''])
def bl(addr,target):
 d=target-(addr+4)
 if d&1 or not -(1<<24)<=d<(1<<24):raise ValueError('BL range')
 x=d&0x1ffffff;s=x>>24&1;i1=x>>23&1;i2=x>>22&1;j1=1^(i1^s);j2=1^(i2^s)
 return (0xf000|(s<<10)|((x>>12)&1023)).to_bytes(2,'little')+(0xd000|(j1<<13)|(j2<<11)|((x>>1)&2047)).to_bytes(2,'little')
def target(im,addr):
 i=addr-FLASH;h1=int.from_bytes(im[i:i+2],'little');h2=int.from_bytes(im[i+2:i+4],'little')
 if h1&0xf800!=0xf000 or h2&0xd000!=0xd000:return None
 s=h1>>10&1;j1=h2>>13&1;j2=h2>>11&1;i1=1^(j1^s);i2=1^(j2^s)
 v=(s<<24)|(i1<<23)|(i2<<22)|((h1&1023)<<12)|((h2&2047)<<1)
 if s:v-=1<<25
 return (addr+4+v)&0xffffffff
def movs(reg,val):return (0x2000|(reg<<8)|val).to_bytes(2,'little')
def lsl_r2(shift):return (0x0012|(shift<<6)).to_bytes(2,'little')
def adds_r2(val):return (0x3200|val).to_bytes(2,'little')
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=decode(SOURCE); original=bytes(im)
assert im[HELPER-FLASH:HELPER-FLASH+32]==bytes([255])*32
# Uses caller's x in r0 and marker y=42; r2 holds RGB565 color.
helper=bytes.fromhex('00 B5 81 B0 00 92 2A 21 14 22 12 23')+bl(HELPER+12,FILL)+bytes.fromhex('01 B0 00 BD')
assert len(helper)==20
im[HELPER-FLASH:HELPER-FLASH+len(helper)]=helper
for call,x,name,base,shift,add in CANDIDATES:
 assert target(im,call)==DRAW,(hex(call),target(im,call))
 start=call-FLASH-8
 # Preserve no part of the original string-render setup: draw a marker instead.
 code=movs(0,x)+movs(2,base)
 if shift:code+=lsl_r2(shift)
 else:code+=bytes.fromhex('00 BF')
 if add:code+=adds_r2(add)
 while len(code)<8:code+=bytes.fromhex('00 BF')
 assert len(code)==8
 im[start:start+8]=code
 im[call-FLASH:call-FLASH+4]=bl(call,HELPER)
OUT.write_text(encode(im));check=decode(OUT);assert check==im
for line in OUT.read_text().splitlines():
 if line.startswith(':') and sum(bytes.fromhex(line[1:]))&255:raise ValueError('bad record checksum')
changed={i for i,(a,b) in enumerate(zip(original,check)) if a!=b}
allowed=set(range(HELPER-FLASH,HELPER-FLASH+len(helper)))
for call,*_ in CANDIDATES:allowed.update(range(call-FLASH-8,call-FLASH+4))
assert changed<=allowed,sorted(changed-allowed)
print('output',OUT,'changed_bytes',len(changed),'sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
for a,x,name,base,shift,add in CANDIDATES:print(hex(a),name,'marker',(x,42),'color',hex((base<<shift)+add))
