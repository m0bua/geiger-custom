#!/usr/bin/env python3
"""Route Energy/Statistics numeric strings through a Tiny-to-Small adapter."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261005-1725-main-percent-v2.hex')
OUT = Path('work/port-20261005-1751-energy-stats-font-v1.hex')
SOURCE_SHA256 = 'd3f75a27db5b45b9896510e14e1cdd6ea9cab93da08c29cb137cb81551ae1989'
WRAPPER = 0x0800F9D4  # Former Tiny glyph table; now only these sites use it.
DRAW_STRING = 0x08008E48
SMALL_DESCRIPTOR = 0x0800FD08
CALLS = [
    0x08009538, 0x08009594,                         # ENERGY
    0x0800C258, 0x0800C2AA, 0x0800C30E,
    0x0800C370, 0x0800C3BE,                         # STATISTICS screen 1
    0x0800C986, 0x0800CA40,                         # STATISTICS screen 2
]


def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 0xFF:
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError('record outside firmware image')
            image[off:off+n] = data
        elif typ == 1:
            break
    return image


def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])


def thumb_bl(src, dst):
    delta = dst - (src + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError('Thumb BL destination out of range')
    imm = delta & 0x1FFFFFF
    s = (imm >> 24) & 1
    i1, i2 = (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = (1 ^ (i1 ^ s)), (1 ^ (i2 ^ s))
    h1 = 0xF000 | (s << 10) | ((imm >> 12) & 0x3FF)
    h2 = 0xD000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7FF)
    return h1.to_bytes(2, 'little') + h2.to_bytes(2, 'little')


if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
    raise ValueError('accepted main-percent-v2 SHA-256 mismatch')
image = decode(SOURCE)
original = bytes(image)

# Small 7x10 byte map: period 0x2E, digits 0x30..0x39, percent 0x43.
# Tiny used 0x20 for period, 0x21 for percent and 0x22..0x2B for digits.
# Translate the writable numeric string in place, restore all call arguments,
# replace only the font descriptor and tail-enter the existing renderer. The
# original LR and caller stack are left intact, including stack-passed args.
wrapper = bytes.fromhex(
    '0F B5'       # push {r0-r3,lr}
    '01 78'       # loop: ldrb r1,[r0]
    '00 29'       # cmp r1,#0
    '0F D0'       # beq done
    '20 29'       # cmp r1,#0x20
    '07 D0'       # beq period
    '21 29'       # cmp r1,#0x21
    '07 D0'       # beq percent
    '22 29'       # cmp r1,#0x22
    '07 D3'       # blo advance
    '2B 29'       # cmp r1,#0x2B
    '05 D8'       # bhi advance
    '0E 31'       # adds r1,#14 (Tiny digits -> Small ASCII digits)
    '02 E0'       # b store
    '2E 21'       # period: movs r1,#0x2E
    '00 E0'       # b store
    '43 21'       # percent: movs r1,#0x43
    '01 70'       # store: strb r1,[r0]
    '40 1C'       # advance: adds r0,#1
    'EC E7'       # b loop
    '0F BC'       # done: pop {r0-r3}; LR remains on stack
    '02 4B'       # ldr r3, [pc,#8] -> renderer thumb address
    '00 93'       # str r3,[sp] -> replace stacked return with renderer
    '02 4B'       # ldr r3, [pc,#8] -> Small descriptor
    '00 BD'       # pop {pc}; tail-enter renderer with original LR/SP
    '00 BF'       # alignment nop
)
wrapper += (DRAW_STRING + 1).to_bytes(4, 'little')
wrapper += SMALL_DESCRIPTOR.to_bytes(4, 'little')
assert len(wrapper) == 60
off = WRAPPER - FLASH
image[off:off+len(wrapper)] = wrapper

for call in CALLS:
    pos = call - FLASH
    old = image[pos:pos+4]
    assert old == original[pos:pos+4], f'callsite premodified at {call:#x}'
    h1 = int.from_bytes(old[:2], 'little')
    h2 = int.from_bytes(old[2:], 'little')
    assert h1 & 0xF800 == 0xF000 and h2 & 0xD000 == 0xD000, f'not Thumb BL at {call:#x}'
    assert thumb_bl(call, DRAW_STRING) == old, f'unexpected original BL target at {call:#x}'
    image[pos:pos+4] = thumb_bl(call, WRAPPER)

OUT.write_text(encode(image))
check = decode(OUT)
assert check == image, 'Intel HEX round-trip mismatch'
for line in OUT.read_text().splitlines():
    assert not (sum(bytes.fromhex(line[1:])) & 0xFF), 'bad Intel HEX checksum'

changed = {i for i, (a, b) in enumerate(zip(original, check)) if a != b}
allowed = set(range(off, off+len(wrapper)))
for call in CALLS:
    allowed.update(range(call-FLASH, call-FLASH+4))
assert changed <= allowed, f'unexpected changes: {sorted(changed-allowed)}'
assert check[SMALL_DESCRIPTOR-FLASH:SMALL_DESCRIPTOR-FLASH+8] == bytes.fromhex('07 0A 00 00 48 F6 00 08')
print('output:', OUT)
print('redirected renderer calls:', ', '.join(hex(x) for x in CALLS))
print('wrapper bytes:', len(wrapper), 'at', hex(WRAPPER))
print('changed bytes:', len(changed), '(only wrapper and the nine callsites)')
print('sha256:', hashlib.sha256(OUT.read_bytes()).hexdigest())
