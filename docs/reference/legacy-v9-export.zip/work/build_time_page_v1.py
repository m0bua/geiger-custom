from pathlib import Path
import hashlib
FLASH=0x08000000
SOURCE=Path('work/port-20261006-0203-settings-layout-v1.hex')
OUT=Path('work/port-20261006-0217-time-page-v1.hex')
BASE_SHA='40b07cdffc773c4038164a47143e8057d15bae0da82141154bbd8985739738be'
# The top Time page formats %02d:%02d through the sequence at 0x0800AA58.
# This is distinct from 0x0800CF38, which belongs to the clock editor menu.
TIME_X=0x0800AAA4 # movs r0,#36 immediately before its DRAW_STRING call

def decode(path):
    im=bytearray([0xff])*0x10000; up=0
    for line in path.read_text().splitlines():
        if not line.startswith(':'): continue
        rec=bytes.fromhex(line[1:]); n,hi,lo,typ=rec[:4]; data=rec[4:-1]
        if len(data)!=n or sum(rec)&0xff: raise ValueError('bad Intel HEX')
        if typ==4: up=int.from_bytes(data,'big')<<16
        elif typ==0:
            off=up+(hi<<8)+lo-FLASH
            if not 0<=off<=len(im)-n: raise ValueError('outside image')
            im[off:off+n]=data
        elif typ==1: break
    return im

def encode(im):
    lines=[':020000040800F2']
    for off in range(0,len(im),16):
        rec=bytes([16,off>>8,off&255,0])+im[off:off+16]
        lines.append(':'+(rec+bytes([(-sum(rec))&0xff])).hex().upper())
    return '\n'.join(lines+[':00000001FF',''])

assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=decode(SOURCE); before=bytes(im)
o=TIME_X-FLASH
assert im[o:o+2]==bytes.fromhex('24 20'), im[o:o+2].hex()
im[o:o+2]=bytes.fromhex('3A 20') # 36 -> 58, +22 px = two Medium cells
OUT.write_text(encode(im))
check=decode(OUT)
assert check==im
assert all(not(sum(bytes.fromhex(line[1:]))&0xff) for line in OUT.read_text().splitlines())
changed={i for i,(a,b) in enumerate(zip(before,check)) if a!=b}
assert changed=={o},changed
print(OUT)
print('top-page time x: 36 -> 58 (+22 px)')
print('sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
