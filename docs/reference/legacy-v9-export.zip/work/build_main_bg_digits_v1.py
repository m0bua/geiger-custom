#!/usr/bin/env python3
"""Enlarge the Small 7x10 digit rasters used by the main reading."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261005-1751-energy-stats-5x8-v2.hex')
OUT = Path('work/port-20261005-1751-main-bg-digits-v1.hex')
SOURCE_SHA256 = 'caa155761d4a3fa452ce0cb4f992f79e5698d1a38c3cb89c3caab9915f8febd1'

SMALL_TABLE = 0x0800F648
SMALL_PERIOD = SMALL_TABLE + 14 * 20       # Small byte 0x2E
SMALL_DIGITS = SMALL_TABLE + 16 * 20        # Small bytes 0x30..0x39
SMALL_PERCENT = 0x0800F904                  # Small extension byte 0x43
TINY_TABLE = 0x0800F9D4
TINY_DESCRIPTOR = 0x0800FD10
GLYPH_COUNT = 12


def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 0xFF:
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError('record outside firmware image')
            image[off:off+n] = data
        elif typ == 1:
            break
    return image


def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])


def unpack_7x10(data):
    assert len(data) == 20
    rows = []
    for y in range(10):
        word = int.from_bytes(data[2*y:2*y+2], 'little')
        rows.append([bool(word & (0x8000 >> x)) for x in range(7)])
    return rows


def enlarge_active_7x10(rows):
    """Scale each digit's inked bounding box ~1.3x inside the same 7x10 cell."""
    ys = [y for y, row in enumerate(rows) if any(row)]
    xs = [x for x in range(7) if any(rows[y][x] for y in ys)]
    if not xs:
        return [[False] * 7 for _ in range(10)]
    x0, x1 = min(xs), max(xs) + 1
    y0, y1 = min(ys), max(ys) + 1
    src = [row[x0:x1] for row in rows[y0:y1]]
    sw, sh = len(src[0]), len(src)
    # Round upward toward 1.3x, but never exceed the Small 7x10 cell.
    dw = min(6, max(1, int(sw * 1.3 + 0.5)))
    dh = min(10, max(1, int(sh * 1.3 + 0.5)))
    scaled = [[src[min(sh-1, int((y + .5) * sh / dh))]
                    [min(sw-1, int((x + .5) * sw / dw))]
               for x in range(dw)] for y in range(dh)]
    out = [[False] * 7 for _ in range(10)]
    xoff, yoff = (7-dw)//2, (10-dh)//2
    for y, row in enumerate(scaled):
        out[y+yoff][xoff:xoff+dw] = row
    return out


def pack_7x10(rows):
    assert len(rows) == 10 and all(len(row) == 7 for row in rows)
    out = bytearray()
    for row in rows:
        word = sum(bool(pixel) << (15-x) for x, pixel in enumerate(row))
        out.extend(word.to_bytes(2, 'little'))
    return bytes(out)


if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
    raise ValueError('accepted main-percent-v2 SHA-256 mismatch')
image = decode(SOURCE)
original = bytes(image)
small_digits_off = SMALL_DIGITS - FLASH

for i in range(10):
    off = SMALL_DIGITS - FLASH + i * 20
    old = bytes(image[off:off+20])
    rows = unpack_7x10(old)
    image[off:off+20] = pack_7x10(enlarge_active_7x10(rows))

OUT.write_text(encode(image))
check = decode(OUT)
assert check == image, 'Intel HEX round-trip mismatch'
for line in OUT.read_text().splitlines():
    assert not (sum(bytes.fromhex(line[1:])) & 255), 'bad Intel HEX checksum'
changed = {i for i, (a, b) in enumerate(zip(original, check)) if a != b}
allowed = set(range(small_digits_off, small_digits_off + 10*20))
assert changed <= allowed, f'unexpected changes: {sorted(changed-allowed)}'
assert len(changed) > 0
assert check[0x0800FD08-FLASH:0x0800FD10-FLASH] == bytes.fromhex('07 0A 00 00 48 F6 00 08')
assert check[0x0800FD10-FLASH:0x0800FD18-FLASH] == bytes.fromhex('05 08 00 00 D4 F9 00 08')
print('output:', OUT)
print('Enlarged only Small digits 0-9 by about 1.3x inside their existing 7x10 cells')
print('changed bytes:', len(changed), '(only the ten Small digit rasters)')
print('sha256:', hashlib.sha256(OUT.read_bytes()).hexdigest())
