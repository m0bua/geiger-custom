from pathlib import Path
import hashlib
FLASH=0x08000000
SOURCE=Path('work/port-20261006-0015-energy-off-position-v3.hex')
OUT=Path('work/port-20261006-0015-energy-off-position-v4.hex')
BASE_SHA='66b0a051e2958883bfe3ff2c795e015dc648664f2fab4c644b32b43ce8134ceb'
CALL=0x08009252
DRAW=0x08008E48

def decode(path):
    image=bytearray([0xFF])*0x10000; upper=0
    for line in path.read_text().splitlines():
        if not line.startswith(':'): continue
        rec=bytes.fromhex(line[1:]); n,hi,lo,typ=rec[:4]; data=rec[4:-1]
        if n!=len(data) or sum(rec)&0xFF: raise ValueError('bad input HEX record')
        if typ==4: upper=int.from_bytes(data,'big')<<16
        elif typ==0:
            off=upper+(hi<<8)+lo-FLASH
            if not 0<=off<=len(image)-n: raise ValueError('record out of range')
            image[off:off+n]=data
        elif typ==1: break
    return image

def encode(image):
    lines=[':020000040800F2']
    for off in range(0,len(image),16):
        rec=bytes([16,off>>8,off&255,0])+image[off:off+16]
        lines.append(':'+(rec+bytes([(-sum(rec))&255])).hex().upper())
    return '\n'.join(lines+[':00000001FF',''])

def target(image,addr):
    o=addr-FLASH; a=int.from_bytes(image[o:o+2],'little'); b=int.from_bytes(image[o+2:o+4],'little')
    if a&0xF800!=0xF000 or b&0xD000!=0xD000:return None
    s=a>>10&1;j1=b>>13&1;j2=b>>11&1;i1=1^(j1^s);i2=1^(j2^s)
    d=(s<<24)|(i1<<23)|(i2<<22)|((a&1023)<<12)|((b&2047)<<1)
    if s:d-=1<<25
    return (addr+4+d)&0xFFFFFFFF

if hashlib.sha256(SOURCE.read_bytes()).hexdigest()!=BASE_SHA: raise ValueError('base hash mismatch')
im=decode(SOURCE); original=bytes(im)
assert target(im,CALL)==DRAW
# Shift the centered two-digit Medium value 1.5 glyphs right and half a glyph down.
o=CALL-FLASH
assert im[o-8:o+4]==bytes.fromhex('1B 68 22 00 1A 21 46 20 FF F7 F9 FD')
im[o-4:o-2]=bytes.fromhex('1E 21') # y=30
im[o-2:o]=bytes.fromhex('44 20')   # x=68
assert target(im,CALL)==DRAW
OUT.write_text(encode(im)); check=decode(OUT); assert check==im
for line in OUT.read_text().splitlines():
    if line.startswith(':') and sum(bytes.fromhex(line[1:]))&255: raise ValueError('bad output checksum')
changed={i for i,(a,b) in enumerate(zip(original,check)) if a!=b}
assert changed=={o-4,o-2},changed
print('output',OUT,'changed_bytes',len(changed),'coordinates',(68,30),'sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
