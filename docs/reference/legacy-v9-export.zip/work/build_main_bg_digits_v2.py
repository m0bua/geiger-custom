#!/usr/bin/env python3
"""Use the existing Medium 11x18 font only for the main background reading."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261005-1751-energy-stats-5x8-v2.hex')
OUT = Path('work/port-20261005-1751-main-bg-digits-v2.hex')
SOURCE_SHA256 = 'caa155761d4a3fa452ce0cb4f992f79e5698d1a38c3cb89c3caab9915f8febd1'

# The central background-value renderer loads its font descriptor from this
# literal at the draw setup around 0x0800923E. The current RAM descriptor is
# 7x10 Small; point this one draw path at the existing 11x18 Medium descriptor.
FONT_DESCRIPTOR_LITERAL = 0x08009308
OLD_DESCRIPTOR_PTR = 0x2000004C
MEDIUM_DESCRIPTOR = 0x0800FCF8
SMALL_DESCRIPTOR = 0x0800FD08


def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, kind = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 0xFF:
            raise ValueError('invalid Intel HEX record')
        if kind == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif kind == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off+n > len(image):
                raise ValueError('record outside firmware image')
            image[off:off+n] = data
        elif kind == 1:
            break
    return image


def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])


if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
    raise ValueError('accepted energy-stats-5x8-v2 SHA-256 mismatch')
image = decode(SOURCE)
original = bytes(image)

# Check this is the literal used by the second descriptor load, and that the
# two font descriptors retain their documented layouts.
assert image[0x0800923E-FLASH:0x08009240-FLASH] == bytes.fromhex('32 4B')
ptr_off = FONT_DESCRIPTOR_LITERAL - FLASH
assert int.from_bytes(image[ptr_off:ptr_off+4], 'little') == OLD_DESCRIPTOR_PTR
assert image[MEDIUM_DESCRIPTOR-FLASH:MEDIUM_DESCRIPTOR-FLASH+8] == bytes.fromhex('0B 12 00 00 A8 F0 00 08')
assert image[SMALL_DESCRIPTOR-FLASH:SMALL_DESCRIPTOR-FLASH+8] == bytes.fromhex('07 0A 00 00 48 F6 00 08')

image[ptr_off:ptr_off+4] = MEDIUM_DESCRIPTOR.to_bytes(4, 'little')
OUT.write_text(encode(image))
check = decode(OUT)
assert check == image, 'Intel HEX round-trip mismatch'
for line in OUT.read_text().splitlines():
    if line.startswith(':'):
        assert not (sum(bytes.fromhex(line[1:])) & 255), 'bad Intel HEX checksum'
changed = {i for i, (a, b) in enumerate(zip(original, check)) if a != b}
expected_changed = {ptr_off+i for i, (a, b) in enumerate(zip(OLD_DESCRIPTOR_PTR.to_bytes(4, 'little'), MEDIUM_DESCRIPTOR.to_bytes(4, 'little'))) if a != b}
assert changed == expected_changed, f'unexpected changed bytes: {sorted(changed)}'
assert int.from_bytes(check[ptr_off:ptr_off+4], 'little') == MEDIUM_DESCRIPTOR
assert check[SMALL_DESCRIPTOR-FLASH:SMALL_DESCRIPTOR-FLASH+8] == bytes.fromhex('07 0A 00 00 48 F6 00 08')
assert check[MEDIUM_DESCRIPTOR-FLASH:MEDIUM_DESCRIPTOR-FLASH+8] == bytes.fromhex('0B 12 00 00 A8 F0 00 08')
print('output:', OUT)
print('Only the main background-reading draw path now selects Medium 11x18')
print('Small digits, time, battery percent, and all other bytes are unchanged')
print('changed bytes:', len(changed))
print('sha256:', hashlib.sha256(OUT.read_bytes()).hexdigest())
