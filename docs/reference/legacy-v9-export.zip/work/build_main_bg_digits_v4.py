#!/usr/bin/env python3
"""Scale 11x18 Medium digit ink by 1.5x in place; preserve all other glyphs."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261005-1751-energy-stats-5x8-v2.hex')
OUT = Path('work/port-20261005-2039-main-bg-digits-v4.hex')
SOURCE_SHA256 = 'caa155761d4a3fa452ce0cb4f992f79e5698d1a38c3cb89c3caab9915f8febd1'
MEDIUM_TABLE = 0x0800F0A8
DIGITS = MEDIUM_TABLE + 16 * 36  # character bytes 0x30..0x39
MEDIUM_DESC = 0x0800FCF8
SMALL_TABLE = 0x0800F648
TINY_TABLE = 0x0800F9D4


def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 255:
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off+n > len(image):
                raise ValueError('record outside image')
            image[off:off+n] = data
        elif typ == 1:
            break
    return image


def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])


def unpack_glyph(data):
    assert len(data) == 36
    rows=[]
    for y in range(18):
        word=int.from_bytes(data[y*2:y*2+2], 'little')
        rows.append([bool(word & (0x8000 >> x)) for x in range(11)])
    return rows


def scale_1_5(rows):
    ys=[y for y,row in enumerate(rows) if any(row)]
    xs=[x for x in range(11) if any(rows[y][x] for y in ys)]
    if not xs or not ys:
        return [[False]*11 for _ in range(18)]
    x0,x1=min(xs),max(xs)+1; y0,y1=min(ys),max(ys)+1
    src=[row[x0:x1] for row in rows[y0:y1]]
    sw,sh=len(src[0]),len(src)
    dw=min(11,max(sw,round(sw*1.5)))
    dh=min(18,max(sh,round(sh*1.5)))
    scaled=[[src[min(sh-1,int((y+0.5)*sh/dh))][min(sw-1,int((x+0.5)*sw/dw))] for x in range(dw)] for y in range(dh)]
    out=[[False]*11 for _ in range(18)]
    xo=(11-dw)//2; yo=(18-dh)//2
    for y,row in enumerate(scaled): out[yo+y][xo:xo+dw]=row
    return out


def pack_glyph(rows):
    out=bytearray()
    for row in rows:
        word=sum(bool(px) << (15-x) for x,px in enumerate(row))
        out.extend(word.to_bytes(2,'little'))
    return bytes(out)

if hashlib.sha256(SOURCE.read_bytes()).hexdigest()!=SOURCE_SHA256:
    raise ValueError('accepted energy-stats base hash mismatch')
image=decode(SOURCE); original=bytes(image)
assert image[MEDIUM_DESC-FLASH:MEDIUM_DESC-FLASH+8] == bytes.fromhex('0B 12 00 00 A8 F0 00 08')
assert image[0x08009308-FLASH:0x0800930C-FLASH] == bytes.fromhex('4C 00 00 20'), 'main draw descriptor path differs from accepted base'
for i in range(10):
    off=DIGITS-FLASH+i*36
    image[off:off+36]=pack_glyph(scale_1_5(unpack_glyph(image[off:off+36])))
OUT.write_text(encode(image))
check=decode(OUT)
assert check==image
for line in OUT.read_text().splitlines():
    assert not (sum(bytes.fromhex(line[1:]))&255)
changed={i for i,(a,b) in enumerate(zip(original,check)) if a!=b}
allowed=set(range(DIGITS-FLASH,DIGITS-FLASH+10*36))
assert changed and changed<=allowed, f'unexpected changed bytes {sorted(changed-allowed)}'
assert check[SMALL_TABLE-FLASH:SMALL_TABLE-FLASH+700]==original[SMALL_TABLE-FLASH:SMALL_TABLE-FLASH+700]
assert check[TINY_TABLE-FLASH:TINY_TABLE-FLASH+192]==original[TINY_TABLE-FLASH:TINY_TABLE-FLASH+192]
print('output:',OUT)
print('Scaled active 11x18 Medium glyphs 0-9 by 1.5x; only ten Medium digit glyph rasters changed.')
print('Small/Tiny glyphs, battery/time code, and main call descriptor are unchanged.')
print('changed bytes:',len(changed),'sha256:',hashlib.sha256(OUT.read_bytes()).hexdigest())
