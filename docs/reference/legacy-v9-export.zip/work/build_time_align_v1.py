from pathlib import Path
import hashlib
FLASH=0x08000000
SOURCE=Path('work/port-20261006-0203-settings-layout-v1.hex')
OUT=Path('work/port-20261006-0210-time-align-v1.hex')
BASE_SHA='40b07cdffc773c4038164a47143e8057d15bae0da82141154bbd8985739738be'
TIME_X=0x0800CF36  # movs r0,#70 immediately before the clock-page time draw at CF38

def decode(p):
 im=bytearray([255])*0x10000;up=0
 for line in p.read_text().splitlines():
  if not line.startswith(':'):continue
  r=bytes.fromhex(line[1:]);n,hi,lo,t=r[:4];d=r[4:-1]
  if len(d)!=n or sum(r)&255:raise ValueError('bad Intel HEX')
  if t==4:up=int.from_bytes(d,'big')<<16
  elif t==0:
   o=up+(hi<<8)+lo-FLASH
   if not 0<=o<=len(im)-n:raise ValueError('address range')
   im[o:o+n]=d
  elif t==1:break
 return im

def encode(im):
 lines=[':020000040800F2']
 for o in range(0,len(im),16):
  r=bytes([16,o>>8,o&255,0])+im[o:o+16]
  lines.append(':'+(r+bytes([(-sum(r))&255])).hex().upper())
 return '\n'.join(lines+[':00000001FF',''])

assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=decode(SOURCE);old=bytes(im)
assert im[TIME_X-FLASH:TIME_X-FLASH+2]==bytes.fromhex('46 20')
im[TIME_X-FLASH:TIME_X-FLASH+2]=bytes.fromhex('5C 20') # 70 -> 92 = +22 px
OUT.write_text(encode(im));check=decode(OUT);assert check==im
for line in OUT.read_text().splitlines():assert not(sum(bytes.fromhex(line[1:]))&255)
changed={i for i,(a,b) in enumerate(zip(old,check))if a!=b}
assert changed=={TIME_X-FLASH},changed
print('output',OUT)
print('time x: 70 -> 92 (+22 px, two Medium glyph cells)')
print('sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
