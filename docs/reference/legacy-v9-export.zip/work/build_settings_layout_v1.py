from pathlib import Path
import hashlib
FLASH=0x08000000
SOURCE=Path('work/port-20261006-0155-energy-off-zero-v7.hex')
OUT=Path('work/port-20261006-0203-settings-layout-v1.hex')
BASE_SHA='b8b0c6b838dc33402b5472801ace3b33d9ac681445e744847fab4e4d8e35546b'
SV_X=0x0800B518       # movs r1,#77: top-level SETTINGS label "Sv"
SUN_X_ADD=0x0800B3D2 # adds #92 to 43: raster sun icon placed on SETTINGS page

def decode(p):
 im=bytearray([255])*0x10000; upper=0
 for line in p.read_text().splitlines():
  if not line.startswith(':'): continue
  r=bytes.fromhex(line[1:]); n,hi,lo,t=r[:4]; d=r[4:-1]
  if len(d)!=n or sum(r)&255: raise ValueError('bad Intel HEX')
  if t==4: upper=int.from_bytes(d,'big')<<16
  elif t==0:
   o=upper+(hi<<8)+lo-FLASH
   if not 0<=o<=len(im)-n: raise ValueError('address range')
   im[o:o+n]=d
  elif t==1: break
 return im

def encode(im):
 lines=[':020000040800F2']
 for o in range(0,len(im),16):
  r=bytes([16,o>>8,o&255,0])+im[o:o+16]
  lines.append(':'+(r+bytes([(-sum(r))&255])).hex().upper())
 return '\n'.join(lines+[':00000001FF',''])

assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=decode(SOURCE); original=bytes(im)
assert im[SV_X-FLASH:SV_X-FLASH+2]==bytes.fromhex('4D 21')
assert im[SUN_X_ADD-FLASH:SUN_X_ADD-FLASH+2]==bytes.fromhex('5C 32')
# Sv: x=77 -> 74 (three pixels left); sun: x=135 -> 138 (three pixels right).
im[SV_X-FLASH:SV_X-FLASH+2]=bytes.fromhex('4A 21')
im[SUN_X_ADD-FLASH:SUN_X_ADD-FLASH+2]=bytes.fromhex('5F 32')
OUT.write_text(encode(im)); check=decode(OUT); assert check==im
for line in OUT.read_text().splitlines(): assert not(sum(bytes.fromhex(line[1:]))&255)
changed={i for i,(a,b) in enumerate(zip(original,check)) if a!=b}
assert changed=={SV_X-FLASH,SUN_X_ADD-FLASH},changed
print('output',OUT)
print('Sv x: 77 -> 74; sun x: 135 -> 138')
print('sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
