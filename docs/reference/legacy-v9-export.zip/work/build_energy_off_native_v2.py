from pathlib import Path
import hashlib
FLASH=0x08000000
SOURCE=Path('work/port-20261006-0015-energy-off-position-v4.hex')
OUT=Path('work/port-20261006-0136-energy-off-native-v2.hex')
BASE_SHA='7d003596b1c1946bee4843dd9d99d29d1c4256c39d9e1bd18b9e2b3023d1b0c7'
CALL=0x080092BC
DISPATCH=0x0800AFE4
FILL=0x08008ECC
HELPER=0x0800F118

def decode(path):
 im=bytearray([255])*0x10000; upper=0
 for line in path.read_text().splitlines():
  if not line.startswith(':'):continue
  rec=bytes.fromhex(line[1:]);n,hi,lo,typ=rec[:4];data=rec[4:-1]
  if n!=len(data) or sum(rec)&255:raise ValueError('invalid HEX')
  if typ==4:upper=int.from_bytes(data,'big')<<16
  elif typ==0:
   off=upper+(hi<<8)+lo-FLASH
   if off<0 or off+n>len(im):raise ValueError('out of range')
   im[off:off+n]=data
  elif typ==1:break
 return im
def encode(im):
 lines=[':020000040800F2']
 for off in range(0,len(im),16):
  rec=bytes([16,off>>8,off&255,0])+im[off:off+16]
  lines.append(':'+(rec+bytes([(-sum(rec))&255])).hex().upper())
 return '\n'.join(lines+[':00000001FF',''])
def bl(addr,target):
 d=target-(addr+4)
 if d&1 or not -(1<<24)<=d<(1<<24):raise ValueError('BL range')
 x=d&0x1ffffff;s=x>>24&1;i1=x>>23&1;i2=x>>22&1;j1=1^(i1^s);j2=1^(i2^s)
 return (0xf000|(s<<10)|((x>>12)&1023)).to_bytes(2,'little')+(0xd000|(j1<<13)|(j2<<11)|((x>>1)&2047)).to_bytes(2,'little')
def target(im,addr):
 i=addr-FLASH;h1=int.from_bytes(im[i:i+2],'little');h2=int.from_bytes(im[i+2:i+4],'little')
 if h1&0xf800!=0xf000 or h2&0xd000!=0xd000:return None
 s=h1>>10&1;j1=h2>>13&1;j2=h2>>11&1;i1=1^(j1^s);i2=1^(j2^s)
 v=(s<<24)|(i1<<23)|(i2<<22)|((h1&1023)<<12)|((h2&2047)<<1)
 if s:v-=1<<25
 return (addr+4+v)&0xffffffff
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=decode(SOURCE);original=bytes(im)
assert target(im,CALL)==DISPATCH
assert im[HELPER-FLASH:HELPER-FLASH+20]==bytes([255])*20
# Solid red overlay at the dynamic resource's known native rectangle: (57,28), 45x23.
helper=bytes.fromhex('00 B5 81 B0 00 92 1C 21 2D 22 17 23')+bl(HELPER+12,FILL)+bytes.fromhex('01 B0 00 BD')
assert len(helper)==20
im[HELPER-FLASH:HELPER-FLASH+20]=helper
# Substitute only the resource argument setup at this callsite; marker helper uses x=57 and RGB565 red.
start=CALL-FLASH-8
im[start:start+8]=bytes.fromhex('39 20 1F 22 00 BF 00 BF')
im[CALL-FLASH:CALL-FLASH+4]=bl(CALL,HELPER)
OUT.write_text(encode(im));check=decode(OUT);assert check==im
for line in OUT.read_text().splitlines():
 if line.startswith(':') and sum(bytes.fromhex(line[1:]))&255:raise ValueError('bad checksum')
changed={i for i,(a,b) in enumerate(zip(original,check)) if a!=b}
allowed=set(range(HELPER-FLASH,HELPER-FLASH+20))|set(range(CALL-FLASH-8,CALL-FLASH+4))
assert changed<=allowed,sorted(changed-allowed)
print('output',OUT,'changed_bytes',len(changed),'overlay',(57,28,45,23),'sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
