from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261006-0245-date-format-v1.hex')
OUT = Path('work/port-20261006-0747-settings-sun-v1.hex')
BASE_SHA = 'd94c51c189c0b0a9ce5c05a3909a3cf882c46ae9d69300759a6e719ec9c38fc2'

# Top-level Settings menu: the right-hand damaged icon call at 0x0800BA26.
# The confirmed sun resource uses selector 17 and is centered in the original
# 20x20 tile at (134,58).  Existing tile x was 130, so only x and selector
# are changed; all other screens and the accepted date-format base remain intact.
SUN_X_ADD = 0x0800BA1A       # adds #76 -> x=130 before the raster call
SUN_SELECTOR = 0x0800BA24    # movs r0,#11 in the call setup

def decode(path):
    image = bytearray([0xFF]) * 0x10000
    upper = 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        count, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if len(data) != count or (sum(rec) & 0xFF):
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            start = upper + (hi << 8) + lo - FLASH
            image[start:start + count] = data
        elif typ == 1:
            break
    return image

def encode(image):
    lines = [':020000040800F2']
    for offset in range(0, len(image), 16):
        body = bytes((16, offset >> 8, offset & 0xFF, 0)) + image[offset:offset + 16]
        lines.append(':' + (body + bytes(((-sum(body)) & 0xFF,))).hex().upper())
    lines += [':00000001FF', '']
    return '\n'.join(lines)

assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == BASE_SHA
image = decode(SOURCE)
original = bytes(image)

assert image[SUN_X_ADD - FLASH:SUN_X_ADD - FLASH + 2] == bytes.fromhex('4C 32')
assert image[SUN_SELECTOR - FLASH:SUN_SELECTOR - FLASH + 2] == bytes.fromhex('0B 20')

image[SUN_X_ADD - FLASH:SUN_X_ADD - FLASH + 2] = bytes.fromhex('50 32')  # x 130 -> 134
image[SUN_SELECTOR - FLASH:SUN_SELECTOR - FLASH + 2] = bytes.fromhex('11 20')  # selector 11 -> 17

OUT.write_text(encode(image))
check = decode(OUT)
assert check == image
assert all((sum(bytes.fromhex(line[1:])) & 0xFF) == 0 for line in OUT.read_text().splitlines())
changed = {i for i, (a, b) in enumerate(zip(original, check)) if a != b}
allowed = {SUN_X_ADD - FLASH, SUN_SELECTOR - FLASH}
assert changed == allowed, (changed, allowed)
print(OUT)
print('sha256', hashlib.sha256(OUT.read_bytes()).hexdigest())
print('sun tile x: 130 -> 134; selector: 11 -> 17; y unchanged')
