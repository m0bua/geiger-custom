#!/usr/bin/env python3
"""Replace TIME field rasters with 11x18 labels, built from clean v51."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261005-1350-time-unknown-calls-disabled-v51.hex')
RESTORE_SOURCE = Path('upload/03-port-20261005-0850-settings-icon-sun-v25.hex')
OUT = Path('work/port-20261005-1700-time-labels-v8.hex')
SOURCE_SHA256 = '4088db379e517155a9a82e332f5d768ca9fda6262d41a930ad34f39d021ab3b6'
DRAW = 0x08008E48
FONT = 0x0800F0A8
HELPER = 0x0800F0CC       # two unused 11x18 punctuation slots: ! and # (72 bytes)
HELPER_END = 0x0800F138
STRINGS = 0x0800F138      # unused $ slot (36 bytes)

# Labels are placed in the known left / centre / right plaques.
# Captions use y=55. Side labels track the requested half-character adjustments.
FIELDS = [
    # hour state
    (0x0800D064, 0, 69), (0x0800D084, 1, 125),
    # minute state
    (0x0800D2FC, 0, 10), (0x0800D2D6, 1, 64), (0x0800D31C, 2, 125),
    # day state
    (0x0800D5B6, 1, 5), (0x0800D590, 2, 64), (0x0800D5D6, 3, 123),
    # month state
    (0x0800D868, 2, 7), (0x0800D842, 3, 64), (0x0800D888, 4, 131),
    # year state
    (0x0800DAC4, 3, 2), (0x0800DAA4, 4, 70),
]

# User-confirmed diagnostic calls on selection 2 (leave these calls untouched):
# D226 red = upper-centre plaque; D244 green = lower-centre; D27E yellow = lower-right;
# D298 blue-violet = upper-left icon; D262 blue = upper-right icon.
# D2B2 was an unknown red raster call, disabled in v51; restore original call to test missing plaque.
# DA68 was another disabled raster call; restore it to test year-screen upper-left MONTH plaque.

def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 0xFF:
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError('record outside firmware image')
            image[off:off+n] = data
        elif typ == 1:
            break
    return image

def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 0xFF])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])

def thumb_bl(address, target):
    delta = target - (address + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError('Thumb BL out of range')
    imm = delta & 0x1FFFFFF
    s, i1, i2 = (imm >> 24) & 1, (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = 1 ^ (i1 ^ s), 1 ^ (i2 ^ s)
    h1 = 0xF000 | (s << 10) | ((imm >> 12) & 0x3FF)
    h2 = 0xD000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7FF)
    return h1.to_bytes(2, 'little') + h2.to_bytes(2, 'little')

def bl_target(image, address):
    off = address - FLASH
    h1 = int.from_bytes(image[off:off+2], 'little')
    h2 = int.from_bytes(image[off+2:off+4], 'little')
    if h1 & 0xF800 != 0xF000 or h2 & 0xD000 != 0xD000:
        return None
    s, j1, j2 = (h1 >> 10) & 1, (h2 >> 13) & 1, (h2 >> 11) & 1
    i1, i2 = 1 ^ (j1 ^ s), 1 ^ (j2 ^ s)
    imm = (s << 24) | (i1 << 23) | (i2 << 22) | ((h1 & 0x3FF) << 12) | ((h2 & 0x7FF) << 1)
    if s:
        imm -= 1 << 25
    return (address + 4 + imm) & 0xFFFFFFFF

def glyph_addr(code):
    return FONT + 36 * (code - 0x20)

def glyph(rows):
    if len(rows) != 18 or any(len(row) != 11 for row in rows):
        raise ValueError('expected 11x18 glyph')
    out = bytearray()
    for row in rows:
        bits = sum((c == '#') << (15-i) for i, c in enumerate(row))
        out.extend(bits.to_bytes(2, 'little'))
    return bytes(out)

def make_helper():
    code = bytearray(); literals = []
    def e16(v): code.extend(v.to_bytes(2, 'little'))
    def ldr(rd, value):
        at = len(code); e16(0x4800 | (rd << 8)); literals.append((at, value))
    # r0=selector 0..4, r1=x. The call sites already run after their plaque fill.
    e16(0xB510)                 # push {r4,lr}
    e16(0xB084)                 # sub sp,#16
    e16(0x0080)                 # selector * 4
    ldr(2, STRINGS)             # string table
    e16(0x1812)                 # r2 += selector*4
    e16(0x4608)                 # r0=x
    e16(0x2137)                 # y=55, lower unit-caption row
    ldr(3, FONT); e16(0x9300)   # [sp]=11x18 font
    ldr(3, 0xFFFF); e16(0x9301) # foreground white
    # Match the lower plaques: centre is brighter; side plaques are darker.
    e16(0x283C)                 # cmp x,#60
    e16(0xD305)                 # bcc darker (left side)
    e16(0x4604)                 # r4=x (r0 still holds x; r1 now holds y)
    e16(0x3C3C)                 # r4 -= 60
    e16(0x2C14)                 # centre tile iff 60 <= x < 80
    e16(0xD201)                 # bcs darker (x >= 80)
    ldr(3, 0xF980)              # bright red-orange: selected lower half
    e16(0xE000)                 # b background_ready
    ldr(3, 0x7922)              # slightly lighter red: side lower halves
    e16(0x9302)
    e16(0x2312); e16(0x021B); e16(0x330B)  # r3=(18<<8)|11
    code.extend(thumb_bl(HELPER + len(code), DRAW))
    e16(0xB004); e16(0xBD10)
    while (HELPER + len(code)) & 3:
        code.append(0)
    literal_pos = {}
    for at, value in literals:
        literal_pos[at] = len(code)
        code.extend(value.to_bytes(4, 'little'))
    for at, _value in literals:
        pc = (HELPER + at + 4) & ~3
        delta = HELPER + literal_pos[at] - pc
        if delta < 0 or delta > 1020 or delta & 3:
            raise ValueError('literal out of range')
        rd = (int.from_bytes(code[at:at+2], 'little') >> 8) & 7
        code[at:at+2] = (0x4800 | (rd << 8) | delta // 4).to_bytes(2, 'little')
    if len(code) > HELPER_END - HELPER:
        raise ValueError(f'helper exceeds two slots: {len(code)}')
    return bytes(code)

if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
    raise ValueError('v51 SHA-256 mismatch')
image = decode(SOURCE)
original = bytes(image)
restore_image = decode(RESTORE_SOURCE)
assert original[0x0800D2B2-FLASH:0x0800D2B2-FLASH+4] == bytes.fromhex('00 BF 00 BF')
assert bl_target(restore_image, 0x0800D2B2) == 0x0800AFE4
image[0x0800D2B2-FLASH:0x0800D2B2-FLASH+4] = restore_image[0x0800D2B2-FLASH:0x0800D2B2-FLASH+4]
assert original[0x0800DA68-FLASH:0x0800DA68-FLASH+4] == bytes.fromhex('00 BF 00 BF')
assert bl_target(restore_image, 0x0800DA68) is not None
image[0x0800DA68-FLASH:0x0800DA68-FLASH+4] = restore_image[0x0800DA68-FLASH:0x0800DA68-FLASH+4]

# Codes supplied by the user are 11x18 punctuation glyphs, repurposed for the TIME labels.
# 0x2B is an unused '+' slot reused as O for MON.
new_glyphs = {
    0x26: ['...........','##......##.','##......##.','.##....##..','.##....##..','..##..##...','..##..##...','...####....','...####....','....##.....','....##.....','....##.....','....##.....','....##.....','....##.....','...........','...........','...........'], # Y
    0x28: ['...........','########...','########...','##......##.','##......##.','##......##.','##......##.','##......##.','##......##.','##......##.','##......##.','##......##.','##......##.','########...','########...','...........','...........','...........'], # D
    0x29: ['...........','...####....','..######...','..##..##...','.##....##..','.##....##..','.##....##..','.########..','.########..','##......##.','##......##.','##......##.','##......##.','##......##.','##......##.','...........','...........','...........'], # A
    0x2B: ['...........','...####....','..######...','.##....##..','.##....##..','##......##.','##......##.','##......##.','##......##.','##......##.','##......##.','.##....##..','.##....##..','..######...','...####....','...........','...........','...........'], # O
    0x3B: ['...........','##########.','##########.','....##.....','....##.....','....##.....','....##.....','....##.....','....##.....','....##.....','....##.....','....##.....','....##.....','##########.','##########.','...........','...........','...........'], # I
    0x3C: ['...........','##......##.','##......##.','##......##.','##......##.','##......##.','##......##.','##########.','##########.','##......##.','##......##.','##......##.','##......##.','##......##.','##......##.','...........','...........','...........'], # H
}
for code, rows in new_glyphs.items():
    addr = glyph_addr(code)
    image[addr-FLASH:addr-FLASH+36] = glyph(rows)

strings = bytes.fromhex(
    '3C 44 00 00'  # HR
    '43 3B 45 00'  # MIN
    '28 29 26 00'  # DAY
    '43 2B 45 00'  # MON
    '26 44 00 00'  # YR
)
assert len(strings) == 20
helper = make_helper()
region = bytearray([0xFF]) * (HELPER_END - HELPER)
region[:len(helper)] = helper
image[HELPER-FLASH:HELPER_END-FLASH] = region
image[STRINGS-FLASH:STRINGS-FLASH+len(strings)] = strings

for call, selector, x in FIELDS:
    off = call - FLASH
    assert bl_target(original, call) == 0x0800AFE4, f'unexpected field target at {call:#x}'
    image[off-4:off-2] = (0x2000 | selector).to_bytes(2, 'little')
    image[off-2:off] = (0x2100 | x).to_bytes(2, 'little')
    image[off:off+4] = thumb_bl(call, HELPER)

OUT.write_text(encode(image))
check = decode(OUT)
assert check == image, 'Intel HEX round-trip mismatch'
for line in OUT.read_text().splitlines():
    assert not (sum(bytes.fromhex(line[1:])) & 0xFF), 'bad Intel HEX checksum'
assert check[0x0800B6A4-FLASH:0x0800B6A4-FLASH+4] == original[0x0800B6A4-FLASH:0x0800B6A4-FLASH+4], 'units icon changed'
for call, _selector, _x in FIELDS:
    assert bl_target(check, call) == HELPER
changed = {i for i,(a,b) in enumerate(zip(original,check)) if a != b}
allowed = set(range(HELPER-FLASH,HELPER_END-FLASH)) | set(range(STRINGS-FLASH,STRINGS-FLASH+20))
allowed.update(range(0x0800D2B2-FLASH,0x0800D2B2-FLASH+4))
allowed.update(range(0x0800DA68-FLASH,0x0800DA68-FLASH+4))
for code in new_glyphs:
    allowed.update(range(glyph_addr(code)-FLASH,glyph_addr(code)-FLASH+36))
for call, _selector, _x in FIELDS:
    allowed.update(range(call-FLASH-4,call-FLASH+4))
assert changed <= allowed, f'unexpected changes: {sorted(changed-allowed)}'
print('output:', OUT)
print('labels: HR / MIN / DAY / MON / YR, 11x18')
print('changed bytes:', len(changed))
print('sha256:', hashlib.sha256(OUT.read_bytes()).hexdigest())
