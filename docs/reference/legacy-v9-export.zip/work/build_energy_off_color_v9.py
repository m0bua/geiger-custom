from pathlib import Path
import hashlib
FLASH=0x08000000
SOURCE=Path('work/port-20261005-1751-energy-stats-5x8-v2.hex')
OUT=Path('work/port-20261006-0015-energy-off-color-v9.hex')
BASE_SHA='caa155761d4a3fa452ce0cb4f992f79e5698d1a38c3cb89c3caab9915f8febd1'
DRAW=0x08008E48
FILL=0x08008ECC
HELPER=0x0800F118
CALLS=[
 (0x0800DC74, 31, 11, bytes.fromhex('00 91 1B 68 20 21 44 20'), 0xF800, 'red'),
 (0x0800DD54,126,  4, bytes.fromhex('00 91 1B 68 20 21 44 20'), 0x07E0, 'green'),
 (0x0800DE38, 31,  0, bytes.fromhex('00 91 1B 68 20 21 44 20'), 0x001F, 'blue'),
 (0x0800E002,255,  0, bytes.fromhex('00 91 1B 68 20 21 44 20'), 0x00FF, 'cyan'),
 (0x0800E0E6, 31, 10, bytes.fromhex('00 93 23 68 1E 21 32 20'), 0x7C00, 'dark red'),
]
def decode(path):
 im=bytearray([255])*0x10000; upper=0
 for line in path.read_text().splitlines():
  if not line.startswith(':'):continue
  rec=bytes.fromhex(line[1:]);n,hi,lo,typ=rec[:4];data=rec[4:-1]
  if n!=len(data) or sum(rec)&255:raise ValueError('invalid HEX record')
  if typ==4:upper=int.from_bytes(data,'big')<<16
  elif typ==0:
   off=upper+(hi<<8)+lo-FLASH
   if off<0 or off+n>len(im):raise ValueError('record out of range')
   im[off:off+n]=data
  elif typ==1:break
 return im
def encode(im):
 lines=[':020000040800F2']
 for off in range(0,len(im),16):
  rec=bytes([16,off>>8,off&255,0])+im[off:off+16]
  lines.append(':'+(rec+bytes([(-sum(rec))&255])).hex().upper())
 return '\n'.join(lines+[':00000001FF',''])
def bl(addr,target):
 d=target-(addr+4)
 if d&1 or not -(1<<24)<=d<(1<<24):raise ValueError('BL out of range')
 x=d&0x1ffffff;s=x>>24&1;i1=x>>23&1;i2=x>>22&1;j1=1^(i1^s);j2=1^(i2^s)
 return (0xf000|(s<<10)|((x>>12)&1023)).to_bytes(2,'little')+(0xd000|(j1<<13)|(j2<<11)|((x>>1)&2047)).to_bytes(2,'little')
def target(im,addr):
 i=addr-FLASH;h1=int.from_bytes(im[i:i+2],'little');h2=int.from_bytes(im[i+2:i+4],'little')
 if h1&0xf800!=0xf000 or h2&0xd000!=0xd000:return None
 s=h1>>10&1;j1=h2>>13&1;j2=h2>>11&1;i1=1^(j1^s);i2=1^(j2^s)
 imm=(s<<24)|(i1<<23)|(i2<<22)|((h1&1023)<<12)|((h2&2047)<<1)
 if s:imm-=1<<25
 return (addr+4+imm)&0xffffffff
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=decode(SOURCE); original=bytes(im)
assert im[HELPER-FLASH:HELPER-FLASH+32]==bytes([255])*32
# r0/r1 retain each site's original x/y; r2 carries RGB565 to the wrapper.
helper=bytes.fromhex('00 B5 81 B0 00 92 28 22 12 23')+bl(HELPER+10,FILL)+bytes.fromhex('01 B0 00 BD')
assert len(helper)==18
im[HELPER-FLASH:HELPER-FLASH+len(helper)]=helper
for call,imm,shift,expected,color,name in CALLS:
 assert target(im,call)==DRAW,(hex(call),target(im,call))
 setup=call-FLASH-8
 assert im[setup:setup+8]==expected,(hex(call),im[setup:setup+8].hex())
 mov=(0x2200|imm).to_bytes(2,'little')
 lsl=(0x0012|(shift<<6)).to_bytes(2,'little') if shift else bytes.fromhex('00 BF')
 im[setup:setup+4]=mov+lsl
 im[call-FLASH:call-FLASH+4]=bl(call,HELPER)
 if color not in [0xF800,0x07E0,0x001F,0x00FF,0x7C00]:raise AssertionError
OUT.write_text(encode(im)); check=decode(OUT);assert check==im
for line in OUT.read_text().splitlines():
 if line.startswith(':') and sum(bytes.fromhex(line[1:]))&255:raise ValueError('bad checksum')
changed={i for i,(a,b) in enumerate(zip(original,check)) if a!=b}
allowed=set(range(HELPER-FLASH,HELPER-FLASH+len(helper)))
for call,*_ in CALLS:allowed.update(range(call-FLASH-8,call-FLASH+4))
assert changed<=allowed,sorted(changed-allowed)
print('output',OUT,'changed_bytes',len(changed),'sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
for c,*_,color,name in CALLS:print(hex(c),name,hex(color))
