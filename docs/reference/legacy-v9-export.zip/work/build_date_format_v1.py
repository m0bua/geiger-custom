from pathlib import Path
import hashlib
FLASH=0x08000000
SOURCE=Path('work/port-20261006-0241-time-page-v6.hex')
OUT=Path('work/port-20261006-0245-date-format-v1.hex')
BASE_SHA='eb117b1b2fff12ed4861d76c38cb1e86a34e9fbce5c52432a92b9ae0fbc09ef7'
FMT=0x0800F024

def dec(p):
 im=bytearray([255])*0x10000;up=0
 for l in p.read_text().splitlines():
  if not l.startswith(':'):continue
  r=bytes.fromhex(l[1:]);n,hi,lo,t=r[:4];d=r[4:-1]
  if len(d)!=n or sum(r)&255:raise ValueError('bad hex')
  if t==4:up=int.from_bytes(d,'big')<<16
  elif t==0:
   off=up+(hi<<8)+lo-FLASH
   if not 0<=off<=len(im)-n: raise ValueError('outside image')
   im[off:off+n]=d
  elif t==1:break
 return im[:0x10000]
def enc(im):
 a=[':020000040800F2']
 for o in range(0,len(im),16):
  r=bytes([16,o>>8,o&255,0])+im[o:o+16];a.append(':'+(r+bytes([(-sum(r))&255])).hex().upper())
 return '\n'.join(a+[':00000001FF',''])
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=dec(SOURCE);old=bytes(im);o=FMT-FLASH
assert im[o:o+10]==b'%02d/%02d\0',im[o:o+10]
im[o:o+10]=b'%02d.%02d\0'
OUT.write_text(enc(im));chk=dec(OUT);assert chk==im
assert all(not(sum(bytes.fromhex(l[1:]))&255) for l in OUT.read_text().splitlines())
changed={i for i,(a,b) in enumerate(zip(old,chk))if a!=b};assert changed=={o+4}
print(OUT);print('date format %02d/%02d -> %02d.%02d');print('sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
