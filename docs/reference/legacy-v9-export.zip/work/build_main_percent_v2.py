#!/usr/bin/env python3
"""Scale the selected 5x8 percent shape into the active 7x10 font slot."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261005-1700-time-labels-v8.hex')
OUT = Path('work/port-20261005-1725-main-percent-v2.hex')
SOURCE_SHA256 = '9caf2b625bca4798eee595e906fcce6ef597ec0509dd270535143a811cf06b12'
TINY_REFERENCE = 0x0800F9E4
SMALL_PERCENT = 0x0800F904  # extension used by the first-screen 7x10 battery text

def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 0xFF:
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError('record outside firmware image')
            image[off:off+n] = data
        elif typ == 1:
            break
    return image

def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 0xFF])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])

def unpack_5x8(data):
    rows = []
    for y in range(8):
        bits = int.from_bytes(data[y*2:y*2+2], 'little')
        rows.append([bool(bits & (0x8000 >> x)) for x in range(5)])
    return rows

def pack_7x10(rows):
    if len(rows) != 10 or any(len(row) != 7 for row in rows):
        raise ValueError('expected 7x10 glyph')
    out = bytearray()
    for row in rows:
        bits = sum(bool(pixel) << (15-x) for x, pixel in enumerate(row))
        out.extend(bits.to_bytes(2, 'little'))
    return bytes(out)

if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
    raise ValueError('v8 SHA-256 mismatch')
image = decode(SOURCE)
original = bytes(image)

tiny_off = TINY_REFERENCE - FLASH
tiny = unpack_5x8(bytes(image[tiny_off:tiny_off+16]))
expected = ['.....', '##..#', '##.#.', '..#..', '.#.##', '#..##', '.....', '.....']
assert [''.join('#' if p else '.' for p in row) for row in tiny] == expected
ys = [y for y in range(8) if any(tiny[y])]
xs = [x for x in range(5) if any(tiny[y][x] for y in range(8))]
assert (min(xs), max(xs), min(ys), max(ys)) == (0, 4, 1, 5)

# Nearest-neighbour enlargement of the square 5x5 active mark to 7x7.
# Center it in the 7x10 cell, leaving one blank row above and two below.
rows = [[False] * 7 for _ in range(10)]
for dy in range(7):
    sy = min(4, int((dy + 0.5) * 5 / 7))
    for dx in range(7):
        sx = min(4, int((dx + 0.5) * 5 / 7))
        rows[1+dy][dx] = tiny[1+sy][sx]
glyph = pack_7x10(rows)
off = SMALL_PERCENT - FLASH
image[off:off+20] = glyph

OUT.write_text(encode(image))
check = decode(OUT)
assert check == image, 'Intel HEX round-trip mismatch'
for line in OUT.read_text().splitlines():
    assert not (sum(bytes.fromhex(line[1:])) & 0xFF), 'bad Intel HEX checksum'
assert check[off:off+20] == glyph
assert check[tiny_off:tiny_off+16] == original[tiny_off:tiny_off+16], 'reference glyph changed'
assert check[0x0800B6A4-FLASH:0x0800B6A4-FLASH+4] == original[0x0800B6A4-FLASH:0x0800B6A4-FLASH+4]
changed = {i for i, (a, b) in enumerate(zip(original, check)) if a != b}
assert changed <= set(range(off, off+20)), f'unexpected changed bytes: {sorted(changed-set(range(off,off+20)))}'
print('output:', OUT)
print('7x10 percent replaced by the selected 5x8 shape enlarged to a square 7x7 mark')
print('changed bytes:', len(changed))
print('sha256:', hashlib.sha256(OUT.read_bytes()).hexdigest())
