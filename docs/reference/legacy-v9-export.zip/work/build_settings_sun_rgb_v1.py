from pathlib import Path
import hashlib
FLASH=0x08000000
SOURCE=Path('work/port-20261006-0747-settings-sun-v1.hex')
OUT=Path('work/port-20261006-0825-settings-sun-rgb-v1.hex')
BASE_SHA='43fff435e717e987107a8442ef94f4b7dd0e75ce4c734186deefd10d570d47d9'

def decode(p):
 im=bytearray([255])*0x10000;u=0
 for l in p.read_text().splitlines():
  if not l.startswith(':'):continue
  r=bytes.fromhex(l[1:]);n,h,lo,t=r[:4];d=r[4:-1]
  if len(d)!=n or sum(r)&255:raise ValueError('bad HEX')
  if t==4:u=int.from_bytes(d,'big')<<16
  elif t==0:im[u+(h<<8)+lo-FLASH:u+(h<<8)+lo-FLASH+n]=d
  elif t==1:break
 return im
def enc(im):
 out=[':020000040800F2']
 for o in range(0,len(im),16):
  d=bytes(im[o:o+16]).ljust(16,b'\xff');b=bytes((16,o>>8,o&255,0))+d
  out.append(':'+ (b+bytes(((-sum(b))&255,))).hex().upper())
 return '\n'.join(out+[':00000001FF',''])
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=decode(SOURCE)
# The known icon is the BA26 raster call in the 0747 build. Paint it via its
# post-raster slot; leave the direct raster dispatcher untouched.
def thumb_bl(at,target):
 delta=target-(at+4); imm=delta&0x1ffffff; s=(imm>>24)&1
 i1=(imm>>23)&1; i2=(imm>>22)&1; j1=1^i1^s; j2=1^i2^s
 return ((0xf000|(s<<10)|((imm>>12)&0x3ff)).to_bytes(2,'little')+
         (0xd000|(j1<<13)|(j2<<11)|((imm>>1)&0x7ff)).to_bytes(2,'little'))
o=0x0800BA2C-FLASH
assert im[o:o+4]==bytes.fromhex('04 F0 D8 FA')
im[o:o+4]=thumb_bl(0x0800BA2C,0x0800F91E)
OUT.write_text(enc(im));check=decode(OUT)
assert check==im and all(sum(bytes.fromhex(x[1:]))&255==0 for x in OUT.read_text().splitlines())
print(OUT);print('sha256',hashlib.sha256(OUT.read_bytes()).hexdigest());print('only known BA26 icon painted red')
