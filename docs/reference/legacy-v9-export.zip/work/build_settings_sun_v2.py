from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261006-0245-date-format-v1.hex')
OUT = Path('work/port-20261006-0750-settings-sun-v2.hex')
BASE_SHA = 'd94c51c189c0b0a9ce5c05a3909a3cf882c46ae9d69300759a6e719ec9c38fc2'

SUN_X_ADD = 0x0800BA1A
SUN_SELECTOR = 0x0800BA24
SUN_RESOURCE = 0x0800BB78       # literal used by the BA26 raster call

def decode(path):
    image = bytearray([0xFF]) * 0x10000
    upper = 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        count, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if len(data) != count or (sum(rec) & 0xFF):
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            start = upper + (hi << 8) + lo - FLASH
            image[start:start + count] = data
        elif typ == 1:
            break
    return image

def encode(image):
    lines = [':020000040800F2']
    for offset in range(0, len(image), 16):
        body = bytes((16, offset >> 8, offset & 0xFF, 0)) + image[offset:offset + 16]
        lines.append(':' + (body + bytes(((-sum(body)) & 0xFF,))).hex().upper())
    lines += [':00000001FF', '']
    return '\n'.join(lines)

assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == BASE_SHA
image = decode(SOURCE)
original = bytes(image)
assert image[SUN_X_ADD-FLASH:SUN_X_ADD-FLASH+2] == bytes.fromhex('4C 32')
assert image[SUN_SELECTOR-FLASH:SUN_SELECTOR-FLASH+2] == bytes.fromhex('0B 20')
assert image[SUN_RESOURCE-FLASH:SUN_RESOURCE-FLASH+4] == bytes.fromhex('2A 03 00 00')

image[SUN_X_ADD-FLASH:SUN_X_ADD-FLASH+2] = bytes.fromhex('50 32')
image[SUN_SELECTOR-FLASH:SUN_SELECTOR-FLASH+2] = bytes.fromhex('11 20')
image[SUN_RESOURCE-FLASH:SUN_RESOURCE-FLASH+4] = bytes.fromhex('F8 0C 00 00')

OUT.write_text(encode(image))
check = decode(OUT)
assert check == image
assert all((sum(bytes.fromhex(line[1:])) & 0xFF) == 0 for line in OUT.read_text().splitlines())
changed = {i for i, (a, b) in enumerate(zip(original, check)) if a != b}
allowed = {SUN_X_ADD-FLASH, SUN_SELECTOR-FLASH, SUN_RESOURCE-FLASH,
           SUN_RESOURCE-FLASH+1}
assert changed == allowed, (changed, allowed)
print(OUT)
print('sha256', hashlib.sha256(OUT.read_bytes()).hexdigest())
print('sun: resource 0x032A -> 0x0CF8; selector 11 -> 17; x 130 -> 134')
