from pathlib import Path
import hashlib
FLASH=0x08000000
SOURCE=Path('work/port-20261006-0815-settings-icons-rgb-v3.hex')
OUT=Path('work/port-20261006-0819-settings-icons-rgb-v4.hex')
BASE_SHA='7cbc56d6678a73be8b1a4671f0a70067eb8fbbff3cd3fcf42b3114d5ba7f0b7d'

def decode(p):
 im=bytearray([255])*0x10000;u=0
 for l in p.read_text().splitlines():
  if not l.startswith(':'):continue
  r=bytes.fromhex(l[1:]);n,h,lo,t=r[:4];d=r[4:-1]
  if len(d)!=n or sum(r)&255:raise ValueError('bad HEX')
  if t==4:u=int.from_bytes(d,'big')<<16
  elif t==0:im[u+(h<<8)+lo-FLASH:u+(h<<8)+lo-FLASH+n]=d
  elif t==1:break
 return im
def enc(im):
 out=[':020000040800F2']
 for o in range(0,len(im),16):
  d=bytes(im[o:o+16]).ljust(16,b'\xff');b=bytes((16,o>>8,o&255,0))+d
  out.append(':'+ (b+bytes(((-sum(b))&255,))).hex().upper())
 return '\n'.join(out+[':00000001FF',''])
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=decode(SOURCE)
# Remove the failed unknown-slot probe; keep its original state update.
im[0x0800BA40-FLASH:0x0800BA44-FLASH]=bytes.fromhex('36 4B 1A 70')
# Permanent red control: the known BA26 icon's safe post-raster slot.
im[0x0800BA2C-FLASH:0x0800BA30-FLASH]=bytes.fromhex('04 F0 D8 FA')
OUT.write_text(enc(im));check=decode(OUT)
assert check==im and all(sum(bytes.fromhex(x[1:]))&255==0 for x in OUT.read_text().splitlines())
print(OUT);print('sha256',hashlib.sha256(OUT.read_bytes()).hexdigest());print('known BA26 control remains painted; unknown slots stock')
