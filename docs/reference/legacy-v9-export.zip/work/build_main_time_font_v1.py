#!/usr/bin/env python3
"""Route only the main radiation and time values through the Medium font."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261005-1751-energy-stats-5x8-v2.hex')
OUT = Path('work/port-20261005-2126-main-time-font-v1.hex')
SOURCE_SHA256 = 'caa155761d4a3fa452ce0cb4f992f79e5698d1a38c3cb89c3caab9915f8febd1'
DRAW_STRING = 0x08008E48
MEDIUM_TABLE = 0x0800F0A8
# This unused punctuation glyph slot stores the tiny argument-adjustment shim.
# It changes only the quote glyph (0x27), not any numeric or letter glyph.
HELPER = 0x0800F1A4
MAIN_CALL = 0x08009252
TIME_CALLS = [
    0x0800D158, 0x0800D17E, 0x0800D1A4,
    0x0800D402, 0x0800D426, 0x0800D44C,
    0x0800D6B6, 0x0800D6DA, 0x0800D6FE,
    0x0800D972, 0x0800D996,
    0x0800DC74, 0x0800DD54,
]
TARGET_CALLS = [MAIN_CALL, *TIME_CALLS]


def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 255:
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError('record outside image')
            image[off:off+n] = data
        elif typ == 1:
            break
    return image


def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])


def thumb_bl(address, target):
    delta = target - (address + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError('BL range/alignment')
    imm = delta & 0x1FFFFFF
    s, i1, i2 = (imm >> 24) & 1, (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = 1 ^ (i1 ^ s), 1 ^ (i2 ^ s)
    h1 = 0xF000 | (s << 10) | ((imm >> 12) & 0x3FF)
    h2 = 0xD000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7FF)
    return h1.to_bytes(2, 'little') + h2.to_bytes(2, 'little')


def thumb_bw(address, target):
    delta = target - (address + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError('B.W range/alignment')
    imm = delta & 0x1FFFFFF
    s, i1, i2 = (imm >> 24) & 1, (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = 1 ^ (i1 ^ s), 1 ^ (i2 ^ s)
    h1 = 0xF000 | (s << 10) | ((imm >> 12) & 0x3FF)
    h2 = 0x9000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7FF)
    return h1.to_bytes(2, 'little') + h2.to_bytes(2, 'little')


def bl_target(image, address):
    off = address - FLASH
    h1 = int.from_bytes(image[off:off+2], 'little')
    h2 = int.from_bytes(image[off+2:off+4], 'little')
    if h1 & 0xF800 != 0xF000 or h2 & 0xD000 != 0xD000:
        return None
    s, j1, j2 = (h1 >> 10) & 1, (h2 >> 13) & 1, (h2 >> 11) & 1
    i1, i2 = 1 ^ (j1 ^ s), 1 ^ (j2 ^ s)
    imm = (s << 24) | (i1 << 23) | (i2 << 22) | ((h1 & 0x3FF) << 12) | ((h2 & 0x7FF) << 1)
    if s:
        imm -= 1 << 25
    return (address + 4 + imm) & 0xFFFFFFFE


def make_helper():
    # Preserve x/y/text/return state. Replace only the size pair and glyph table
    # arguments, then tail-branch to the stock DRAW_STRING implementation.
    code = bytearray()
    code.extend((0x4B03).to_bytes(2, 'little'))  # ldr r3,[pc,#12] -> literal at +16
    code.extend((0x9300).to_bytes(2, 'little'))  # str r3,[sp,#0] -> Medium glyph table
    code.extend((0x2312).to_bytes(2, 'little'))  # movs r3,#18
    code.extend((0x021B).to_bytes(2, 'little'))  # lsls r3,r3,#8
    code.extend((0x330B).to_bytes(2, 'little'))  # adds r3,#11 -> 0x120B
    code.extend(thumb_bw(HELPER + len(code), DRAW_STRING))
    code.extend(bytes.fromhex('00 BF'))         # align literal to +16
    code.extend(MEDIUM_TABLE.to_bytes(4, 'little'))
    if len(code) > 36:
        raise ValueError('helper does not fit one glyph slot')
    code.extend(bytes.fromhex('00 BF') * ((36-len(code)) // 2))
    return bytes(code)


if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
    raise ValueError('accepted base SHA mismatch')
image = decode(SOURCE)
original = bytes(image)
for call in TARGET_CALLS:
    if bl_target(image, call) != DRAW_STRING:
        raise ValueError(f'unexpected renderer target at {call:#x}')

# Ensure helper storage is the documented 11x18 quote glyph slot, not live code.
assert HELPER == MEDIUM_TABLE + (0x27 - 0x20) * 36
helper = make_helper()
image[HELPER-FLASH:HELPER-FLASH+36] = helper
for call in TARGET_CALLS:
    image[call-FLASH:call-FLASH+4] = thumb_bl(call, HELPER)

OUT.write_text(encode(image))
check = decode(OUT)
assert check == image
for line in OUT.read_text().splitlines():
    assert not (sum(bytes.fromhex(line[1:])) & 255)
assert all(bl_target(check, call) == HELPER for call in TARGET_CALLS)

allowed = set(range(HELPER-FLASH, HELPER-FLASH+36))
for call in TARGET_CALLS:
    allowed.update(range(call-FLASH, call-FLASH+4))
changed = {i for i, (a, b) in enumerate(zip(original, check)) if a != b}
assert changed and changed <= allowed, f'unexpected changed addresses: {sorted(changed-allowed)}'
# Protected shared glyphs, descriptors, battery, Small, and Tiny data are untouched.
for code in [*range(0x20, 0x27), *range(0x28, 0x48)]:
    off = MEDIUM_TABLE-FLASH + (code-0x20)*36
    assert check[off:off+36] == original[off:off+36], f'glyph {code:#x} changed'
assert check[0x0800F648-FLASH:0x0800FC00-FLASH] == original[0x0800F648-FLASH:0x0800FC00-FLASH]
assert check[0x0800FCF8-FLASH:0x0800FD18-FLASH] == original[0x0800FCF8-FLASH:0x0800FD18-FLASH]

print('output:', OUT)
print('Localized Medium 11x18 selection at the main radiation and 13 time-value calls.')
print('All other draw calls, numeric glyphs, battery, Small/Tiny, and descriptors unchanged.')
print('changed bytes:', len(changed), 'sha256:', hashlib.sha256(OUT.read_bytes()).hexdigest())
