from pathlib import Path
import hashlib

FLASH=0x08000000
SOURCE=Path('work/port-20261006-0756-settings-icons-v1.hex')
OUT=Path('work/port-20261006-0759-settings-sun-v2.hex')
BASE_SHA='8b26ccc205ed6e8d634f4c45d642fb7d9c571c5d4e35eee9ac32f3ba8f427a7c'

def decode(path):
    im=bytearray([0xFF])*0x10000; upper=0
    for line in path.read_text().splitlines():
        if not line.startswith(':'): continue
        r=bytes.fromhex(line[1:]); n,hi,lo,t=r[:4]; d=r[4:-1]
        if len(d)!=n or sum(r)&255: raise ValueError('bad HEX')
        if t==4: upper=int.from_bytes(d,'big')<<16
        elif t==0:
            o=upper+(hi<<8)+lo-FLASH; im[o:o+n]=d
        elif t==1: break
    return im

def encode(im):
    out=[':020000040800F2']
    for o in range(0,len(im),16):
        data=bytes(im[o:o+16]).ljust(16,b'\xff')
        b=bytes((16,o>>8,o&255,0))+data
        out.append(':'+ (b+bytes(((-sum(b))&255,))).hex().upper())
    return '\n'.join(out+[':00000001FF',''])

assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=decode(SOURCE); before=bytes(im)
def put(addr, data):
    b=bytes.fromhex(data)
    im[addr-FLASH:addr-FLASH+len(b)]=b

# The working Settings-page sun is the 12x12 resource at 0x0364, selector 22.
# B9EE (center), BA0A (left) and BA26 (right) each get their own selector;
# BB74/BB78 are their resource-offset literals.
put(0x0800B9EC,'16 20')
put(0x0800BA08,'16 20')
put(0x0800BA24,'16 20')
put(0x0800BB74,'64 03 00 00')
put(0x0800BB78,'64 03 00 00')

# Make the two larger tiles 12x12 and center the raster in their old tiles.
put(0x0800B9F4,'0C 22')
put(0x0800B9F8,'0A 32')
put(0x0800B9FE,'10 3A')
put(0x0800BA10,'0C 22')
put(0x0800BA16,'3A 32')

OUT.write_text(encode(im)); check=decode(OUT)
assert check==im and all(sum(bytes.fromhex(x[1:]))&255==0 for x in OUT.read_text().splitlines())
changed={i for i,(a,b) in enumerate(zip(before,check)) if a!=b}
assert len(changed)==10, changed
print(OUT)
print('sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
print('three icons: B9EE/BA0A/BA26 -> sun resource 0x0364 selector 22')
