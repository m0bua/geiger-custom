from pathlib import Path
import hashlib
FLASH=0x08000000
SOURCE=Path('work/port-20261006-0245-date-format-v1.hex')
OUT=Path('work/port-20261006-0249-date-format-v2.hex')
BASE_SHA='d94c51c189c0b0a9ce5c05a3909a3cf882c46ae9d69300759a6e719ec9c38fc2'
PTR=0x0800AB14
FULL=0x0800EFE8

def dec(p):
 im=bytearray([255])*0x10000;up=0
 for l in p.read_text().splitlines():
  if not l.startswith(':'):continue
  r=bytes.fromhex(l[1:]);n,hi,lo,t=r[:4];d=r[4:-1]
  if len(d)!=n or sum(r)&255:raise ValueError('bad hex')
  if t==4:up=int.from_bytes(d,'big')<<16
  elif t==0:
   off=up+(hi<<8)+lo-FLASH
   if not 0<=off<=len(im)-n:raise ValueError('outside')
   im[off:off+n]=d
  elif t==1:break
 return im[:0x10000]
def enc(im):
 a=[':020000040800F2']
 for o in range(0,len(im),16):
  r=bytes([16,o>>8,o&255,0])+im[o:o+16];a.append(':'+(r+bytes([(-sum(r))&255])).hex().upper())
 return '\n'.join(a+[':00000001FF',''])
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=dec(SOURCE);old=bytes(im)
# The page's date formatter pointer literal.
p=PTR-FLASH;assert int.from_bytes(im[p:p+4],'little')==0x0800F024
im[p:p+4]=FULL.to_bytes(4,'little')
# Same 15-byte footprint as the existing full date format.
f=FULL-FLASH;assert im[f:f+15]==b'%02d/%02d/%02d\0'
im[f:f+15]=b'%04d.%02d.%02d\0'
OUT.write_text(enc(im));chk=dec(OUT);assert chk==im
assert all(not(sum(bytes.fromhex(l[1:]))&255) for l in OUT.read_text().splitlines())
changed={i for i,(a,b) in enumerate(zip(old,chk))if a!=b};assert changed <= set(range(p,p+4))|set(range(f,f+15))
print(OUT);print('date formatter: %04d.%02d.%02d; page now points to full formatter');print('sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
