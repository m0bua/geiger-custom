from pathlib import Path
import hashlib
FLASH=0x08000000
SOURCE=Path('work/port-20261006-0203-settings-layout-v1.hex')
OUT=Path('work/port-20261006-0238-time-page-v5.hex')
BASE_SHA='40b07cdffc773c4038164a47143e8057d15bae0da82141154bbd8985739738be'
DRAW=0x08008E48; SMALL=0x0800F648; HELPER=0x0800F1B0
TIME_X=0x0800AAD0; DATE_CALL=0x0800AAE8

def decode(path):
 im=bytearray([255])*0x10000;up=0
 for line in path.read_text().splitlines():
  if not line.startswith(':'):continue
  rec=bytes.fromhex(line[1:]);n,hi,lo,t=rec[:4];d=rec[4:-1]
  if len(d)!=n or sum(rec)&255:raise ValueError('bad Intel HEX')
  if t==4:up=int.from_bytes(d,'big')<<16
  elif t==0:
   off=up+(hi<<8)+lo-FLASH; im[off:off+n]=d
  elif t==1:break
 return im

def encode(im):
 out=[':020000040800F2']
 for off in range(0,len(im),16):
  rec=bytes([16,off>>8,off&255,0])+im[off:off+16]
  out.append(':'+(rec+bytes([(-sum(rec))&255])).hex().upper())
 return '\n'.join(out+[':00000001FF',''])
def bl(src,dst):
 d=dst-(src+4);x=d&0x1ffffff;s=x>>24&1;i1=x>>23&1;i2=x>>22&1;j1=1^(i1^s);j2=1^(i2^s)
 return (0xf000|(s<<10)|((x>>12)&1023)).to_bytes(2,'little')+(0xd000|(j1<<13)|(j2<<11)|((x>>1)&2047)).to_bytes(2,'little')
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=decode(SOURCE);old=bytes(im)
assert im[TIME_X-FLASH:TIME_X-FLASH+2]==bytes.fromhex('44 20')
im[TIME_X-FLASH:TIME_X-FLASH+2]=bytes.fromhex('54 20') # 68 -> 84
assert im[DATE_CALL-FLASH:DATE_CALL-FLASH+4]==bl(DATE_CALL,DRAW)
# Proven tail-adapter ABI: preserve caller args, replace saved table/dims/LR.
code=bytearray.fromhex('0F B5')
code += bytes.fromhex('04 48 05 90') # ldr r0,[pc,#16] -> Small table literal; str [sp,#20]
code += bytes.fromhex('04 48 03 90') # dims literal
code += bytes.fromhex('04 48 04 90') # DRAW+1 literal
code += bytes.fromhex('0F BC 00 BD')
# align literal pool at helper+16; three literals
while len(code)<22: code += bytes.fromhex('00 BF')
code += SMALL.to_bytes(4,'little')
code += (0x0A07).to_bytes(4,'little')
code += (DRAW+1).to_bytes(4,'little')
assert len(code)==34
im[HELPER-FLASH:HELPER-FLASH+len(code)]=code
im[DATE_CALL-FLASH:DATE_CALL-FLASH+4]=bl(DATE_CALL,HELPER)
OUT.write_text(encode(im));check=decode(OUT);assert check==im
assert all(not(sum(bytes.fromhex(x[1:]))&255) for x in OUT.read_text().splitlines())
changed={i for i,(a,b) in enumerate(zip(old,check))if a!=b};allowed=set(range(TIME_X-FLASH,TIME_X-FLASH+2))|set(range(DATE_CALL-FLASH,DATE_CALL-FLASH+4))|set(range(HELPER-FLASH,HELPER-FLASH+34));assert changed<=allowed
print(OUT);print('time x 68 -> 84; date Small tail adapter 7x10');print('sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
