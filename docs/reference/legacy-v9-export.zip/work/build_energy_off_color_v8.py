from pathlib import Path
import hashlib
FLASH=0x08000000
SOURCE=Path('work/port-20261005-1751-energy-stats-5x8-v2.hex')
OUT=Path('work/port-20261006-0010-energy-off-color-v8.hex')
BASE_SHA='caa155761d4a3fa452ce0cb4f992f79e5698d1a38c3cb89c3caab9915f8febd1'
CALL=0x0800E0E6
DRAW_STRING=0x08008E48
FILL=0x08008ECC
HELPER=0x0800F118
RED=0xF800

def decode(path):
 image=bytearray([255])*0x10000; upper=0
 for line in path.read_text().splitlines():
  if not line.startswith(':'): continue
  rec=bytes.fromhex(line[1:]); n,hi,lo,typ=rec[:4]; data=rec[4:-1]
  if n!=len(data) or sum(rec)&255: raise ValueError('bad Intel HEX record')
  if typ==4: upper=int.from_bytes(data,'big')<<16
  elif typ==0:
   off=upper+(hi<<8)+lo-FLASH
   if off<0 or off+n>len(image): raise ValueError('out of range')
   image[off:off+n]=data
  elif typ==1: break
 return image

def encode(image):
 lines=[':020000040800F2']
 for off in range(0,len(image),16):
  rec=bytes([16,off>>8,off&255,0])+image[off:off+16]
  lines.append(':'+ (rec+bytes([(-sum(rec))&255])).hex().upper())
 return '\n'.join(lines+[':00000001FF',''])

def bl(addr,target):
 d=target-(addr+4)
 if d&1 or not -(1<<24)<=d<(1<<24): raise ValueError('branch range')
 x=d&0x1ffffff;s=(x>>24)&1;i1=(x>>23)&1;i2=(x>>22)&1;j1=1^(i1^s);j2=1^(i2^s)
 return (0xf000|(s<<10)|((x>>12)&1023)).to_bytes(2,'little')+(0xd000|(j1<<13)|(j2<<11)|((x>>1)&2047)).to_bytes(2,'little')

def target(image,addr):
 i=addr-FLASH;h1=int.from_bytes(image[i:i+2],'little');h2=int.from_bytes(image[i+2:i+4],'little')
 if h1&0xf800!=0xf000 or h2&0xd000!=0xd000:return None
 s=h1>>10&1;j1=h2>>13&1;j2=h2>>11&1;i1=1^(j1^s);i2=1^(j2^s)
 imm=(s<<24)|(i1<<23)|(i2<<22)|((h1&1023)<<12)|((h2&2047)<<1)
 if s:imm-=1<<25
 return (addr+4+imm)&0xffffffff

assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=decode(SOURCE); orig=bytes(im)
assert target(im,CALL)==DRAW_STRING
assert im[HELPER-FLASH:HELPER-FLASH+24]==bytes([255])*24
# Fixed red swatch at the candidate call at its x origin (30), diagnostic y=30.
helper=(bytes.fromhex('00 B5 81 B0 03 4B 00 93 28 22 12 23')+bl(HELPER+12,FILL)+bytes.fromhex('01 B0 00 BD')+RED.to_bytes(4,'little'))
assert len(helper)==24
im[HELPER-FLASH:HELPER-FLASH+24]=helper
setup=CALL-FLASH-6
im[setup:setup+6]=bytes.fromhex('1E 20 1E 21 00 22')
im[CALL-FLASH:CALL-FLASH+4]=bl(CALL,HELPER)
OUT.write_text(encode(im))
check=decode(OUT);assert check==im
for line in OUT.read_text().splitlines():
 if line.startswith(':') and sum(bytes.fromhex(line[1:]))&255: raise ValueError('bad checksum')
changed={i for i,(a,b) in enumerate(zip(orig,check)) if a!=b}
allowed=set(range(HELPER-FLASH,HELPER-FLASH+24))|set(range(CALL-FLASH-6,CALL-FLASH+4))
assert changed<=allowed
print('output',OUT,'changed_bytes',len(changed),'sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
print('candidate',hex(CALL),'original renderer',hex(DRAW_STRING),'red 40x18 at (30,30)')
