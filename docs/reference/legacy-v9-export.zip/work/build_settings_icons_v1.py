from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261006-0245-date-format-v1.hex')
ORIGINAL = Path('work/Port-4.1.17(2).hex')
OUT = Path('work/port-20261006-0756-settings-icons-v1.hex')
BASE_SHA = 'd94c51c189c0b0a9ce5c05a3909a3cf882c46ae9d69300759a6e719ec9c38fc2'

def decode(path):
    image = bytearray([0xFF]) * 0x10000
    upper = 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        count, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if len(data) != count or (sum(rec) & 0xFF):
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            start = upper + (hi << 8) + lo - FLASH
            image[start:start + count] = data
        elif typ == 1:
            break
    return image

def encode(image):
    lines = [':020000040800F2']
    for offset in range(0, len(image), 16):
        body = bytes((16, offset >> 8, offset & 0xFF, 0)) + image[offset:offset + 16]
        lines.append(':' + (body + bytes(((-sum(body)) & 0xFF,))).hex().upper())
    lines += [':00000001FF', '']
    return '\n'.join(lines)

assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == BASE_SHA
image = decode(SOURCE)
original_base = bytes(image)
stock = decode(ORIGINAL)

# These are the three post-raster state updates in the SOUND/DIODE/RES menu.
# The accepted base replaced them with text-helper calls; restore stock bytes.
ranges = [(0x0800BA2C, 0x0800BA30),
          (0x0800BA42, 0x0800BA46),
          (0x0800BA4A, 0x0800BA4E)]
for start, end in ranges:
    a, b = start - FLASH, end - FLASH
    image[a:b] = stock[a:b]

OUT.write_text(encode(image))
check = decode(OUT)
assert check == image
assert all((sum(bytes.fromhex(line[1:])) & 0xFF) == 0 for line in OUT.read_text().splitlines())
changed = {i for i, (a, b) in enumerate(zip(original_base, check)) if a != b}
allowed = set()
for start, end in ranges:
    allowed.update(range(start - FLASH, end - FLASH))
assert changed == allowed, (changed, allowed)
print(OUT)
print('sha256', hashlib.sha256(OUT.read_bytes()).hexdigest())
print('restored stock post-raster updates at BA2C, BA40 and BA48')
