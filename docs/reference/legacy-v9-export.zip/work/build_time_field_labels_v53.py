#!/usr/bin/env python3
"""Draw compact labels over the active TIME-menu fields from v51."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261005-1350-time-unknown-calls-disabled-v51.hex')
OUT = Path('work/port-20261005-1450-time-field-labels-v53.hex')
SOURCE_SHA256 = '4088db379e517155a9a82e332f5d768ca9fda6262d41a930ad34f39d021ab3b6'
HELPER = 0x0800F970
TABLE = 0x0800F9AC
FONT = 0x0800F648

# One confirmed active field per TIME-menu state. These calls run after the tile fill.
ACTIVE_FIELDS = [
    ('HR',  0x0800D064, 5, 73),
    ('MIN', 0x0800D2D6, 6, 70),
    ('DAY', 0x0800D590, 7, 70),
    ('MON', 0x0800D842, 8, 70),
    ('YR',  0x0800DAA4, 9, 73),
]
SETTINGS_SELECTOR_REMAP = {0x0800B430: 3, 0x0800B4D2: 4, 0x0800B4F6: 4}

def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 0xFF:
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError('record outside firmware image')
            image[off:off+n] = data
        elif typ == 1:
            break
    return image

def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 0xFF, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 0xFF])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])

def thumb_bl(address, target):
    delta = target - (address + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError('Thumb BL out of range')
    imm = delta & 0x1FFFFFF
    s, i1, i2 = (imm >> 24) & 1, (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = 1 ^ (i1 ^ s), 1 ^ (i2 ^ s)
    h1 = 0xF000 | (s << 10) | ((imm >> 12) & 0x3FF)
    h2 = 0xD000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7FF)
    return h1.to_bytes(2, 'little') + h2.to_bytes(2, 'little')

def bl_target(image, address):
    off = address - FLASH
    h1 = int.from_bytes(image[off:off+2], 'little')
    h2 = int.from_bytes(image[off+2:off+4], 'little')
    if h1 & 0xF800 != 0xF000 or h2 & 0xD000 != 0xD000:
        return None
    s, j1, j2 = (h1 >> 10) & 1, (h2 >> 13) & 1, (h2 >> 11) & 1
    i1, i2 = 1 ^ (j1 ^ s), 1 ^ (j2 ^ s)
    imm = (s << 24) | (i1 << 23) | (i2 << 22) | ((h1 & 0x3FF) << 12) | ((h2 & 0x7FF) << 1)
    if s:
        imm -= 1 << 25
    return (address + 4 + imm) & 0xFFFFFFFF

def glyph(rows):
    if len(rows) != 10 or any(len(row) != 7 for row in rows):
        raise ValueError('expected a 7x10 glyph')
    out = bytearray()
    for row in rows:
        bits = sum((c == '#') << (15-i) for i, c in enumerate(row))
        out.extend(bits.to_bytes(2, 'little'))
    return bytes(out)

def glyph_addr(code):
    return FONT + 20 * (code - 0x20)

if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
    raise ValueError('v51 SHA-256 mismatch')
image = decode(SOURCE)
original = bytes(image)

# Preserve C and O in previously unused slots before changing their former slots to A and H.
original_c = original[glyph_addr(0x29)-FLASH:glyph_addr(0x29)-FLASH+20]
original_o = original[glyph_addr(0x3C)-FLASH:glyph_addr(0x3C)-FLASH+20]
image[glyph_addr(0x2D)-FLASH:glyph_addr(0x2D)-FLASH+20] = original_c  # C
image[glyph_addr(0x2B)-FLASH:glyph_addr(0x2B)-FLASH+20] = original_o  # O
new_glyphs = {
    0x26: ['#...#..','#...#..','.#.#...','..#....','..#....','..#....','..#....','.......','.......','.......'], # Y
    0x28: ['####...','#...#..','#...#..','#...#..','#...#..','#...#..','####...','.......','.......','.......'], # D
    0x29: ['.###...','#...#..','#...#..','#####..','#...#..','#...#..','#...#..','.......','.......','.......'], # A
    0x3B: ['#####..','..#....','..#....','..#....','..#....','..#....','#####..','.......','.......','.......'], # I
    0x3C: ['#...#..','#...#..','#...#..','#####..','#...#..','#...#..','#...#..','.......','.......','.......'], # H
}
for code, rows in new_glyphs.items():
    addr = glyph_addr(code)
    image[addr-FLASH:addr-FLASH+20] = glyph(rows)

# The existing helper uses selector*4. Five compact TIME labels fit beside the five
# unique SETTINGS strings. Selectors above 4 use the existing lower-row y coordinate.
assert image[0xF97E:0xF980] == bytes.fromhex('06 2C'), 'unexpected SETTINGS helper layout'
image[0xF97E:0xF980] = bytes.fromhex('04 2C')
strings = (
    bytes.fromhex('3D 41 00 00') +  # Sv
    bytes.fromhex('2D 42 27 00') +  # CPM; C moved to 0x2D
    bytes.fromhex('22 00 00 00') +  # R
    bytes.fromhex('2B 21 00 00') +  # ON; O moved to 0x2B
    bytes.fromhex('2B 2A 2A 00') +  # OFF
    bytes.fromhex('3C 22 00 00') +  # HR
    bytes.fromhex('27 3B 21 00') +  # MIN
    bytes.fromhex('28 29 26 00') +  # DAY
    bytes.fromhex('27 2B 21 00') +  # MON
    bytes.fromhex('26 22 00 00')    # YR
)
assert len(strings) == 40
image[TABLE-FLASH:TABLE-FLASH+40] = strings

# Update known persistent 7x10 C strings outside the SETTINGS helper.
assert original[0x0800A74E-FLASH:0x0800A752-FLASH] == bytes.fromhex('29 42 27 00'), 'main CPM string changed'
assert original[0x0800F940-FLASH:0x0800F944-FLASH] == bytes.fromhex('29 21 25 00'), 'dose CNT string changed'
image[0x0800A74E-FLASH] = 0x2D
image[0x0800F940-FLASH] = 0x2D

for call, selector in SETTINGS_SELECTOR_REMAP.items():
    off = call - FLASH
    assert bl_target(original, call) == HELPER, f'unexpected SETTINGS helper target at {call:#x}'
    image[off-6:off-4] = (0x2000 | selector).to_bytes(2, 'little')

# The two instructions immediately before each raster call only select its resource.
# Reuse them for selector/x, then call the already-proven 7x10 renderer.
for _name, call, selector, x in ACTIVE_FIELDS:
    off = call - FLASH
    assert bl_target(original, call) == 0x0800AFE4, f'unexpected field target at {call:#x}'
    image[off-4:off-2] = (0x2000 | selector).to_bytes(2, 'little')
    image[off-2:off] = (0x2100 | x).to_bytes(2, 'little')
    image[off:off+4] = thumb_bl(call, HELPER)

OUT.write_text(encode(image))
check = decode(OUT)
assert check == image, 'Intel HEX round-trip mismatch'
for line in OUT.read_text().splitlines():
    assert not (sum(bytes.fromhex(line[1:])) & 0xFF), 'bad Intel HEX checksum'
assert check[0x0800B6A4-FLASH:0x0800B6A4-FLASH+4] == original[0x0800B6A4-FLASH:0x0800B6A4-FLASH+4], 'units icon changed'
for _name, call, _selector, _x in ACTIVE_FIELDS:
    assert bl_target(check, call) == HELPER
changed = {i for i,(a,b) in enumerate(zip(original, check)) if a != b}
allowed = set(range(0xF97E,0xF980)) | set(range(TABLE-FLASH,TABLE-FLASH+40))
for code in [0x26,0x28,0x29,0x3B,0x3C,0x2B,0x2D]:
    allowed.update(range(glyph_addr(code)-FLASH,glyph_addr(code)-FLASH+20))
allowed.update([0x0800A74E-FLASH,0x0800F940-FLASH])
for call in SETTINGS_SELECTOR_REMAP:
    allowed.update(range(call-FLASH-6,call-FLASH-4))
for _name, call, _selector, _x in ACTIVE_FIELDS:
    allowed.update(range(call-FLASH-4,call-FLASH+4))
assert changed <= allowed, f'unexpected changes: {sorted(changed-allowed)}'
print('output:', OUT)
print('field labels: HR / MIN / DAY / MON / YR')
print('changed bytes:',len(changed))
print('sha256:',hashlib.sha256(OUT.read_bytes()).hexdigest())
