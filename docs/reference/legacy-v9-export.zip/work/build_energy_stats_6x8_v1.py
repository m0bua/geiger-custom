#!/usr/bin/env python3
"""Replace Tiny 5x8 glyphs with Small-derived 6x8 glyphs for numeric screens."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261005-1725-main-percent-v2.hex')
OUT = Path('work/port-20261005-1751-energy-stats-6x8-v1.hex')
SOURCE_SHA256 = 'd3f75a27db5b45b9896510e14e1cdd6ea9cab93da08c29cb137cb81551ae1989'

SMALL_TABLE = 0x0800F648
SMALL_PERIOD = SMALL_TABLE + 14 * 20       # Small byte 0x2E
SMALL_DIGITS = SMALL_TABLE + 16 * 20        # Small bytes 0x30..0x39
SMALL_PERCENT = 0x0800F904                  # Small extension byte 0x43
TINY_TABLE = 0x0800F9D4
TINY_DESCRIPTOR = 0x0800FD10
GLYPH_COUNT = 12


def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 0xFF:
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError('record outside firmware image')
            image[off:off+n] = data
        elif typ == 1:
            break
    return image


def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])


def unpack_7x10(data):
    assert len(data) == 20
    rows = []
    for y in range(10):
        word = int.from_bytes(data[2*y:2*y+2], 'little')
        rows.append([bool(word & (0x8000 >> x)) for x in range(7)])
    return rows


def resize_7x10_to_6x8(rows):
    # Center-sampled nearest neighbor: preserves the pixel style and glyph edges.
    return [[rows[min(9, int((y + 0.5) * 10 / 8))]
             [min(6, int((x + 0.5) * 7 / 6))]
             for x in range(6)] for y in range(8)]


def pack_6x8(rows):
    assert len(rows) == 8 and all(len(row) == 6 for row in rows)
    out = bytearray()
    for row in rows:
        word = sum(bool(pixel) << (15-x) for x, pixel in enumerate(row))
        out.extend(word.to_bytes(2, 'little'))
    return bytes(out)


if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
    raise ValueError('accepted main-percent-v2 SHA-256 mismatch')
image = decode(SOURCE)
original = bytes(image)

def glyph(addr):
    off = addr - FLASH
    return resize_7x10_to_6x8(unpack_7x10(bytes(image[off:off+20])))

# Preserve Tiny's input-code ordering: 0x20 period, 0x21 percent,
# 0x22..0x2B digits 0..9. Only the source shapes come from Small.
glyphs = [glyph(SMALL_PERIOD), glyph(SMALL_PERCENT)]
glyphs.extend(glyph(SMALL_DIGITS + i*20) for i in range(10))
table = b''.join(pack_6x8(g) for g in glyphs)
assert len(table) == GLYPH_COUNT * 16

table_off = TINY_TABLE - FLASH
image[table_off:table_off+len(table)] = table
desc_off = TINY_DESCRIPTOR - FLASH
old_desc = bytes(image[desc_off:desc_off+8])
assert old_desc == bytes.fromhex('05 08 00 00 D4 F9 00 08')
image[desc_off:desc_off+2] = bytes([6, 8])

OUT.write_text(encode(image))
check = decode(OUT)
assert check == image, 'Intel HEX round-trip mismatch'
for line in OUT.read_text().splitlines():
    assert not (sum(bytes.fromhex(line[1:])) & 255), 'bad Intel HEX checksum'

changed = {i for i, (a, b) in enumerate(zip(original, check)) if a != b}
allowed = set(range(table_off, table_off+len(table))) | set(range(desc_off, desc_off+2))
assert changed <= allowed, f'unexpected changes: {sorted(changed-allowed)}'
assert check[desc_off:desc_off+8] == bytes.fromhex('06 08 00 00 D4 F9 00 08')
assert check[table_off:table_off+len(table)] == table
print('output:', OUT)
print('Tiny input codes retained; Small glyphs resized 7x10 -> 6x8: digits, period, percent')
print('changed bytes:', len(changed), '(only 12 glyphs and Tiny width byte)')
print('sha256:', hashlib.sha256(OUT.read_bytes()).hexdigest())
