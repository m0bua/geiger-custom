from pathlib import Path
import hashlib

FLASH=0x08000000
SOURCE=Path('work/port-20261006-0756-settings-icons-v1.hex')
OUT=Path('work/port-20261006-0805-settings-icons-rgb-v1.hex')
BASE_SHA='8b26ccc205ed6e8d634f4c45d642fb7d9c571c5d4e35eee9ac32f3ba8f427a7c'

def decode(path):
    im=bytearray([255])*0x10000; upper=0
    for line in path.read_text().splitlines():
        if not line.startswith(':'): continue
        r=bytes.fromhex(line[1:]); n,h,lo,t=r[:4]; d=r[4:-1]
        if len(d)!=n or sum(r)&255: raise ValueError('bad Intel HEX')
        if t==4: upper=int.from_bytes(d,'big')<<16
        elif t==0:
            o=upper+(h<<8)+lo-FLASH; im[o:o+n]=d
        elif t==1: break
    return im

def encode(im):
    out=[':020000040800F2']
    for o in range(0,len(im),16):
        d=bytes(im[o:o+16]).ljust(16,b'\xff')
        b=bytes((16,o>>8,o&255,0))+d
        out.append(':'+ (b+bytes(((-sum(b))&255,))).hex().upper())
    return '\n'.join(out+[':00000001FF',''])

assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=decode(SOURCE); before=bytes(im)

# BA2C is the previously identified first icon probe. These two corresponding
# post-raster slots are the two still-unknown icon records.
for addr in (0x0800BA40,0x0800BA48):
    off=addr-FLASH
    assert im[off:off+4]==bytes.fromhex('36 4B 1A 70' if addr==0x0800BA40 else '01 22 1A 70')
    im[off:off+4]=bytes.fromhex('04 F0 D8 FA')

OUT.write_text(encode(im)); check=decode(OUT)
assert check==im
assert all(sum(bytes.fromhex(x[1:]))&255==0 for x in OUT.read_text().splitlines())
changed={i for i,(a,b) in enumerate(zip(before,check)) if a!=b}
assert changed==set(range(0xBA40,0xBA44))|set(range(0xBA48,0xBA4C)),changed
print(OUT)
print('sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
print('RGB probe: unknown icon slots BA40 and BA48 -> fill helper; BA2C remains first confirmed probe')
