# Renderer scaling experiment — 2026-10-05

## Current working baseline

Use `port-20261005-1751-energy-stats-5x8-v2.hex` as the accepted firmware baseline.
SHA-256: `caa155761d4a3fa452ce0cb4f992f79e5698d1a38c3cb89c3caab9915f8febd1`.
The baseline file was not modified. Renderer scaling is paused.

## Findings to retain

- Generic text renderer: `0x08008E48`.
- Monochrome glyph rasterizer: `0x08008D64`.
- `0x0800F0CC` is active executable code, not a free font-table slot. Thirteen calls target it: `0x0800D064`, `0x0800D084`, `0x0800D2D6`, `0x0800D2FC`, `0x0800D31C`, `0x0800D590`, `0x0800D5B6`, `0x0800D5D6`, `0x0800D842`, `0x0800D868`, `0x0800D888`, `0x0800DAA4`, `0x0800DAC4`. Overwriting it causes reboots in the clock/energy menus.
- Medium-font alias glyphs are stored at the addresses used for `Y`, `D`, `A`, and `I` substitutions. Placing the experimental helper at `0x0800F180` overwrote those glyphs; the device then lost those letters.
- v4 placed code back at `0x0800F0CC`; this overwrote the active helper and rebooted the menus again. Do not reuse that address for new code.
- Experimental v3’s synthetic Thumb emulation did confirm the generated 16×27 row buffers for `0–9`, `.`, `:`, `/`, assuming an 11×18 source. This did not prove that the target device displayed the enlarged glyphs; the user observed no visible size increase.
- The experiment corrected two helper bugs in the emulator model: source glyph rows use bit 10 as the leftmost pixel in the 11-bit glyph, and the rasterizer’s x coordinate must be loaded after setting its stack color arguments. These are useful implementation notes but do not validate a device build.

## Failed candidates

- `port-20261005-2144-render-scale-v1.hex`: helper overwrote active code at `0x0800F0CC`; menus rebooted; no visible scaling.
- `port-20261005-2144-render-scale-v2.hex`: still used the same active-code location; isolating the call sites did not fix the behavior.
- `port-20261005-2144-render-scale-v3.hex`: helper was moved to `0x0800F180`, so the reboot stopped, but the `Y/D/A/I` aliases were overwritten and the user saw no size increase.
- `port-20261005-2144-render-scale-v4.hex`: moved code back over the active function at `0x0800F0CC`; reboot returned and scaling remained invisible.

Do not use v1–v4 as the working firmware.

## Next attempt

Resume from the accepted baseline above. Do not place helper code over `0x0800F0CC`, the Y/D/A/I alias glyphs, or other active glyph data. A future scaling attempt needs to modify the existing renderer/rasterizer in place or first establish a genuinely safe code region and verify the actual call path on device. Require visible/device-level confirmation before treating scaling as successful.
