#!/usr/bin/env python3
"""Make a square-ish 11x18 percent from v8's 5x8 reference glyph."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261005-1700-time-labels-v8.hex')
OUT = Path('work/port-20261005-1714-main-percent-v1.hex')
SOURCE_SHA256 = '9caf2b625bca4798eee595e906fcce6ef597ec0509dd270535143a811cf06b12'
HELPER = 0x0800F0CC
HELPER_END = 0x0800F138
MEDIUM_PERCENT = 0x0800F138  # glyph code 0x24
STRINGS_OLD = 0x0800F138
STRINGS_NEW = 0x0800F15C  # unused '&' glyph slot
TINY_REFERENCE = 0x0800F9E4  # user-selected 5x8 shape (byte 0x21)

def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 0xFF:
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError('record outside firmware image')
            image[off:off+n] = data
        elif typ == 1:
            break
    return image

def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 0xFF])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])

def pixels_5x8(data):
    rows = []
    for y in range(8):
        word = int.from_bytes(data[2*y:2*y+2], 'little')
        rows.append([bool(word & (0x8000 >> x)) for x in range(5)])
    return rows

def pack_11x18(rows):
    if len(rows) != 18 or any(len(row) != 11 for row in rows):
        raise ValueError('expected 11x18 glyph')
    out = bytearray()
    for row in rows:
        bits = sum((bool(pixel) << (15-x)) for x, pixel in enumerate(row))
        out.extend(bits.to_bytes(2, 'little'))
    return bytes(out)

if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
    raise ValueError('v8 SHA-256 mismatch')
image = decode(SOURCE)
original = bytes(image)

# Move the five 4-byte time-label strings out of the medium % glyph slot.
old_off = STRINGS_OLD - FLASH
new_off = STRINGS_NEW - FLASH
strings = bytes(image[old_off:old_off+20])
assert len(strings) == 20
helper = bytes(image[HELPER-FLASH:HELPER_END-FLASH])
old_ptr = (STRINGS_OLD).to_bytes(4, 'little')
new_ptr = (STRINGS_NEW).to_bytes(4, 'little')
assert helper.count(old_ptr) == 1, 'expected one string-table pointer in the TIME helper'
helper_off = HELPER - FLASH + helper.index(old_ptr)
image[helper_off:helper_off+4] = new_ptr
image[new_off:new_off+20] = strings

# The selected 5x8 glyph has a 5x5 active bitmap. Enlarge each pixel 2x2,
# producing a centered 10x10 mark in the 11x18 medium-font cell.
tiny_off = TINY_REFERENCE - FLASH
tiny = pixels_5x8(bytes(image[tiny_off:tiny_off+16]))
expected_rows = [
    '.....', '##..#', '##.#.', '..#..', '.#.##', '#..##', '.....', '.....'
]
assert [''.join('#' if p else '.' for p in row) for row in tiny] == expected_rows, 'reference glyph differs from the supplied sample'
ys = [y for y in range(8) if any(tiny[y])]
xs = [x for x in range(5) if any(tiny[y][x] for y in range(8))]
assert (min(xs), max(xs), min(ys), max(ys)) == (0, 4, 1, 5)
glyph_rows = [[False] * 11 for _ in range(18)]
x0 = (11 - 2*len(xs)) // 2
y0 = (18 - 2*len(ys)) // 2
for sy in ys:
    for sx in xs:
        if tiny[sy][sx]:
            for dy in range(2):
                for dx in range(2):
                    glyph_rows[y0 + 2*(sy-min(ys)) + dy][x0 + 2*(sx-min(xs)) + dx] = True
glyph = pack_11x18(glyph_rows)
image[MEDIUM_PERCENT-FLASH:MEDIUM_PERCENT-FLASH+36] = glyph

OUT.write_text(encode(image))
check = decode(OUT)
assert check == image, 'Intel HEX round-trip mismatch'
for line in OUT.read_text().splitlines():
    assert not (sum(bytes.fromhex(line[1:])) & 0xFF), 'bad Intel HEX checksum'
assert check[HELPER-FLASH:HELPER-FLASH+len(helper)] != helper, 'TIME helper pointer was not updated'
assert check[new_off:new_off+20] == strings, 'TIME strings did not move intact'
assert check[MEDIUM_PERCENT-FLASH:MEDIUM_PERCENT-FLASH+36] == glyph
assert check[tiny_off:tiny_off+16] == original[tiny_off:tiny_off+16], 'tiny reference glyph changed'
changed = {i for i, (a, b) in enumerate(zip(original, check)) if a != b}
allowed = (
    set(range(helper_off, helper_off+4))
    | set(range(new_off, new_off+20))
    | set(range(MEDIUM_PERCENT-FLASH, MEDIUM_PERCENT-FLASH+36))
)
assert changed <= allowed, f'unexpected changed bytes: {sorted(changed-allowed)}'
print('output:', OUT)
print('medium %: 11x18 cell, 10x10 active pixels from the selected 5x8 shape')
print('TIME label strings moved intact from % slot to unused & slot')
print('changed bytes:', len(changed))
print('sha256:', hashlib.sha256(OUT.read_bytes()).hexdigest())
