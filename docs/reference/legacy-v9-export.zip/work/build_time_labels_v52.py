#!/usr/bin/env python3
"""Add compact English labels to the five TIME-menu states from v51."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261005-1350-time-unknown-calls-disabled-v51.hex')
OUT = Path('work/port-20261005-1430-time-labels-v52.hex')
SOURCE_SHA256 = '4088db379e517155a9a82e332f5d768ca9fda6262d41a930ad34f39d021ab3b6'
HELPER = 0x0800F970                 # existing 7x10 SETTINGS text renderer
TABLE = 0x0800F9AC                  # 10 fixed four-byte strings fit through 0xF9D3
H_GLYPH = 0x0800F724                # former '+' glyph; no active string uses it

# State, first old header call, second old header call (if present), selector, centered x.
# Minute had no visible second header; its former unused call becomes the text call directly.
TIME_TITLES = [
    ('HR',  0x0800CFB2, 0x0800CFCE, 5, 73),
    ('MIN', 0x0800D2B2, None,         6, 70),
    ('DAY', 0x0800D4A4, 0x0800D4C0, 7, 70),
    ('MON', 0x0800D758, 0x0800D772, 8, 70),
    ('YR',  0x0800D9F2, 0x0800DA0E, 9, 73),
]
SETTINGS_SELECTOR_REMAP = {
    0x0800B430: 3,  # diode ON shares the existing ON string
    0x0800B4D2: 4,  # sound OFF shares the existing OFF string
    0x0800B4F6: 4,  # diode OFF shares the existing OFF string
}

def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 0xFF:
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError('record outside firmware image')
            image[off:off+n] = data
        elif typ == 1:
            break
    return image

def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 0xFF, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 0xFF])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])

def thumb_bl(address, target):
    delta = target - (address + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError('Thumb BL out of range')
    imm = delta & 0x1FFFFFF
    s, i1, i2 = (imm >> 24) & 1, (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = 1 ^ (i1 ^ s), 1 ^ (i2 ^ s)
    h1 = 0xF000 | (s << 10) | ((imm >> 12) & 0x3FF)
    h2 = 0xD000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7FF)
    return h1.to_bytes(2, 'little') + h2.to_bytes(2, 'little')

def bl_target(image, address):
    off = address - FLASH
    h1 = int.from_bytes(image[off:off+2], 'little')
    h2 = int.from_bytes(image[off+2:off+4], 'little')
    if h1 & 0xF800 != 0xF000 or h2 & 0xD000 != 0xD000:
        return None
    s, j1, j2 = (h1 >> 10) & 1, (h2 >> 13) & 1, (h2 >> 11) & 1
    i1, i2 = 1 ^ (j1 ^ s), 1 ^ (j2 ^ s)
    imm = (s << 24) | (i1 << 23) | (i2 << 22) | ((h1 & 0x3FF) << 12) | ((h2 & 0x7FF) << 1)
    if s:
        imm -= 1 << 25
    return (address + 4 + imm) & 0xFFFFFFFF

def glyph(rows):
    if len(rows) != 10 or any(len(row) != 7 for row in rows):
        raise ValueError('expected 7x10 glyph')
    out = bytearray()
    for row in rows:
        word = sum((c == '#') << (15 - i) for i, c in enumerate(row))
        out.extend(word.to_bytes(2, 'little'))
    return bytes(out)

if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
    raise ValueError('v51 SHA-256 mismatch')
image = decode(SOURCE)
original = bytes(image)

# The existing helper uses selector*4 and puts selectors >4 at the lower label row.
assert image[0xF97E:0xF980] == bytes.fromhex('06 2C'), 'unexpected SETTINGS helper layout'
image[0xF97E:0xF980] = bytes.fromhex('04 2C')

# Entries 0..4 preserve the SETTINGS labels, folding duplicate ON/OFF entries.
# Entries 5..9 are the five TIME labels. 0x2B is the new H glyph.
strings = (
    bytes.fromhex('3D 41 00 00') +  # Sv
    bytes.fromhex('29 42 27 00') +  # CPM
    bytes.fromhex('22 00 00 00') +  # R
    bytes.fromhex('3C 21 00 00') +  # ON
    bytes.fromhex('3C 2A 2A 00') +  # OFF
    bytes.fromhex('2B 22 00 00') +  # HR
    bytes.fromhex('27 26 21 00') +  # MIN
    bytes.fromhex('3B 28 24 00') +  # DAY
    bytes.fromhex('27 3C 21 00') +  # MON
    bytes.fromhex('24 22 00 00')    # YR
)
assert len(strings) == 40
image[TABLE-FLASH:TABLE-FLASH+len(strings)] = strings

# Reclaim the unused '+' slot as a 7x10 H. No current string uses 0x2B.
image[H_GLYPH-FLASH:H_GLYPH-FLASH+20] = glyph([
    '#...#..', '#...#..', '#...#..', '#####..', '#...#..', '#...#..', '#...#..',
    '.......', '.......', '.......',
])

# Consolidate repeated SETTINGS string selectors without changing their locations.
for call, selector in SETTINGS_SELECTOR_REMAP.items():
    off = call - FLASH
    assert image[off-6:off-4] in (bytes.fromhex('04 20'), bytes.fromhex('05 20'), bytes.fromhex('06 20'))
    assert bl_target(image, call) == HELPER
    image[off-6:off-4] = (0x2000 | selector).to_bytes(2, 'little')

# A TIME title call receives selector and x in the two setup instructions that only served
# the old raster dispatcher. Any second half of the old bitmap title is disabled.
for _name, first, second, selector, x in TIME_TITLES:
    off = first - FLASH
    if first == 0x0800D2B2:
        assert original[off:off+4] == bytes.fromhex('00 BF 00 BF'), 'v51 minute slot changed'
    else:
        assert bl_target(original, first) == 0x0800AFE4, f'unexpected old title target at {first:#x}'
    image[off-4:off-2] = (0x2000 | selector).to_bytes(2, 'little')
    image[off-2:off] = (0x2100 | x).to_bytes(2, 'little')
    image[off:off+4] = thumb_bl(first, HELPER)
    if second is not None:
        assert bl_target(original, second) == 0x0800AFE4, f'unexpected title half at {second:#x}'
        image[second-FLASH:second-FLASH+4] = bytes.fromhex('00 BF 00 BF')

OUT.write_text(encode(image))
check = decode(OUT)
assert check == image, 'Intel HEX round-trip mismatch'
for line in OUT.read_text().splitlines():
    assert not (sum(bytes.fromhex(line[1:])) & 0xFF), 'bad Intel HEX checksum'
assert check[0x0800B6A4-FLASH:0x0800B6A4-FLASH+4] == original[0x0800B6A4-FLASH:0x0800B6A4-FLASH+4], 'units icon changed'
for _name, first, second, _selector, _x in TIME_TITLES:
    assert bl_target(check, first) == HELPER
    if second is not None:
        assert check[second-FLASH:second-FLASH+4] == bytes.fromhex('00 BF 00 BF')
for call, selector in SETTINGS_SELECTOR_REMAP.items():
    assert check[call-FLASH-6:call-FLASH-4] == (0x2000 | selector).to_bytes(2, 'little')
changed = {i for i, (a, b) in enumerate(zip(original, check)) if a != b}
allowed = set(range(0xF97E, 0xF980)) | set(range(TABLE-FLASH, TABLE-FLASH+40)) | set(range(H_GLYPH-FLASH, H_GLYPH-FLASH+20))
for call in SETTINGS_SELECTOR_REMAP:
    allowed.update(range(call-FLASH-6, call-FLASH-4))
for _name, first, second, _selector, _x in TIME_TITLES:
    allowed.update(range(first-FLASH-4, first-FLASH+4))
    if second is not None:
        allowed.update(range(second-FLASH, second-FLASH+4))
assert changed <= allowed, f'unexpected changes: {sorted(changed - allowed)}'
print('output:', OUT)
print('labels: HR / MIN / DAY / MON / YR')
print('changed bytes:', len(changed))
print('sha256:', hashlib.sha256(OUT.read_bytes()).hexdigest())
