from pathlib import Path
import hashlib
FLASH=0x08000000
SOURCE=Path('work/port-20261006-0015-energy-off-position-v4.hex')
OUT=Path('work/port-20261006-0150-energy-off-zero-v4.hex')
BASE_SHA='7d003596b1c1946bee4843dd9d99d29d1c4256c39d9e1bd18b9e2b3023d1b0c7'
CALL=0x080092BC
DISPATCH=0x0800AFE4
DRAW=0x08008E48
HELPER=0x0800F0A8  # formerly the Medium-font space glyph, approved as reusable
TAIL=0x0800F118    # erased tail space
STRING=0x0800F00B  # existing NUL-terminated "00"
MEDIUM_DESC=0x0800FCF8

def decode(path):
 im=bytearray([255])*0x10000; upper=0
 for line in path.read_text().splitlines():
  if not line.startswith(':'): continue
  rec=bytes.fromhex(line[1:]);n,hi,lo,typ=rec[:4];data=rec[4:-1]
  if n!=len(data) or sum(rec)&255:raise ValueError('invalid Intel HEX record')
  if typ==4:upper=int.from_bytes(data,'big')<<16
  elif typ==0:
   off=upper+(hi<<8)+lo-FLASH
   if off<0 or off+n>len(im):raise ValueError('record out of range')
   im[off:off+n]=data
  elif typ==1:break
 return im
def encode(im):
 lines=[':020000040800F2']
 for off in range(0,len(im),16):
  rec=bytes([16,off>>8,off&255,0])+im[off:off+16]
  lines.append(':'+(rec+bytes([(-sum(rec))&255])).hex().upper())
 return '\n'.join(lines+[':00000001FF',''])
def bl(addr,target):
 d=target-(addr+4)
 if d&1 or not -(1<<24)<=d<(1<<24):raise ValueError('BL range')
 x=d&0x1ffffff;s=x>>24&1;i1=x>>23&1;i2=x>>22&1;j1=1^(i1^s);j2=1^(i2^s)
 return (0xf000|(s<<10)|((x>>12)&1023)).to_bytes(2,'little')+(0xd000|(j1<<13)|(j2<<11)|((x>>1)&2047)).to_bytes(2,'little')
def b16(addr,target):
 d=target-(addr+4)
 if d&1 or not -2048<=d//2<=2047:raise ValueError('B range')
 return (0xE000|((d//2)&0x7ff)).to_bytes(2,'little')
def target(im,addr):
 i=addr-FLASH;h1=int.from_bytes(im[i:i+2],'little');h2=int.from_bytes(im[i+2:i+4],'little')
 if h1&0xf800!=0xf000 or h2&0xd000!=0xd000:return None
 s=h1>>10&1;j1=h2>>13&1;j2=h2>>11&1;i1=1^(j1^s);i2=1^(j2^s)
 v=(s<<24)|(i1<<23)|(i2<<22)|((h1&1023)<<12)|((h2&2047)<<1)
 if s:v-=1<<25
 return (addr+4+v)&0xffffffff
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=decode(SOURCE);original=bytes(im)
assert target(im,CALL)==DISPATCH
assert im[HELPER-FLASH:HELPER-FLASH+36]==bytes(36), 'Medium space glyph no longer blank'
assert im[TAIL-FLASH:TAIL-FLASH+8]==bytes([0xFF])*8, 'tail space no longer erased'
assert im[STRING-FLASH:STRING-FLASH+3]==b'00\0', 'existing 00 string changed'
# Entry creates the normal 11x18 renderer call for string "00" at the same
# position as the 10..60 values: x=68, y=30.  The helper uses the blank Medium
# space-glyph slot and the previously confirmed erased tail space.
code=bytearray()
def h(v): code.extend(v.to_bytes(2,'little'))
h(0xB510)            # push {r4,lr}
h(0xB084)            # sub sp,#16
h(0x4A1C)            # ldr r2,[pc,#112] -> F120, "00\0"
h(0x2044)            # x=68
h(0x211E)            # y=30
h(0x4B1C)            # ldr r3,[pc,#112] -> F124, Medium descriptor
h(0x9300)            # descriptor at [sp]
h(0x2300); h(0x43DB); h(0x9301)  # foreground = white
h(0x4B1A); h(0x9302)              # background = sampled turquoise at F128
h(0x2312); h(0x021B); h(0x330B)   # r3=(18<<8)|11
assert len(code)==30
code+=b16(HELPER+len(code),TAIL)
assert len(code)==32
im[HELPER-FLASH:HELPER-FLASH+len(code)]=code
# Renderer tail: call, restore 16-byte argument area, and return to caller.
tail=bl(TAIL,DRAW)+bytes.fromhex('04 B0 10 BD')
assert len(tail)==8
im[TAIL-FLASH:TAIL-FLASH+len(tail)]=tail
# Literal pool loaded by the helper; no new string or glyph is added.
im[TAIL-FLASH+8:TAIL-FLASH+20]=STRING.to_bytes(4,'little')+MEDIUM_DESC.to_bytes(4,'little')+(0x8640).to_bytes(4,'little')
im[CALL-FLASH:CALL-FLASH+4]=bl(CALL,HELPER)
OUT.write_text(encode(im));check=decode(OUT);assert check==im
for line in OUT.read_text().splitlines():
 if line.startswith(':') and sum(bytes.fromhex(line[1:]))&255:raise ValueError('bad output checksum')
changed={i for i,(a,b) in enumerate(zip(original,check)) if a!=b}
allowed=set(range(HELPER-FLASH,HELPER-FLASH+32))|set(range(TAIL-FLASH,TAIL-FLASH+20))|set(range(CALL-FLASH,CALL-FLASH+4))
assert changed<=allowed,sorted(changed-allowed)
print('output',OUT,'changed_bytes',len(changed),'coordinates',(68,30),'sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
