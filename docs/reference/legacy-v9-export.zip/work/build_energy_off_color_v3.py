#!/usr/bin/env python3
"""Color-probe the adjacent Medium-font selector 0x12 in the energy menu."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261005-1751-energy-stats-5x8-v2.hex')
OUT = Path('work/port-20261005-2343-energy-off-color-v3.hex')
SOURCE_SHA256 = 'caa155761d4a3fa452ce0cb4f992f79e5698d1a38c3cb89c3caab9915f8febd1'
CALL = 0x0800BDCE
MEDIUM_SETTINGS_RENDERER = 0x0800FD90
FILL = 0x08008ECC
HELPER = 0x0800F118
RED565 = 0xF800


def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 0xFF:
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off+n > len(image):
                raise ValueError('record outside firmware image')
            image[off:off+n] = data
        elif typ == 1:
            break
    return image


def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])


def thumb_bl(address, target):
    delta = target - (address + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError('Thumb BL target out of range')
    imm = delta & 0x1FFFFFF
    s, i1, i2 = (imm >> 24) & 1, (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = 1 ^ (i1 ^ s), 1 ^ (i2 ^ s)
    h1 = 0xF000 | (s << 10) | ((imm >> 12) & 0x3FF)
    h2 = 0xD000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7FF)
    return h1.to_bytes(2, 'little') + h2.to_bytes(2, 'little')


def bl_target(image, address):
    off = address - FLASH
    h1 = int.from_bytes(image[off:off+2], 'little')
    h2 = int.from_bytes(image[off+2:off+4], 'little')
    if h1 & 0xF800 != 0xF000 or h2 & 0xD000 != 0xD000:
        return None
    s, j1, j2 = (h1 >> 10) & 1, (h2 >> 13) & 1, (h2 >> 11) & 1
    i1, i2 = 1 ^ (j1 ^ s), 1 ^ (j2 ^ s)
    imm = ((s << 24) | (i1 << 23) | (i2 << 22) |
           ((h1 & 0x3FF) << 12) | ((h2 & 0x7FF) << 1))
    if s:
        imm -= 1 << 25
    return (address + 4 + imm) & 0xFFFFFFFF


if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
    raise ValueError('accepted base SHA-256 mismatch')
image = decode(SOURCE)
original = bytes(image)
if bl_target(image, CALL) != MEDIUM_SETTINGS_RENDERER:
    raise ValueError('selector 0x12 call no longer targets the Medium settings renderer')

# The row's Medium-font configuration maps selector 0x12 to x=61, y=31.
# Reuse a known blank code area for a tiny fixed red RGB565 fill wrapper.
assert HELPER % 4 == 0
assert image[HELPER-FLASH:HELPER-FLASH+24] == bytes([0xFF])*24, 'diagnostic helper area is not blank'
helper = (bytes.fromhex('00 B5 81 B0 03 4B 00 93 28 22 12 23') +
          thumb_bl(HELPER+12, FILL) + bytes.fromhex('01 B0 00 BD') +
          RED565.to_bytes(4, 'little'))
assert len(helper) == 24
image[HELPER-FLASH:HELPER-FLASH+24] = helper

# Selector 0x13's text draw is replaced by a red 40x18 swatch at the original
# Medium-font origin; no stats, battery/ENERGY percentage, or other menu calls move.
setup = CALL-FLASH-6
expected_setup = bytes.fromhex('00 93 11 4B 12 20')
assert image[setup:setup+6] == expected_setup, 'unexpected selector-0x12 setup'
image[setup:setup+6] = bytes.fromhex('3D 20 1F 21 00 22')  # r0=61, r1=31, r2 unused
image[CALL-FLASH:CALL-FLASH+4] = thumb_bl(CALL, HELPER)

OUT.write_text(encode(image))
check = decode(OUT)
assert check == image, 'Intel HEX round-trip mismatch'
for line in OUT.read_text().splitlines():
    if line.startswith(':') and sum(bytes.fromhex(line[1:])) & 0xFF:
        raise ValueError('bad Intel HEX checksum')
changed = {i for i, (a, b) in enumerate(zip(original, check)) if a != b}
allowed = set(range(HELPER-FLASH, HELPER-FLASH+24))
allowed.update(range(CALL-FLASH-6, CALL-FLASH+4))
assert changed <= allowed, f'unexpected changes: {sorted(changed-allowed)}'
print('output:', OUT)
print('base sha256:', SOURCE_SHA256)
print('probe: selector 0x12 at 0x0800BDCE, red 40x18 at (61,31)')
print('stats callsites unchanged; only one Medium-font selector is replaced')
print('changed bytes:', len(changed))
print('sha256:', hashlib.sha256(OUT.read_bytes()).hexdigest())
