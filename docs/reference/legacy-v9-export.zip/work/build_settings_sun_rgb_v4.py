from pathlib import Path
import hashlib
FLASH=0x08000000
SOURCE=Path('work/port-20261006-0747-settings-sun-v1.hex')
OUT=Path('work/port-20261006-0900-settings-sun-rgb-v4.hex')
BASE_SHA='43fff435e717e987107a8442ef94f4b7dd0e75ce4c734186deefd10d570d47d9'
CALL=0x0800BA2C; WRAP=0x0800F12C; FILL=0x0800F91E; STATE=0x0800FFE0
def dec(p):
 im=bytearray([255])*0x10000;u=0
 for l in p.read_text().splitlines():
  if not l.startswith(':'):continue
  r=bytes.fromhex(l[1:]);n,a,t=r[0],int.from_bytes(r[1:3],'big'),r[3];d=r[4:4+n]
  if t==4:u=int.from_bytes(d,'big')<<16
  elif t==0:im[u+a-FLASH:u+a-FLASH+n]=d
  elif t==1:break
 return im
def enc(im):
 q=[':020000040800F2']
 for o in range(0,len(im),16):
  b=bytes((16,o>>8,o&255,0))+bytes(im[o:o+16]);q.append(':'+(b+bytes((-sum(b)&255,))).hex().upper())
 return '\n'.join(q+[':00000001FF',''])
def bl(a,t):
 d=t-a-4;i=d&0x1ffffff;s=i>>24&1;i1=i>>23&1;i2=i>>22&1;j1=1^i1^s;j2=1^i2^s
 return ((0xf000|(s<<10)|(i>>12&1023)).to_bytes(2,'little')+(0xd000|(j1<<13)|(j2<<11)|(i>>1&2047)).to_bytes(2,'little'))
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=dec(SOURCE);o=WRAP-FLASH
# This is a verified unused 0xFF gap, outside font/data tables.
assert im[o:o+12]==b'\xff'*12
# Preserve caller LR; paint using the confirmed arguments; then run the
# original state helper and return normally to the caller.
code=bytes.fromhex('00 B5')+bl(WRAP+2,FILL)+bl(WRAP+6,STATE)+bytes.fromhex('00 BD')
assert len(code)==12
im[o:o+12]=code
assert im[CALL-FLASH:CALL-FLASH+4]==bytes.fromhex('04 F0 D8 FA')
im[CALL-FLASH:CALL-FLASH+4]=bl(CALL,WRAP)
OUT.write_text(enc(im));assert dec(OUT)==im
print(OUT);print('sha256',hashlib.sha256(OUT.read_bytes()).hexdigest());print('wrapper at verified FF gap; Medium/font data untouched')
