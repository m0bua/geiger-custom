# Geiger-2 continuation export v8

Created 2026-10-05 23:41 UTC.

This archive contains the complete working tree for the EN 4.1.17 firmware work:

- `work/`: all generated Intel HEX builds, builders, diagnostics, notes, font maps, and the previous continuation export.
- `upload/`: supplied HEX, ZIP, images, and raster search documentation.

Accepted working base:

- `work/port-20261006-0203-settings-layout-v1.hex`
- SHA-256: `40b07cdffc773c4038164a47143e8057d15bae0da82141154bbd8985739738be`

Latest test build:

- `work/port-20261006-0241-time-page-v6.hex`
- SHA-256: `eb117b1b2fff12ed4861d76c38cb1e86a34e9fbce5c52432a92b9ae0fbc09ef7`

The latest build moves the large Time-page clock to x=80 and restores the stock date renderer.
