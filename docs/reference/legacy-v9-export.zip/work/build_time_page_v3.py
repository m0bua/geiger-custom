from pathlib import Path
import hashlib
FLASH=0x08000000
SOURCE=Path('work/port-20261006-0203-settings-layout-v1.hex')
OUT=Path('work/port-20261006-0230-time-page-v3.hex')
BASE_SHA='40b07cdffc773c4038164a47143e8057d15bae0da82141154bbd8985739738be'
# State 4 is the Time page. Its first text draw is the large HH:MM value.
# 0x0800AAD2: movs r0,#68 -> x=90 (+22 px / two Medium cells).
X=0x0800AAD0

def decode(path):
 im=bytearray([255])*0x10000;up=0
 for line in path.read_text().splitlines():
  if not line.startswith(':'):continue
  rec=bytes.fromhex(line[1:]);n,hi,lo,t=rec[:4];d=rec[4:-1]
  if len(d)!=n or sum(rec)&255:raise ValueError('bad Intel HEX')
  if t==4:up=int.from_bytes(d,'big')<<16
  elif t==0:
   off=up+(hi<<8)+lo-FLASH
   if not 0<=off<=len(im)-n:raise ValueError('outside image')
   im[off:off+n]=d
  elif t==1:break
 return im

def encode(im):
 out=[':020000040800F2']
 for off in range(0,len(im),16):
  rec=bytes([16,off>>8,off&255,0])+im[off:off+16]
  out.append(':'+(rec+bytes([(-sum(rec))&255])).hex().upper())
 return '\n'.join(out+[':00000001FF',''])
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=decode(SOURCE); old=bytes(im);o=X-FLASH
assert im[o:o+2]==bytes.fromhex('44 20'),im[o:o+2].hex()
im[o:o+2]=bytes.fromhex('5A 20')
OUT.write_text(encode(im));check=decode(OUT)
assert check==im
assert all(not(sum(bytes.fromhex(line[1:]))&255) for line in OUT.read_text().splitlines())
changed={i for i,(a,b) in enumerate(zip(old,check)) if a!=b};assert changed=={o},changed
print(OUT);print('Time-page HH:MM x: 68 -> 90 (+22 px)');print('sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
