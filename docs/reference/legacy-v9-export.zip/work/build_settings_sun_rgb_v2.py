from pathlib import Path
import hashlib

FLASH=0x08000000
SOURCE=Path('work/port-20261006-0825-settings-sun-rgb-v1.hex')
OUT=Path('work/port-20261006-0835-settings-sun-rgb-v2.hex')
BASE_SHA='601dbad66d1ff35cca8f300c1002b57ce25edf6dcaa96dc59f1e1b792793289f'
WRAP=0x0800F292
FILL=0x0800F91E
STATE=0x0800FFE0
CALL=0x0800BA2C

def decode(p):
 im=bytearray([255])*0x10000;u=0
 for l in p.read_text().splitlines():
  if not l.startswith(':'): continue
  r=bytes.fromhex(l[1:]);n,a,t=r[0],int.from_bytes(r[1:3],'big'),r[3];d=r[4:4+n]
  if len(d)!=n or sum(r)&255: raise ValueError('bad HEX')
  if t==4:u=int.from_bytes(d,'big')<<16
  elif t==0:im[u+a-FLASH:u+a-FLASH+n]=d
  elif t==1:break
 return im
def enc(im):
 out=[':020000040800F2']
 for o in range(0,len(im),16):
  b=bytes((16,o>>8,o&255,0))+bytes(im[o:o+16]);out.append(':'+(b+bytes((-sum(b)&255,))).hex().upper())
 return '\n'.join(out+[':00000001FF',''])
def bl(a,t):
 d=t-(a+4);imm=d&0x1ffffff;s=(imm>>24)&1;i1=(imm>>23)&1;i2=(imm>>22)&1
 j1=1^i1^s;j2=1^i2^s
 return ((0xf000|(s<<10)|((imm>>12)&1023)).to_bytes(2,'little')+
         (0xd000|(j1<<13)|(j2<<11)|((imm>>1)&2047)).to_bytes(2,'little'))

assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=decode(SOURCE);old=bytes(im)
o=WRAP-FLASH
assert im[o:o+12]==b'\x00'*12
# Preserve the caller registers and return address: fill the confirmed icon,
# then tail-call the original state helper so screen transitions remain intact.
code=bytes.fromhex('0F B5')+bl(WRAP+2,FILL)+bytes.fromhex('0F BD')+bl(WRAP+8,STATE)
assert len(code)==12
im[o:o+12]=code
assert im[CALL-FLASH:CALL-FLASH+4]==bl(CALL,FILL)
im[CALL-FLASH:CALL-FLASH+4]=bl(CALL,WRAP)
OUT.write_text(enc(im))
assert decode(OUT)==im
print(OUT)
print('sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
print('wrapper preserves r0-r3/lr, paints BA26 icon, then tail-calls original state helper')
