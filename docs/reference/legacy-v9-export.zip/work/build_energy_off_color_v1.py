#!/usr/bin/env python3
"""Diagnostic: color candidate text draws for the Energy power-off menu."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261005-1751-energy-stats-5x8-v2.hex')
OUT = Path('work/port-20261005-1751-energy-off-color-v1.hex')
SOURCE_SHA256 = 'caa155761d4a3fa452ce0cb4f992f79e5698d1a38c3cb89c3caab9915f8febd1'
DRAW_STRING = 0x08008E48

# Five candidate text draws from the menu/settings renderer group. They all
# share a red diagnostic wrapper; this isolates their text from raster assets.
CANDIDATES = [0x0800C258, 0x0800C2AA, 0x0800C30E, 0x0800C370, 0x0800C3BE]
DIAGNOSTIC_COLOR = 0xF800
HELPER = 0x0800F118


def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 0xFF:
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off+n > len(image):
                raise ValueError('record outside firmware image')
            image[off:off+n] = data
        elif typ == 1:
            break
    return image


def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])


def thumb_bl(address, target):
    delta = target - (address + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError('Thumb BL target out of range')
    imm = delta & 0x1FFFFFF
    s, i1, i2 = (imm >> 24) & 1, (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = 1 ^ (i1 ^ s), 1 ^ (i2 ^ s)
    h1 = 0xF000 | (s << 10) | ((imm >> 12) & 0x3FF)
    h2 = 0xD000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7FF)
    return h1.to_bytes(2, 'little') + h2.to_bytes(2, 'little')


def thumb_bw(address, target):
    return thumb_bl(address, target)


def bl_target(image, address):
    off = address - FLASH
    h1 = int.from_bytes(image[off:off+2], 'little')
    h2 = int.from_bytes(image[off+2:off+4], 'little')
    if h1 & 0xF800 != 0xF000 or h2 & 0xD000 != 0xD000:
        return None
    s, j1, j2 = (h1 >> 10) & 1, (h2 >> 13) & 1, (h2 >> 11) & 1
    i1, i2 = 1 ^ (j1 ^ s), 1 ^ (j2 ^ s)
    imm = ((s << 24) | (i1 << 23) | (i2 << 22) |
           ((h1 & 0x3FF) << 12) | ((h2 & 0x7FF) << 1))
    if s:
        imm -= 1 << 25
    return (address + 4 + imm) & 0xFFFFFFFF


if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
    raise ValueError('accepted base SHA-256 mismatch')
image = decode(SOURCE)
original = bytes(image)
assert HELPER % 4 == 0
helper_size = 12
assert image[HELPER-FLASH:HELPER-FLASH+helper_size] == bytes([0xFF]) * helper_size, 'helper area is not blank'
# ldr r3,[pc,#4] ; b.w DRAW_STRING ; nop ; RGB565 literal
helper_code = (bytes.fromhex('01 4B') + thumb_bw(HELPER+2, DRAW_STRING) +
               bytes.fromhex('00 BF') + DIAGNOSTIC_COLOR.to_bytes(4, 'little'))
assert len(helper_code) == helper_size
image[HELPER-FLASH:HELPER-FLASH+helper_size] = helper_code

for call in CANDIDATES:
    if bl_target(image, call) != DRAW_STRING:
        raise ValueError(f'unexpected original renderer target at {call:#x}')
    image[call-FLASH:call-FLASH+4] = thumb_bl(call, HELPER)

OUT.write_text(encode(image))
check = decode(OUT)
assert check == image, 'Intel HEX round-trip mismatch'
for line in OUT.read_text().splitlines():
    if line.startswith(':') and sum(bytes.fromhex(line[1:])) & 0xFF:
        raise ValueError('bad Intel HEX checksum')

changed = {i for i, (a, b) in enumerate(zip(original, check)) if a != b}
allowed = set(range(HELPER-FLASH, HELPER-FLASH+helper_size))
for call in CANDIDATES:
    allowed.update(range(call-FLASH, call-FLASH+4))
assert changed <= allowed, f'unexpected changes: {sorted(changed-allowed)}'
print('output:', OUT)
print('base sha256:', SOURCE_SHA256)
print('red RGB565 color:', f'{DIAGNOSTIC_COLOR:#06x}')
print('candidate callsites:', ', '.join(f'{call:#010x}' for call in CANDIDATES))
print('changed bytes:', len(changed), '(only five callsites and one tiny wrapper)')
print('sha256:', hashlib.sha256(OUT.read_bytes()).hexdigest())
