from pathlib import Path
import hashlib
FLASH=0x08000000
SOURCE=Path('work/port-20261006-0203-settings-layout-v1.hex')
OUT=Path('work/port-20261006-0234-time-page-v4.hex')
BASE_SHA='40b07cdffc773c4038164a47143e8057d15bae0da82141154bbd8985739738be'
DRAW=0x08008E48
SMALL=0x0800F648
HELPER=0x0800F1B0
TIME_X=0x0800AAD0
DATE_CALL=0x0800AAE8

def decode(path):
 im=bytearray([255])*0x10000;up=0
 for line in path.read_text().splitlines():
  if not line.startswith(':'):continue
  rec=bytes.fromhex(line[1:]);n,hi,lo,t=rec[:4];d=rec[4:-1]
  if len(d)!=n or sum(rec)&255:raise ValueError('bad Intel HEX')
  if t==4:up=int.from_bytes(d,'big')<<16
  elif t==0:
   off=up+(hi<<8)+lo-FLASH
   if not 0<=off<=len(im)-n:raise ValueError('outside image')
   im[off:off+n]=d
  elif t==1:break
 return im

def encode(im):
 out=[':020000040800F2']
 for off in range(0,len(im),16):
  rec=bytes([16,off>>8,off&255,0])+im[off:off+16]
  out.append(':'+(rec+bytes([(-sum(rec))&255])).hex().upper())
 return '\n'.join(out+[':00000001FF',''])
def bl(src,dst):
 d=dst-(src+4); assert d&1==0 and -(1<<24)<=d<(1<<24)
 x=d&0x1ffffff;s=x>>24&1;i1=x>>23&1;i2=x>>22&1;j1=1^(i1^s);j2=1^(i2^s)
 return (0xf000|(s<<10)|((x>>12)&1023)).to_bytes(2,'little')+(0xd000|(j1<<13)|(j2<<11)|((x>>1)&2047)).to_bytes(2,'little')
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_SHA
im=decode(SOURCE); old=bytes(im)
# half Medium cell backwards: 90 -> 84
assert im[TIME_X-FLASH:TIME_X-FLASH+2]==bytes.fromhex('44 20')
im[TIME_X-FLASH:TIME_X-FLASH+2]=bytes.fromhex('54 20')
# date call routes through a small-font adapter; keep caller's x/y/string/colors.
assert im[DATE_CALL-FLASH:DATE_CALL-FLASH+4]==bl(DATE_CALL,DRAW)
code=bytearray.fromhex('10 B5 83 B0') # push {r4,lr}; sub sp,#12
# copy caller stack colors: old SP = current SP + 20; fg +24, bg +28
code += bytes.fromhex('04 9C 01 94 04 9C') # ldr r4,[sp,#16]? corrected below
# overwrite with exact instructions: ldr r4,[sp,#24]; str [sp,#4]; ldr [sp,#28]; str [sp,#8]
code=bytearray.fromhex('10 B5 83 B0 06 9C 01 94 07 9C 02 94')
code += bytes.fromhex('03 4C 00 94 0A 23 1B 02 07 33') # small ptr literal; table; dims 0x0A07
# call renderer
code += bl(HELPER+len(code),DRAW)
code += bytes.fromhex('03 B0 10 BD')
# align and literals; ldr r4,[pc,#12] at helper+12 => pc aligned helper+16, +12 = +28
while len(code)<28: code += bytes.fromhex('00 BF')
code += SMALL.to_bytes(4,'little')
assert len(code)<=48,len(code)
im[HELPER-FLASH:HELPER-FLASH+len(code)]=code
im[DATE_CALL-FLASH:DATE_CALL-FLASH+4]=bl(DATE_CALL,HELPER)
OUT.write_text(encode(im));check=decode(OUT);assert check==im
assert all(not(sum(bytes.fromhex(x[1:]))&255) for x in OUT.read_text().splitlines())
changed={i for i,(a,b) in enumerate(zip(old,check)) if a!=b}
allowed=set(range(TIME_X-FLASH,TIME_X-FLASH+2))|set(range(DATE_CALL-FLASH,DATE_CALL-FLASH+4))|set(range(HELPER-FLASH,HELPER-FLASH+len(code)))
assert changed<=allowed,sorted(changed-allowed)
print(OUT);print('Time x 90 -> 84; date via Small 7x10; helper bytes',len(code));print('sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
