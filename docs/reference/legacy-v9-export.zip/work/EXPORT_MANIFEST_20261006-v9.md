# GEIGER2 continuation export — 2026-10-06 v9

## Current working state

- Device: Mira Safety Geiger-2, EN 4.1.17 patch work.
- Accepted functional base from the recent sequence: `port-20261006-0747-settings-sun-v1.hex`.
- The settings-page sun test changed the damaged right icon resource selection and position.
- The latest icon-color experiments were rejected after device reboot.

## Settings icon mapping

- Direct raster calls:
  - `0x0800B9EE` — central icon, resource offset `0x0604`, 900 bytes.
  - `0x0800BA0A` — left icon, resource offset `0x0302`, 720 bytes.
  - `0x0800BA26` — right icon, resource offset `0x032A`, 800 bytes.
- Do not modify as icon calls:
  - `0x0800BA2C`, `0x0800BA40`, `0x0800BA48` — post-raster state helpers.
- Resource dispatcher: `0x0800AFE4`.
- External resource-reader path reaches `0x0800E43C` over SPI; raster bytes are not in the 64 KiB MCU HEX.
- Direct replacement of raster calls with `0x0800F91E` caused reboot and is rejected.

## Latest rejected experiments

- `port-20261006-1015-settings-icon1-red-v1.hex` — direct `B9EE -> F91E`; device rebooted.
- `port-20261006-0915-settings-sun-rgb-v5.hex` — direct `BA2C -> F91E`; device rebooted.
- `port-20261006-0900-settings-sun-rgb-v4.hex` — wrapper experiment; damaged Medium/menu behavior.

## Next safe direction

Obtain a dump of the external SPI resource memory (`R80B 104AB`) and recolor the resource bytes directly, or reconstruct a fully compatible wrapper around the original resource dispatcher. Do not probe `BA2C/BA40/BA48` with the fill helper again.

## Naming rule

`port-{date}-{time}-{topic}-v{N}.hex`; topic changes reset version to 1. Keep the time monotonic for sorting.
