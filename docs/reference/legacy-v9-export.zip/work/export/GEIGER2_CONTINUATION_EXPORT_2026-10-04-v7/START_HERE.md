# Geiger-2 continuation export — 2026-10-04 v7

## Frozen working firmware

Use `firmware/approved/port-20261004-2235-settings-page-clear-v6.hex` as the current approved base.
SHA-256: `f10069bdb4cd8f3084cf313c7bb3432aee6be89e5a9ee511b50b0efca00bcea6`.

The user explicitly froze SETTINGS clear **v6** as the basis. A later v7 test
was generated after that decision; it is unapproved and must not replace v6.
Do not rebuild, rename, or alter the frozen HEX unless the user asks for a new
firmware change.

## Read first

1. `docs/GEIGER2_CONTINUATION_NOTES_2026-10-04-v7.md` — handoff and latest decisions.
2. `docs/GEIGER2_BLOCK_MAP_2026-10-04-v2.md` — confirmed firmware blocks and protected areas.
3. `docs/GEIGER2_FONT_MAP_2026-10-04-v7.md` and the three font cards in `assets/`.
4. `docs/SETTINGS_PAGE_CLEAR_HISTORY.md` — status of each recent SETTINGS build.

The earlier approved battery v6 and Dose labels v2 remain in `firmware/approved/`;
the SETTINGS v6 HEX is the newest combined basis. All previous export content,
including the 2026-10-02 history, is retained.
