#!/usr/bin/env python3
"""Write a current font map by extracting the three font tables from HEX."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
HEX = Path("firmware/approved/port-20261004-1639-dose-labels-7x10-v2.hex")
OLD_MAP = Path("docs/GEIGER2_FONT_MAP_2026-10-04-v6.md")
OUT = Path("docs/GEIGER2_FONT_MAP_2026-10-04-v7.md")
SHA = "4b77d5d1c9544e8af0d6396945fdf978afd907fcae09b68fb76fd681580608cc"


def decode(path):
    image, upper = bytearray([255])*0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(":"):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, kind = rec[:4]
        data = rec[4:-1]
        if len(data) != n or sum(rec) & 255:
            raise ValueError("invalid Intel HEX record")
        if kind == 4:
            upper = int.from_bytes(data, "big") << 16
        elif kind == 0:
            off = upper + (hi << 8) + lo - FLASH
            image[off:off+n] = data
        elif kind == 1:
            break
    return image


def labels_from_map(text):
    sections, current = {}, None
    for line in text.splitlines():
        if line.startswith("## 11×18"):
            current = "medium"; sections[current] = {}
        elif line.startswith("## 7×10"):
            current = "small"; sections[current] = {}
        elif line.startswith("## 5×8"):
            current = "tiny"; sections[current] = {}
        elif line.startswith("## "):
            current = None
        elif current and line.startswith("|") and not line.startswith("|---"):
            f = [x.strip() for x in line.strip("|").split("|")]
            if f and f[0].isdigit():
                sections[current][int(f[0])] = (f[2] if current == "medium" else f[1]).strip("`")
    return sections


def raster(image, addr, w, h):
    off = addr - FLASH
    rows = []
    for y in range(h):
        word = int.from_bytes(image[off+2*y:off+2*y+2], "little")
        rows.append("".join("#" if (word >> (15-x)) & 1 else "." for x in range(w)))
    return "/".join(rows)


if hashlib.sha256(HEX.read_bytes()).hexdigest() != SHA:
    raise ValueError("current firmware SHA-256 mismatch")
image = decode(HEX)
names = labels_from_map(OLD_MAP.read_text())
assert (len(names["medium"]), len(names["small"]), len(names["tiny"])) == (40, 35, 12)

descs = [
    (0x0800FCF8, 11, 18, 0x0800F0A8, "medium A"),
    (0x0800FD00, 11, 18, 0x0800F0A8, "medium B"),
    (0x0800FD08, 7, 10, 0x0800F648, "small"),
    (0x0800FD10, 5, 8, 0x0800F9D4, "tiny"),
]
for a, w, h, ptr, _ in descs:
    b = image[a-FLASH:a-FLASH+8]
    if (b[0], b[1], int.from_bytes(b[4:8], "little")) != (w, h, ptr):
        raise ValueError(f"descriptor check failed at {a:#x}")

out = [
    "# Geiger‑2 font map — re-indexed from the approved DOSE-label v2 firmware",
    "",
    f"**HEX:** `{HEX.name}`  ",
    f"**SHA‑256:** `{SHA}`",
    "",
    "## Font descriptors in this firmware",
    "",
    "| Descriptor | Size | Glyph-table address | Capacity / current use |",
    "|---:|---:|---:|---|",
]
for a,w,h,ptr,label in descs:
    used = "40 slots; 38 glyphs (slots 29–30 are executable helper code)" if w==11 else ("35 table glyphs + custom % extension" if w==7 else "12 glyphs")
    out.append(f"| `0x{a:08X}` | {w}×{h} | `0x{ptr:08X}` | {used} |")
out += [
    "",
    "Rows in the tables below are extracted from the current HEX, not copied as pixel art. Each row lists the byte code used by the string renderer. Raster rows use `#` for set pixels and `.` for clear pixels; pixels are packed as 16-bit little-endian words with bit 15 at x=0.",
    "",
    "## 11×18 medium font",
    "",
    "The descriptors at `0x0800FCF8` and `0x0800FD00` point to the same table. The two formerly cleared `µ`/`h` glyph slots were reused by the battery text helper: `0x0800F4BC–0x0800F503` now contains executable code and literals. Do not treat those bytes as printable glyphs.",
    "",
    "| Index | Byte | Glyph | Address | Bitmap rows |",
    "|---:|---:|---|---:|---|",
]
for i in range(40):
    addr=0x0800F0A8+i*36
    name=names["medium"].get(i,"?")
    if i in (29,30):
        out.append(f"| {i:02d} | `0x{0x20+i:02X}` | reserved for helper code ({name}) | `0x{addr:08X}` | — |")
    else:
        out.append(f"| {i:02d} | `0x{0x20+i:02X}` | {name} | `0x{addr:08X}` | `{raster(image,addr,11,18)}` |")

out += ["", "## 7×10 small font", "", "The descriptor points to 35 glyphs at `0x0800F648`. The battery percentage glyph is a separate 36th glyph at `0x0800F904`, addressed with byte `0x43`; it is included below.", "", "| Index | Byte | Glyph | Address | Bitmap rows |", "|---:|---:|---|---:|---|"]
for i in range(35):
    addr=0x0800F648+i*20
    name=names["small"].get(i,"?")
    out.append(f"| {i:02d} | `0x{0x20+i:02X}` | {name} | `0x{addr:08X}` | `{raster(image,addr,7,10)}` |")
out.append(f"| 35 | `0x43` | % (battery extension) | `0x0800F904` | `{raster(image,0x0800F904,7,10)}` |")

out += ["", "## 5×8 tiny font", "", "| Index | Byte | Glyph | Address | Bitmap rows |", "|---:|---:|---|---:|---|"]
for i in range(12):
    addr=0x0800F9D4+i*16
    name=names["tiny"].get(i,"?")
    # 5x8 rows are packed one per 16-bit word, same bit-15-left convention.
    out.append(f"| {i:02d} | `0x{0x20+i:02X}` | {name} | `0x{addr:08X}` | `{raster(image,addr,5,8)}` |")

out += [
    "",
    "## Current screen strings using the 7×10 font",
    "",
    "| Screen / label | Encoded bytes (hex) | Current coordinates |",
    "|---|---|---|",
    "| MAIN `µSv/h` | `3F 3D 41 2F 40 00` | `(80,61)` |",
    "| MAIN `CPM` | `29 42 27 00` | `(87,61)` |",
    "| MAIN `µR/h` | `3F 22 2F 40 00` | `(83,61)` |",
    "| DOSE red `µSv` | `3F 3D 41 00` | `(118,38)` |",
    "| DOSE green `µR` | `3F 22 00` | `(129,38)` |",
    "| DOSE blue `CNT` | `29 21 25 00` | `(129,38)` |",
    "",
    "The 7×10 byte map is custom: byte values are not ASCII. For its main table, byte `0x20 + index` selects a slot; the custom glyph ordering is listed above. `%` is appended separately at `0x43`.",
    "",
    "The active font tables do not contain a complete A–Z alphabet: the 11×18 and 7×10 sets are selected glyph subsets. This is the current firmware inventory; do not infer a full alphabet from an earlier planning note.",
    "",
    "## Render style and code reuse",
    "",
    "- The 7×10 renderer is `DRAW_STRING` at `0x08008E48`; the current custom dose-label helper reuses the battery helper at `0x0800F4BC` and the font table at `0x0800F648`.",
    "- Font foreground for DOSE labels is white (`0xFFFF`); the character-cell background is the tested dark gray RGB565 `0x2945`.",
    "- The helper occupies addresses that overlapped the two removed 11×18 glyphs. The code/data region after the 7×10 `%` extension is also used by a helper and dose-label strings; preserve these when editing font storage.",
    "- Current approved text labels: red `µSv`, green `µR`, blue `CNT`; `µ` denotes micro (`10⁻⁶`).",
]
OUT.write_text("\n".join(out)+"\n")
print("font map:", OUT)
print("HEX SHA-256:", SHA)
print("descriptors verified:", len(descs), "font descriptors; raster rows extracted for 86 printable glyphs")
