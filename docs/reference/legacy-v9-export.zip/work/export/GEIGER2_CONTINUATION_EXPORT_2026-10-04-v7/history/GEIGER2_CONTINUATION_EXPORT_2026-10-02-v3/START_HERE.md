# GEIGER2 continuation export — 2026-10-02 v3

This is a folder export of the current firmware work. It is not an archive of the project directory.

## Contents
- `firmware/root/`: current approved base and latest V31 candidate.
- `firmware/to_delete/`: preserved diagnostic and superseded HEX experiments.
- `firmware/old/`: older HEX files retained under `old`.
- `notes/`: full historical handoff and current status notes.
- `SHA256SUMS.txt`: hashes for every exported file except this manifest.

## Current state
- Approved known-working base: `firmware/root/Port-4.1.17-no-headings-settings-labels-screen-clear-v1-60x20-unit-color-test-rgb.hex`.
- Latest candidate V31 is one composed `µSv/h` raster, not three rasters. Its draw buffer was enlarged to fit the 29-pixel bitmap.
- V31 settings map has 10 settings entries, but duplicate ON/OFF calls were NOPed rather than redirected; the user reported the menu broke. Do not treat V31 as approved.
- The user requested no further firmware/menu changes until resuming. COM4 CLI attempts in this session failed at bootloader acknowledgement; no flash write began through the CLI.
- Start future work from the approved base and read `notes/CONTINUATION_NOTES_2026-10-02-v3.md` first.
