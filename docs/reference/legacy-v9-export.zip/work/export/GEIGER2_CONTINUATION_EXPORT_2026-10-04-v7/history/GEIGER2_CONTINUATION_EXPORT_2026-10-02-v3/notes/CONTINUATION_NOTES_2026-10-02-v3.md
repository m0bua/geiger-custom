# GEIGER2 continuation — 2026-10-02 v3

## User direction
- Do not make further firmware or menu changes until the user resumes work.
- Preserve firmware HEX artifacts; superseded/test HEX files belong in `to_delete`, not deleted.
- Keep only HEX firmware outputs in the project root, plus the approved working base.
- Preferred flash port is COM4. CLI path: `%APPDATA%\milerd-port\STM32\STM32_Programmer_CLI.exe`.
- On this PC the CLI can open COM4 but may fail to enter the bootloader; `--start 0x08000000` has also previously reported success without actually restarting the device.

## Current project files
- Approved/known working base: `Port-4.1.17-no-headings-settings-labels-screen-clear-v1-60x20-unit-color-test-rgb.hex`
  - SHA-256: `90CCFB6C4616B080D169551518AE7D7B6748C93BC2F0F82882684F01C6E9DC6B`
  - The user confirmed this settings layout works.
- Latest candidate: `Port-4.1.17-unit-composite-three-glyphs-v31.hex`
  - SHA-256: `7D03F4436060542BAC5365E486258E2F93FBD818549A4C2E2D6F038D3D133719`
  - IMPORTANT: despite the filename, the unit is one 29-pixel composite raster, not three rasters.
  - Its renderer scratch buffer was increased from 256 to 504 bytes to accommodate 29 x 7 x 2 = 406 bytes. The allocation, stack argument offset, and stack restoration were patched together.
  - The map contains 10 settings rows plus one unit row. Duplicate settings calls at `0x0800B8C2` (ON) and `0x0800BA96` (OFF) were replaced with NOPs; they were not redirected to shared calls. Menu behavior is therefore suspect.
  - The CLI attempts from this session opened COM4 but timed out waiting for bootloader acknowledgement. The V31 write did not start from the CLI. Device state after the user's testing is unknown.
- Earlier V29/V30 candidates and the duplicate V28 HEX are retained under `to_delete/`.
- Other older diagnostics are retained in `to_delete/`; do not restore one as the base without checking against the approved HEX.

## Latest user-observed device behavior
- User reported a bootloop before the unit rendered on an earlier composite candidate.
- The 29-pixel raster exceeded the renderer's original 256-byte temporary buffer (406 bytes required), a strong likely cause. V31 increases that buffer, but has not been verified on the device in this session.
- User then reported that the menu also broke. No fix was attempted after that report, per the user's instruction to stop and export only.

## Next work when resumed
1. First establish which HEX is currently flashed and reproduce/confirm the menu failure.
2. Preserve the working base and repair menu entries by redirecting duplicate calls, not by simply dropping them.
3. Implement and verify `µ`, `Sv`, and `/h` as three narrow rasters if feasible, avoiding the 29-pixel buffer overflow. Validate settings and first-screen rendering separately.
4. Confirm Intel HEX checksums and compare changed address ranges before any flash attempt.
5. Flash only after the device is actually in bootloader; use the user's established reset flow if CLI acknowledgement times out.

## Existing handoff history
See `old/Geiger-2-export-2026-10-02.md` and the historical archive `old/GEIGER2_CONTINUATION_EXPORT_2026-10-02.zip` for earlier analysis, address maps, and prior decisions.
