#!/usr/bin/env python3
"""Re-index active firmware glyphs and create three exact bitmap font cards."""
from pathlib import Path
import hashlib
import re
from PIL import Image, ImageDraw, ImageFont

FLASH = 0x08000000
HEX = Path("firmware/approved/port-20261004-1639-dose-labels-7x10-v2.hex")
OLD_MAP = Path("docs/GEIGER2_FONT_MAP_2026-10-04-v6.md")
OUT = Path("assets")
EXPECTED_SHA = "4b77d5d1c9544e8af0d6396945fdf978afd907fcae09b68fb76fd681580608cc"


def decode_hex(path):
    image = bytearray([0xFF]) * 0x10000
    upper = 0
    for line in path.read_text().splitlines():
        if not line.startswith(":"):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, kind = rec[:4]
        data = rec[4:-1]
        if len(data) != n or sum(rec) & 255:
            raise ValueError("bad Intel HEX record")
        if kind == 4:
            upper = int.from_bytes(data, "big") << 16
        elif kind == 0:
            off = upper + (hi << 8) + lo - FLASH
            image[off:off+n] = data
        elif kind == 1:
            break
    return image


def parse_map_sections(md):
    sections = {}
    current = None
    for line in md.splitlines():
        if line.startswith("## 11×18"):
            current = "medium"
            sections[current] = []
        elif line.startswith("## 7×10"):
            current = "small"
            sections[current] = []
        elif line.startswith("## 5×8"):
            current = "tiny"
            sections[current] = []
        elif line.startswith("## "):
            current = None
        elif current and line.startswith("|") and not line.startswith("|---"):
            fields = [s.strip() for s in line.strip("|").split("|")]
            if not fields or not fields[0].isdigit():
                continue
            idx = int(fields[0])
            if current == "medium":
                # Index, code, glyph name, address, raster, note.
                label = fields[2].strip("`")
            elif current == "small":
                # Index, visible glyph, address, raster.
                label = fields[1].strip("`")
            else:
                label = fields[1].strip("`")
            sections[current].append((idx, label))
    return sections


def glyph_rows(image, addr, width, height):
    off = addr - FLASH
    rows = []
    for y in range(height):
        word = int.from_bytes(image[off+y*2:off+y*2+2], "little")
        rows.append([(word >> (15-x)) & 1 for x in range(width)])
    return rows


def draw_card(title, subtitle, entries, width, height, filename, cols, scale, reserved=()):
    tile_w = 180 if width == 11 else 150
    tile_h = 54 + height*scale + 34
    margin, top = 24, 86
    rows = (len(entries) + cols - 1) // cols
    canvas = Image.new("RGB", (margin*2 + cols*tile_w, top + rows*tile_h + 24), (14, 18, 24))
    d = ImageDraw.Draw(canvas)
    f_title = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 27)
    f_sub = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14)
    f_label = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 15)
    f_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 12)
    d.text((margin, 16), title, font=f_title, fill=(245, 248, 252))
    d.text((margin, 52), subtitle, font=f_sub, fill=(163, 178, 194))
    reserved = set(reserved)
    for pos, (idx, code, label, addr, rows_bits) in enumerate(entries):
        x = margin + (pos % cols)*tile_w
        y = top + (pos // cols)*tile_h
        d.rounded_rectangle((x, y, x+tile_w-10, y+tile_h-10), radius=8,
                            fill=(24, 30, 39), outline=(61, 75, 90), width=1)
        d.text((x+10, y+8), f"#{idx:02d}  {code}", font=f_small, fill=(148, 170, 189))
        d.text((x+10, y+26), label, font=f_label, fill=(240, 243, 247))
        gx, gy = x+12, y+54
        if idx in reserved:
            d.rectangle((gx, gy, gx+width*scale-1, gy+height*scale-1), fill=(38, 44, 53), outline=(82, 90, 101))
            d.text((gx+8, gy+height*scale//2-9), "CODE", font=f_small, fill=(237, 176, 83))
        else:
            for yy, row in enumerate(rows_bits):
                for xx, pixel in enumerate(row):
                    color = (240, 244, 250) if pixel else (35, 43, 53)
                    d.rectangle((gx+xx*scale, gy+yy*scale, gx+(xx+1)*scale-1, gy+(yy+1)*scale-1), fill=color)
        d.text((gx, y+tile_h-25), f"0x{addr:08X}" if addr else "custom extension", font=f_small, fill=(141, 157, 174))
    path = OUT / filename
    canvas.save(path, format="PNG", optimize=True)
    return path


if hashlib.sha256(HEX.read_bytes()).hexdigest() != EXPECTED_SHA:
    raise ValueError("approved firmware SHA mismatch")
img = decode_hex(HEX)
descriptors = {
    "11x18-a": (0x0800FCF8, 11, 18, 0x0800F0A8),
    "11x18-b": (0x0800FD00, 11, 18, 0x0800F0A8),
    "7x10": (0x0800FD08, 7, 10, 0x0800F648),
    "5x8": (0x0800FD10, 5, 8, 0x0800F9D4),
}
for _name, (desc, w, h, ptr) in descriptors.items():
    raw = img[desc-FLASH:desc-FLASH+8]
    actual = int.from_bytes(raw[4:8], "little")
    if (raw[0], raw[1], actual) != (w, h, ptr):
        raise ValueError(f"font descriptor mismatch at {desc:#x}")

sections = parse_map_sections(OLD_MAP.read_text())
if len(sections["medium"]) != 40 or len(sections["small"]) != 35 or len(sections["tiny"]) != 12:
    raise ValueError("font map row count mismatch")

OUT.mkdir(parents=True, exist_ok=True)
medium_entries = []
for idx, label in sections["medium"]:
    addr = 0x0800F0A8 + idx*36
    rows = glyph_rows(img, addr, 11, 18) if idx not in (29, 30) else None
    code = f"byte 0x{0x20+idx:02X}"
    medium_entries.append((idx, code, label, addr, rows))

small_entries = []
for idx, label in sections["small"]:
    addr = 0x0800F648 + idx*20
    small_entries.append((idx, f"byte 0x{0x20+idx:02X}", label, addr, glyph_rows(img, addr, 7, 10)))
percent_addr = 0x0800F904
small_entries.append((35, "byte 0x43", "%", percent_addr, glyph_rows(img, percent_addr, 7, 10)))

tiny_entries = []
for idx, label in sections["tiny"]:
    addr = 0x0800F9D4 + idx*16
    tiny_entries.append((idx, f"byte 0x{0x20+idx:02X}", label, addr, glyph_rows(img, addr, 5, 8)))

draw_card("11×18 MEDIUM", "v2 firmware • 38 visible glyphs • slots 29–30 are executable code", medium_entries,
          11, 18, "GEIGER2_FONT_CARD_11x18_MEDIUM_v7.png", 6, 5, reserved=(29, 30))
draw_card("7×10 SMALL", "v2 firmware • 35 mapped glyphs + custom % extension", small_entries,
          7, 10, "GEIGER2_FONT_CARD_7x10_SMALL_v7.png", 6, 7)
draw_card("5×8 TINY", "v2 firmware • 12 glyphs", tiny_entries,
          5, 8, "GEIGER2_FONT_CARD_5x8_TINY_v7.png", 4, 10)
print("indexed firmware:", HEX)
print("descriptors:", {k: hex(v[0]) for k, v in descriptors.items()})
print("cards:", *sorted(p.name for p in OUT.glob("GEIGER2_FONT_CARD_*_v7.png")), sep="\n- ")
