#!/usr/bin/env python3
"""Rebuild the user-confirmed v13 glyph background from the known v5 base."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('firmware/source/port-20261004-0915-main-units-7x10-v5.hex')
OUT = Path('firmware/approved/port-20261004-1050-main-units-7x10-v13-darker-gray.hex')
V5_SHA = 'b9d9a4b065f731a4113eebc33884feaec66a926f851c2b8b93dcf6a71b94c499'
BG = 0x0800A760
OLD = 0x4A49
TEST = 0x2945  # Neutral RGB565 gray, darker than v12


def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        rec = bytes.fromhex(line[1:])
        n, hi, lo, kind = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 255:
            raise ValueError('invalid Intel HEX')
        if kind == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif kind == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError('HEX record outside image')
            image[off:off+n] = data
        elif kind == 1:
            break
    return image


def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])


if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != V5_SHA:
    raise ValueError('v5 source hash mismatch')
image = decode(SOURCE)
bg_off = BG - FLASH
if image[bg_off:bg_off+2] != OLD.to_bytes(2, 'little'):
    raise ValueError('unexpected v5 glyph-background literal')
old_a758 = image[0xA758:0xA75A]
image[bg_off:bg_off+2] = TEST.to_bytes(2, 'little')

OUT.write_text(encode(image))
check = decode(OUT)
if check != image:
    raise AssertionError('HEX round trip mismatch')
for line in OUT.read_text().splitlines():
    if sum(bytes.fromhex(line[1:])) & 255:
        raise AssertionError('Intel HEX checksum failure')
if check[0xA758:0xA75A] != old_a758:
    raise AssertionError('obsolete fill literal changed')
changed = [i for i, (a, b) in enumerate(zip(decode(SOURCE), check)) if a != b]
if changed != [0xA760, 0xA761]:
    raise AssertionError(f'unexpected modified offsets: {changed[:8]}')
print('output:', OUT)
print(f'only changed bytes: 0x0800A760–0x0800A761; RGB565 0x{TEST:04X}, user-confirmed neutral dark gray')
print('v5 renderer, glyphs, labels, wrapper area, settings hooks, and HEX checksums: OK')
print('sha256:', hashlib.sha256(OUT.read_bytes()).hexdigest())
