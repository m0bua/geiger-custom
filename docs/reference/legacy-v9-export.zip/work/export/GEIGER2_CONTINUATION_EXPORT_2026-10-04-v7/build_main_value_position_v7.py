#!/usr/bin/env python3
"""Shift the central MAIN measurement value and its per-glyph background."""
from pathlib import Path
import hashlib

FLASH=0x08000000
SOURCE=Path('firmware/approved/port-20261004-1305-battery-v6.hex')
OUT=Path('firmware/experiments/main/port-20261004-1311-main-value-v7.hex')
ADDRESS_X=0x08009250
ADDRESS_Y=0x0800924E
OLD_X=0x203F  # MOVS r0,#63
NEW_X=0x204A  # MOVS r0,#74: +11 px, one medium 11x18 glyph
OLD_Y=0x211A  # MOVS r1,#26
NEW_Y=0x2123  # MOVS r1,#35: +9 px, half of 18px glyph height
EXPECTED_SHA256='e0e7a86aa692fc19ac178aa894dbdd277b7cf0f6208d55320cdd97277374daaf'

def decode(path):
 image=bytearray([255])*0x10000; upper=0
 for line in path.read_text().splitlines():
  rec=bytes.fromhex(line[1:]); n,hi,lo,kind=rec[:4]; data=rec[4:-1]
  if len(data)!=n or sum(rec)&255: raise ValueError('bad Intel HEX record')
  if kind==4: upper=int.from_bytes(data,'big')<<16
  elif kind==0:
   off=upper+(hi<<8)+lo-FLASH
   if off<0 or off+n>len(image): raise ValueError('address outside image')
   image[off:off+n]=data
  elif kind==1: break
 return image

def encode(image):
 lines=[':020000040800F2']
 for off in range(0,len(image),16):
  rec=bytes([16,off>>8,off&255,0])+image[off:off+16]
  lines.append(':'+ (rec+bytes([-sum(rec)&255])).hex().upper())
 return '\n'.join(lines+[':00000001FF',''])

if hashlib.sha256(SOURCE.read_bytes()).hexdigest()!=EXPECTED_SHA256: raise ValueError('approved v6 hash mismatch')
image=decode(SOURCE)
for addr,old,new in ((ADDRESS_Y,OLD_Y,NEW_Y),(ADDRESS_X,OLD_X,NEW_X)):
 off=addr-FLASH
 if int.from_bytes(image[off:off+2],'little')!=old: raise ValueError(f'unexpected instruction at {addr:#x}')
 image[off:off+2]=new.to_bytes(2,'little')
OUT.parent.mkdir(parents=True,exist_ok=True); OUT.write_text(encode(image))
check=decode(OUT)
if check!=image: raise AssertionError('round-trip mismatch')
for line in OUT.read_text().splitlines():
 if sum(bytes.fromhex(line[1:]))&255: raise AssertionError('Intel HEX checksum failure')
original=decode(SOURCE)
changed=[i for i,(a,b) in enumerate(zip(original,check)) if a!=b]
expected={ADDRESS_X-FLASH,ADDRESS_Y-FLASH}
if set(changed)!=expected: raise AssertionError(f'unexpected changes: {changed}')
print('output:',OUT)
print('central value draw call 0x08009252: x 63->74 (+11 px), y 26->35 (+9 px)')
print('per-glyph background is passed through the same draw call and moves with the value')
print('changed bytes:',len(changed),'SHA-256:',hashlib.sha256(OUT.read_bytes()).hexdigest())
