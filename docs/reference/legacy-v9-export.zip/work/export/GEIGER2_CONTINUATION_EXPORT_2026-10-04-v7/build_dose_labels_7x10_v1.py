#!/usr/bin/env python3
"""Replace the three confirmed DOSE raster labels with 7x10 text.

The draw helper reuses the existing compact battery text renderer and its
already-tested 7x10 font/background setup. The source stays the approved
main-values-up5-v1 image; RGB diagnostic positions are not reused.
"""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path("firmware/source/port-20261004-1540-main-values-up5-v1.hex")
OUT = Path("firmware/experiments/port-20261004-1616-dose-labels-7x10-v1.hex")
BASE_SHA256 = "f246ac3ad2ad31a93aae215bbdf45b5a068d842766bdfffdd5d298688bde55d1"

BATTERY_TEXT_HELPER = 0x0800F4BC
DOSE_TEXT_HELPER = 0x0800F91E
DRAW_SETUP = 0x0800F4DA  # shared 7x10 font/background/draw setup
FONT_7X10 = 0x0800F648
DOSE_LABELS = 0x0800F938

CALLS = [
    (0x0800A250, 4, bytes.fromhex("00 94 9B 00 C9 00"), "µSv"),
    (0x0800A278, 5, bytes.fromhex("00 91 9B 00 0F 49"), "CNT"),
    (0x0800A2A2, 6, bytes.fromhex("00 94 9B 00 09 01"), "µR"),
]


def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(":"):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, kind = rec[:4]
        data = rec[4:-1]
        if len(data) != n or sum(rec) & 0xFF:
            raise ValueError("invalid Intel HEX record")
        if kind == 4:
            upper = int.from_bytes(data, "big") << 16
        elif kind == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError("record outside image")
            image[off:off+n] = data
        elif kind == 1:
            break
    return image


def encode(image):
    lines = [":020000040800F2"]
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(":" + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return "\n".join(lines + [":00000001FF", ""])


def thumb_bl(address, target):
    delta = target - (address + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError("Thumb BL target out of range")
    imm = delta & 0x1FFFFFF
    s, i1, i2 = (imm >> 24) & 1, (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = 1 ^ (i1 ^ s), 1 ^ (i2 ^ s)
    first = 0xF000 | (s << 10) | ((imm >> 12) & 0x3FF)
    second = 0xD000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7FF)
    return first.to_bytes(2, "little") + second.to_bytes(2, "little")


def thumb_b(address, target):
    delta = target - (address + 4)
    if delta & 1 or not -2048 <= delta // 2 <= 2047:
        raise ValueError("Thumb B target out of range")
    return (0xE000 | ((delta // 2) & 0x7FF)).to_bytes(2, "little")


def check_bl(image, address, target):
    off = address - FLASH
    h1 = int.from_bytes(image[off:off+2], "little")
    h2 = int.from_bytes(image[off+2:off+4], "little")
    if h1 & 0xF800 != 0xF000 or h2 & 0xD000 != 0xD000:
        raise AssertionError(f"not Thumb BL at {address:#x}")
    s = (h1 >> 10) & 1
    j1, j2 = (h2 >> 13) & 1, (h2 >> 11) & 1
    i1, i2 = 1 ^ (j1 ^ s), 1 ^ (j2 ^ s)
    imm = (s << 24) | (i1 << 23) | (i2 << 22) | ((h1 & 0x3FF) << 12) | ((h2 & 0x7FF) << 1)
    if s:
        imm -= 1 << 25
    if (address + 4 + imm) & 0xFFFFFFFF != target:
        raise AssertionError(f"wrong BL target at {address:#x}")


def halfwords(*values):
    return b"".join(v.to_bytes(2, "little") for v in values)


def make_battery_helper():
    """Keep selectors 8/9 working and dispatch 4..6 to the dose text path."""
    base = BATTERY_TEXT_HELPER
    code = bytearray()
    labels = {}
    branches = []
    literals = []

    def e16(value):
        code.extend(value.to_bytes(2, "little"))

    def mark(name):
        labels[name] = len(code)

    def branch(name, cond=None):
        at = len(code)
        e16(0)
        branches.append((at, name, cond))

    def ldr(rd, value, key=None):
        at = len(code)
        e16(0x4800 | (rd << 8))
        literals.append((at, value, key))

    def bl(target):
        code.extend(thumb_bl(base + len(code), target))

    e16(0xB510)                 # push {r4,lr}
    e16(0xB084)                 # sub sp,#16
    e16(0x2807)                 # cmp r0,#7
    branch("battery", cond=2)  # selectors 8/9 retain original battery path
    branch("dose_external")
    mark("battery")
    e16(0x2809)                 # cmp r0,#9 (charging)
    branch("charging", cond=0)
    ldr(3, 0xC618)               # gray
    branch("color_ready")
    mark("charging")
    ldr(3, 0x07E0)               # green
    mark("color_ready")
    e16(0x9301)                 # [sp+4] = foreground
    ldr(2, 0, "percent")
    e16(0x2003)                 # x=3
    e16(0x2105)                 # y=5
    mark("draw_setup")
    ldr(3, FONT_7X10)
    e16(0x9300)                 # [sp] = glyph table
    ldr(3, 0x2945)               # tested dark-gray glyph background
    e16(0x9302)                 # [sp+8] = background
    e16(0x230A)
    e16(0x021B)
    e16(0x3307)                 # r3=(10<<8)|7
    bl(0x08008E48)
    e16(0xB004)                 # add sp,#16
    e16(0xBD10)                 # pop {r4,pc}

    while (base + len(code)) & 3:
        code.append(0)
    pool = {}
    for at, value, key in literals:
        pool[(value, key)] = len(code)
        resolved = 0x0800F918 if key == "percent" else value
        code.extend(resolved.to_bytes(4, "little"))
    for at, value, key in literals:
        pos = pool[(value, key)]
        pc = (base + at + 4) & ~3
        delta = base + pos - pc
        if delta < 0 or delta > 1020 or delta & 3:
            raise ValueError("battery helper literal out of range")
        rd = (int.from_bytes(code[at:at+2], "little") >> 8) & 7
        code[at:at+2] = (0x4800 | rd << 8 | delta//4).to_bytes(2, "little")

    for at, name, cond in branches:
        source = base + at
        target = DOSE_TEXT_HELPER if name == "dose_external" else base + labels[name]
        delta = target - (source + 4)
        if delta & 1:
            raise ValueError("unaligned battery helper branch")
        imm = delta // 2
        if cond is None:
            if not -1024 <= imm <= 1023:
                raise ValueError("battery helper branch out of range")
            op = 0xE000 | (imm & 0x7FF)
        else:
            if not -128 <= imm <= 127:
                raise ValueError("battery helper conditional branch out of range")
            op = 0xD000 | (cond << 8) | (imm & 0xFF)
        code[at:at+2] = op.to_bytes(2, "little")
    if len(code) > 72:
        raise ValueError(f"battery helper too large: {len(code)}")
    return bytes(code), base + labels["draw_setup"]


LABEL_DATA = 0x0800F938


if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != BASE_SHA256:
    raise ValueError("approved source SHA-256 mismatch")
image = decode(SOURCE)

# The unused 7x10 extension hole and the twelve trailing helper bytes are the
# only new storage used. Keep the battery helper's bg/font/literals untouched.
if image[0x0800F91D-FLASH:0x0800F944-FLASH] != b"\xFF" * 39:
    raise ValueError("expected erased 7x10 code gap")
if image[0x0800F4FC-FLASH:0x0800F504-FLASH] != b"\x00" * 8:
    raise ValueError("battery helper tail is not unused")

# Extend the already-tested battery helper by using its unused tail. It now
# shares font/color setup between battery strings and the new dose labels.
battery_helper, DRAW_SETUP = make_battery_helper()
image[BATTERY_TEXT_HELPER-FLASH:BATTERY_TEXT_HELPER-FLASH+72] = bytes(72)
image[BATTERY_TEXT_HELPER-FLASH:BATTERY_TEXT_HELPER-FLASH+len(battery_helper)] = battery_helper

# r0 is selector 4..6. Convert it to a 4-byte string slot, load the string,
# set white foreground and (118,34), then join the existing tested draw setup.
code = bytearray(halfwords(
    0x3804,             # subs r0,#4
    0x0080,             # lsls r0,r0,#2
    0x4A04,             # ldr r2,[pc,#16] -> pointer at F934
    0x1812,             # adds r2,r0
    0x2300,             # movs r3,#0
    0x43DB,             # mvns r3,r3 -> white 0xffff
    0x9301,             # str r3,[sp,#4]
    0x2076,             # movs r0,#118
    0x2122,             # movs r1,#34
))
code += thumb_b(DOSE_TEXT_HELPER + len(code), DRAW_SETUP)
while (DOSE_TEXT_HELPER + len(code)) & 3:
    code.append(0)
if DOSE_TEXT_HELPER + len(code) != 0x0800F934:
    raise AssertionError("literal pool alignment changed")
code += DOSE_LABELS.to_bytes(4, "little")
labels = (
    bytes.fromhex("3F 3D 41 00") +  # µSv
    bytes.fromhex("29 21 25 00") +  # CNT
    bytes.fromhex("3F 22 00 00")    # µR
)
code += labels
if len(code) != 38:
    raise AssertionError(f"unexpected extension size: {len(code)}")
image[DOSE_TEXT_HELPER-FLASH:0x0800F944-FLASH] = code

for call, selector, expected, _label in CALLS:
    off = call - FLASH
    if image[off-6:off] != expected:
        raise ValueError(f"unexpected pre-call setup at {call:#x}")
    if int.from_bytes(image[off:off+4], "little") != int.from_bytes(thumb_bl(call, 0x0800AFE4), "little"):
        raise ValueError(f"call at {call:#x} is not the confirmed bitmap renderer")
    image[off-6:off] = halfwords(0x2000 | selector, 0xBF00, 0xBF00)
    image[off:off+4] = thumb_bl(call, BATTERY_TEXT_HELPER)

OUT.write_text(encode(image))
check = decode(OUT)
if check != image:
    raise AssertionError("HEX round-trip mismatch")
for line in OUT.read_text().splitlines():
    if sum(bytes.fromhex(line[1:])) & 0xFF:
        raise AssertionError("Intel HEX checksum failure")
for call, _, _, _ in CALLS:
    check_bl(check, call, BATTERY_TEXT_HELPER)
check_bl(check, 0x0800A6B4, BATTERY_TEXT_HELPER)
check_bl(check, 0x0800A6DA, BATTERY_TEXT_HELPER)
if check[0xF938:0xF944] != labels:
    raise AssertionError("dose label strings differ from expected custom glyph codes")
if check[0xF4C0:0xF4C6] != bytes.fromhex("07 28 00 D2 2B E2"):
    raise AssertionError("battery/dose selector dispatch differs from expected")
changed = {i for i, (a, b) in enumerate(zip(decode(SOURCE), check)) if a != b}
allowed = set(range(0xF4BC, 0xF504)) | set(range(0xF91E, 0xF944))
for call, *_ in CALLS:
    allowed |= set(range(call-FLASH-6, call-FLASH+4))
if changed - allowed:
    raise AssertionError(f"unexpected modified bytes: {sorted(changed - allowed)}")
if check[0xA6B4-FLASH:0xA6B8-FLASH] != decode(SOURCE)[0xA6B4-FLASH:0xA6B8-FLASH]:
    raise AssertionError("battery charging call changed")
print("output:", OUT)
print("base: approved main-values-up5-v1")
print("labels: µSv / CNT / µR, 7x10 font, white on existing dark-gray glyph cells")
print("screen origin: (118,34), inferred from the original DOSE screenshot")
print("battery selectors 8/9 and all confirmed no-touch blocks retained")
print("HEX checksums, round-trip, call targets, patch bounds: OK")
print("changed bytes:", len(changed))
print("sha256:", hashlib.sha256(OUT.read_bytes()).hexdigest())
