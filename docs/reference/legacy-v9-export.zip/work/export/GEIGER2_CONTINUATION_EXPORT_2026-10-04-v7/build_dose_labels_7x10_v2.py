#!/usr/bin/env python3
"""Build v2 of the DOSE 7x10 label test from the v1 test HEX."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path("firmware/experiments/port-20261004-1616-dose-labels-7x10-v1.hex")
OUT = Path("firmware/approved/port-20261004-1639-dose-labels-7x10-v2.hex")
SOURCE_SHA256 = "3774b850a7fef797c11ee9e59b41283eb537f59680f627c930b39181499e6acf"
HELPER = 0x0800F4BC
LABEL_ROUTINE = 0x0800F91E
LABEL_BYTES = 0x0800F938
CALLS = [
    (0x0800A250, 4, 118, "µSv", bytes.fromhex("04 20 00 BF 00 BF")),
    (0x0800A278, 5, 129, "µR",  bytes.fromhex("05 20 00 BF 00 BF")),
    (0x0800A2A2, 6, 129, "CNT", bytes.fromhex("06 20 00 BF 00 BF")),
]


def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(":"):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, kind = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 255:
            raise ValueError("invalid Intel HEX record")
        if kind == 4:
            upper = int.from_bytes(data, "big") << 16
        elif kind == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError("record outside firmware image")
            image[off:off+n] = data
        elif kind == 1:
            break
    return image


def encode(image):
    lines = [":020000040800F2"]
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(":" + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return "\n".join(lines + [":00000001FF", ""])


def thumb_bl(address, target):
    delta = target - (address + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError("Thumb BL out of range")
    imm = delta & 0x1FFFFFF
    s, i1, i2 = (imm >> 24) & 1, (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = 1 ^ (i1 ^ s), 1 ^ (i2 ^ s)
    h1 = 0xF000 | (s << 10) | ((imm >> 12) & 0x3FF)
    h2 = 0xD000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7FF)
    return h1.to_bytes(2, "little") + h2.to_bytes(2, "little")


def check_bl(image, address, target):
    off = address - FLASH
    h1 = int.from_bytes(image[off:off+2], "little")
    h2 = int.from_bytes(image[off+2:off+4], "little")
    if h1 & 0xF800 != 0xF000 or h2 & 0xD000 != 0xD000:
        raise AssertionError(f"not a Thumb BL at {address:#x}")
    s = (h1 >> 10) & 1
    j1, j2 = (h2 >> 13) & 1, (h2 >> 11) & 1
    i1, i2 = 1 ^ (j1 ^ s), 1 ^ (j2 ^ s)
    imm = (s << 24) | (i1 << 23) | (i2 << 22) | ((h1 & 0x3FF) << 12) | ((h2 & 0x7FF) << 1)
    if s:
        imm -= 1 << 25
    if (address + 4 + imm) & 0xFFFFFFFF != target:
        raise AssertionError(f"unexpected Thumb BL target at {address:#x}")


if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
    raise ValueError("v1 SHA-256 mismatch")
image = decode(SOURCE)

# V1 kept µSv at (118,34), but used the other two labels on the wrong calls.
# Keep µSv x=118; move the green µR and blue CNT 11 px right. Set all y=38.
for call, selector, x, _label, expected in CALLS:
    off = call - FLASH
    if image[off-6:off] != expected:
        raise ValueError(f"unexpected v1 setup at {call:#x}")
    check_bl(image, call, HELPER)
    image[off-6:off] = b"".join(v.to_bytes(2, "little") for v in (
        0x2000 | selector, 0x2100 | x, 0xBF00
    ))

routine_off = LABEL_ROUTINE - FLASH
if image[routine_off:routine_off+20] != bytes.fromhex(
    "04 38 80 00 04 4A 12 18 00 23 DB 43 01 93 76 20 22 21 D2 E5"
):
    raise ValueError("v1 label helper differs from expected code")
# mov r0,r1 (the per-call x coordinate), then y=38 (34+4 px).
image[routine_off+14:routine_off+18] = bytes.fromhex("08 00 26 21")

# Selector order is red µSv, green µR, blue CNT.
labels = bytes.fromhex(
    "3F 3D 41 00"  # µSv
    "3F 22 00 00"  # µR
    "29 21 25 00"  # CNT
)
image[LABEL_BYTES-FLASH:LABEL_BYTES-FLASH+12] = labels

OUT.write_text(encode(image))
check = decode(OUT)
if check != image:
    raise AssertionError("HEX round-trip mismatch")
for line in OUT.read_text().splitlines():
    if sum(bytes.fromhex(line[1:])) & 255:
        raise AssertionError("Intel HEX checksum failure")
for call, *_ in CALLS:
    check_bl(check, call, HELPER)
if check[LABEL_BYTES-FLASH:LABEL_BYTES-FLASH+12] != labels:
    raise AssertionError("label strings differ from custom 7x10 codes")
changed = {i for i, (a, b) in enumerate(zip(decode(SOURCE), check)) if a != b}
allowed = set(range(0xF92C, 0xF930)) | set(range(0xF938, 0xF944))
for call, *_ in CALLS:
    allowed |= set(range(call-FLASH-6, call-FLASH))
if changed - allowed:
    raise AssertionError(f"unexpected changed offsets: {sorted(changed - allowed)}")
print("output:", OUT)
print("base: v1 dose-label test HEX")
print("red µSv: (118,38); green µR and blue CNT: (129,38)")
print("Intel HEX checksums, round-trip, call targets, and patch bounds: OK")
print("changed bytes:", len(changed))
print("sha256:", hashlib.sha256(OUT.read_bytes()).hexdigest())
