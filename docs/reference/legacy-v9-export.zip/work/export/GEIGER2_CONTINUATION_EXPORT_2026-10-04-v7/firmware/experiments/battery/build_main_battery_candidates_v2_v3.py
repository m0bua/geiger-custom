#!/usr/bin/env python3
"""Build isolated battery-screen resource-call candidates from confirmed v13."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('firmware/experiments/battery/v13-base.hex')
SOURCE_SHA256 = '86c47e1c2f4873ce0b585f644b8ae1cb7ce8d9eb1da1e3aa4a2313266ac64995'
NOP_PAIR = bytes.fromhex('00 BF 00 BF')
CANDIDATES = {
    0x0800A6DA: Path('firmware/experiments/battery/port-20261004-main-battery-v2-dynamic-17x17.hex'),
    0x0800A6B4: Path('firmware/experiments/battery/port-20261004-main-battery-v3-static-24x12.hex'),
}


def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        rec = bytes.fromhex(line[1:])
        n, hi, lo, kind = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 0xFF:
            raise ValueError('invalid Intel HEX record')
        if kind == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif kind == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError('HEX record outside firmware image')
            image[off:off+n] = data
        elif kind == 1:
            break
    return image


def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 0xFF, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 0xFF])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])


def check_bl_target(image, address, expected=0x0800AFE4):
    offset = address - FLASH
    h1 = int.from_bytes(image[offset:offset+2], 'little')
    h2 = int.from_bytes(image[offset+2:offset+4], 'little')
    if h1 & 0xF800 != 0xF000 or h2 & 0xD000 != 0xD000:
        raise ValueError(f'not a Thumb BL at 0x{address:08X}')
    s = (h1 >> 10) & 1
    j1, j2 = (h2 >> 13) & 1, (h2 >> 11) & 1
    i1, i2 = 1 ^ (j1 ^ s), 1 ^ (j2 ^ s)
    imm = (s << 24) | (i1 << 23) | (i2 << 22) | ((h1 & 0x3FF) << 12) | ((h2 & 0x7FF) << 1)
    if s:
        imm -= 1 << 25
    target = (address + 4 + imm) & 0xFFFFFFFE
    if target != expected:
        raise ValueError(f'0x{address:08X} targets 0x{target:08X}')


if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
    raise ValueError('v13 source SHA-256 mismatch')
base = decode(SOURCE)
for address, output in CANDIDATES.items():
    image = bytearray(base)
    check_bl_target(image, address)
    offset = address - FLASH
    image[offset:offset+4] = NOP_PAIR
    output.write_text(encode(image))
    check = decode(output)
    if check != image:
        raise AssertionError('Intel HEX round-trip mismatch')
    for line in output.read_text().splitlines():
        if sum(bytes.fromhex(line[1:])) & 0xFF:
            raise AssertionError('Intel HEX checksum failure')
    changed = [i for i, (a, b) in enumerate(zip(base, check)) if a != b]
    expected_changed = [i for i in range(offset, offset+4) if base[i] != check[i]]
    if changed != expected_changed:
        raise AssertionError(f'unexpected changed bytes at {changed}')
    print(output, 'SHA-256', hashlib.sha256(output.read_bytes()).hexdigest())
