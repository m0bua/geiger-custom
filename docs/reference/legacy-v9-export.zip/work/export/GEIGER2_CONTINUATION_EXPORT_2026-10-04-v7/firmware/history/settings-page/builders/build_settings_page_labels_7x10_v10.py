#!/usr/bin/env python3
"""Restore SETTINGS labels to original raster-grid anchors and shared state slots."""
from pathlib import Path
import hashlib
FLASH=0x08000000
BASE=Path(__file__).resolve().parent/'port-20261004-1954-settings-page-labels-7x10-v9.hex'
OUT=Path(__file__).resolve().parent/'port-20261004-2000-settings-page-labels-7x10-v10.hex'
BASE_SHA='23eab35f0431b4a679c8af0a8cee5759a30079d0200ac3196e94e077c71ae78c'
CALLS={
 0x0800B406:(3,106,'sound ON'),
 0x0800B430:(4,137,'diode ON'),
 0x0800B4D2:(5,103,'sound OFF'),
 0x0800B4F6:(6,134,'diode OFF'),
 0x0800B51C:(0,73,'Sv'),
 0x0800B542:(1,73,'CPM'),
 0x0800B566:(2,73,'R'),
}
def decode(path):
 im=bytearray([255])*0x10000; upper=0
 for line in path.read_text().splitlines():
  if not line.startswith(':'): continue
  rec=bytes.fromhex(line[1:]); n,hi,lo,typ=rec[:4]; data=rec[4:-1]
  if sum(rec)&255 or len(data)!=n: raise ValueError('bad HEX record')
  if typ==4: upper=int.from_bytes(data,'big')<<16
  elif typ==0:
   off=upper+(hi<<8)+lo-FLASH
   im[off:off+n]=data
  elif typ==1: break
 return im
def encode(im):
 lines=[':020000040800F2']
 for off in range(0,len(im),16):
  rec=bytes([16,off>>8,off&255,0])+im[off:off+16]
  lines.append(':'+ (rec+bytes([(-sum(rec))&255])).hex().upper())
 return '\n'.join(lines+[':00000001FF',''])
if hashlib.sha256(BASE.read_bytes()).hexdigest()!=BASE_SHA: raise ValueError('base SHA mismatch')
im=decode(BASE)
# Keep the screen-matched y-coordinate from v9.
assert im[0xF982:0xF984]==bytes.fromhex('1C 21')
# Requested final tuning from v9: units -4 px; ON states +3 px; OFF states unchanged.
# ON/OFF variants share one anchor per control, as required by the user.
for addr,(selector,x,name) in CALLS.items():
 off=addr-FLASH
 assert int.from_bytes(im[off-6:off-4],'little')==0x2000|selector, (hex(addr),name)
 im[off-4:off-2]=(0x2100|x).to_bytes(2,'little')
# Disable four unclassified SETTINGS raster blocks identified during RGB probing.
UNKNOWN_BLOCK_CALLS=(0x0800B36E,0x0800B38A,0x0800B3B0,0x0800B3DC)
for addr in UNKNOWN_BLOCK_CALLS:
 off=addr-FLASH
 h1=int.from_bytes(im[off:off+2],'little'); h2=int.from_bytes(im[off+2:off+4],'little')
 assert h1&0xF800==0xF000 and h2&0xD000==0xD000, hex(addr)
 im[off:off+4]=bytes.fromhex('00 BF 00 BF')
# The full-screen clear helper is already used by other page transitions. Reuse the
# title call slot on SETTINGS entry so the page is cleared once before drawing.
def thumb_bl(at,target):
 delta=target-(at+4)
 assert not delta&1 and -(1<<24)<=delta<(1<<24)
 imm=delta&0x1FFFFFF
 ss=(imm>>24)&1; i1=(imm>>23)&1; i2=(imm>>22)&1
 j1=1^(i1^ss); j2=1^(i2^ss)
 a=0xF000|(ss<<10)|((imm>>12)&0x3FF)
 b=0xD000|(j1<<13)|(j2<<11)|((imm>>1)&0x7FF)
 return a.to_bytes(2,'little')+b.to_bytes(2,'little')
clear_call=0x0800B31A
clear_off=clear_call-FLASH
assert im[clear_off:clear_off+4]==bytes.fromhex('00 BF 00 BF')
im[clear_off:clear_off+4]=thumb_bl(clear_call,0x08008F70)
OUT.write_text(encode(im))
check=decode(OUT)
assert check==im
for line in OUT.read_text().splitlines():
 if sum(bytes.fromhex(line[1:]))&255: raise AssertionError('checksum')
print('Output:',OUT)
print('SHA-256:',hashlib.sha256(OUT.read_bytes()).hexdigest())
print('Coordinates: units x=73; speaker ON/OFF x=106 (ON) / 103 (OFF); sun x=137 (ON) / 134 (OFF); y=28.')
