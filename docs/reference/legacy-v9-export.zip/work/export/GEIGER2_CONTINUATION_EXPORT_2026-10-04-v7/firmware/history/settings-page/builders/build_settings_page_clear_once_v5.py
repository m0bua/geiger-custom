#!/usr/bin/env python3
"""One gray SETTINGS clear per transition; carry first-entry state in r6."""
from pathlib import Path
import hashlib
FLASH=0x08000000
BASE=Path(__file__).resolve().parent/'port-20261004-2043-settings-fill-probe-v1.hex'
OUT=Path(__file__).resolve().parent/'port-20261004-2227-settings-page-clear-v5.hex'
BASE_SHA='fdf2055c37649edaa725c8df30127ca284688183c45a77fd354d404facb09205'
GUARD=0x0800B2D8; SLOT=0x0800B316; LDR=0x0800B318; CALL=0x0800B31A; RESUME=0x0800B31E
GRAY=0x0800B5A4; FILL=0x08008F70

def dec(p):
 im=bytearray([255])*0x10000; upper=0
 for line in p.read_text().splitlines():
  if not line.startswith(':'):continue
  r=bytes.fromhex(line[1:]); n,hi,lo,t=r[:4]; d=r[4:-1]
  if len(d)!=n or sum(r)&255:raise ValueError('bad hex')
  if t==4: upper=int.from_bytes(d,'big')<<16
  elif t==0:
   o=upper+(hi<<8)+lo-FLASH
   if not 0<=o<=len(im)-n:raise ValueError('range')
   im[o:o+n]=d
  elif t==1:break
 return im
def enc(im):
 out=[':020000040800F2']
 for o in range(0,len(im),16):
  r=bytes([16,o>>8,o&255,0])+im[o:o+16]
  out.append(':'+(r+bytes([(-sum(r))&255])).hex().upper())
 return '\n'.join(out+[':00000001FF',''])
def bl(at,tgt):
 d=tgt-(at+4)
 if d&1 or not -(1<<24)<=d<(1<<24):raise ValueError('BL range')
 x=d&0x1ffffff;s=x>>24&1;i1=x>>23&1;i2=x>>22&1;j1=1^(i1^s);j2=1^(i2^s)
 a=0xf000|(s<<10)|((x>>12)&0x3ff);b=0xd000|(j1<<13)|(j2<<11)|((x>>1)&0x7ff)
 return a.to_bytes(2,'little')+b.to_bytes(2,'little')
def bl_tgt(im,a):
 o=a-FLASH;h1=int.from_bytes(im[o:o+2],'little');h2=int.from_bytes(im[o+2:o+4],'little')
 if h1&0xf800!=0xf000 or h2&0xd000!=0xd000:raise ValueError('not BL')
 s=h1>>10&1;j1=h2>>13&1;j2=h2>>11&1;i1=1^(j1^s);i2=1^(j2^s)
 x=(s<<24)|(i1<<23)|(i2<<22)|((h1&0x3ff)<<12)|((h2&0x7ff)<<1)
 if s:x-=1<<25
 return (a+4+x)&0xffffffff

if hashlib.sha256(BASE.read_bytes()).hexdigest()!=BASE_SHA:raise ValueError('base SHA')
im=dec(BASE); old=bytes(im)
# r6 is saved by the renderer's prologue and is not used until after B31E.
# It holds 0 on first entry and 1 on redraw; the state byte itself remains unchanged.
assert im[GUARD-FLASH:GUARD-FLASH+16]==bytes.fromhex('03 4B 1B 78 00 2B 02 D1 01 4B 01 22 1A 70 70 47')
assert im[SLOT-FLASH:SLOT-FLASH+8]==bytes.fromhex('00 BF 00 BF 00 BF 00 BF')
assert im[GRAY-FLASH:GRAY-FLASH+4]==bytes.fromhex('25 19 00 00')
im[GUARD-FLASH:GUARD-FLASH+16]=bytes.fromhex('03 4B 1E 78 00 2E 02 D1 01 4B 01 22 1A 70 70 47')
# CBNZ r6, B31E: skip clear for redraws. On first entry it falls through.
delta=RESUME-(SLOT+4)
assert delta==4
cbnz=0xB900 | (((delta>>1)&0x1f)<<3) | 6
im[SLOT-FLASH:SLOT-FLASH+2]=cbnz.to_bytes(2,'little')
pc=(LDR+4)&~3; d=GRAY-pc
assert 0<=d<=1020 and d%4==0
im[LDR-FLASH:LDR-FLASH+2]=(0x4800|(d//4)).to_bytes(2,'little')
im[CALL-FLASH:CALL-FLASH+4]=bl(CALL,FILL)
assert bl_tgt(im,CALL)==FILL
OUT.write_text(enc(im)); ck=dec(OUT)
assert ck==im
for line in OUT.read_text().splitlines():assert not(sum(bytes.fromhex(line[1:]))&255)
changed={i for i,(a,b) in enumerate(zip(old,ck)) if a!=b}
allowed=set(range(GUARD-FLASH,GUARD-FLASH+16))|set(range(SLOT-FLASH,SLOT-FLASH+2))|set(range(LDR-FLASH,LDR-FLASH+2))|set(range(CALL-FLASH,CALL-FLASH+4))
assert changed<=allowed,sorted(changed-allowed)
print('Output:',OUT);print('SHA-256:',hashlib.sha256(OUT.read_bytes()).hexdigest())
print('r6=0 on first SETTINGS entry: load gray 0x1925, BL full clear, resume at B31E.')
print('r6=1 on later redraws: CBNZ skips directly to B31E. Seven repeat fills remain disabled.')
