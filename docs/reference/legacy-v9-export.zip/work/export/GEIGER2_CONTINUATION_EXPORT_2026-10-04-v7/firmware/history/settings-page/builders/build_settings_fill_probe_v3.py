#!/usr/bin/env python3
"""Add the normal one-shot charcoal SETTINGS clear to the fill probe."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
BASE = Path(__file__).resolve().parent / "port-20261004-2043-settings-fill-probe-v1.hex"
OUT = Path(__file__).resolve().parent / "port-20261004-2052-settings-fill-probe-v3.hex"
BASE_SHA = "fdf2055c37649edaa725c8df30127ca284688183c45a77fd354d404facb09205"
STATE_HELPER = 0x0800B2D8
SETTINGS_SLOT = 0x0800B316
ROUTE_SLOT = 0x0800B318
CODE_CAVE = 0x0800A6FC
GRAY_FILL = 0x08008F70
STATE_PTR = 0x200004FE
GRAY565 = 0x1925  # Same color literal used by the firmware's normal full-screen clear.

def decode(path):
    im = bytearray([255]) * 0x20000
    upper = 0
    for line in path.read_text().splitlines():
        if not line.startswith(":"):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if len(data) != n or sum(rec) & 0xFF:
            raise ValueError("bad Intel HEX record")
        if typ == 4:
            upper = int.from_bytes(data, "big") << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(im):
                raise ValueError("record outside flash")
            im[off:off+n] = data
        elif typ == 1:
            break
    return im

def encode(im):
    lines = []
    upper = None
    for off in range(0, min(len(im), 0x10000), 16):
        next_upper = 0x0800 + (off >> 16)
        if next_upper != upper:
            upper = next_upper
            rec = bytes([2, 0, 0, 4]) + upper.to_bytes(2, "big")
            lines.append(":" + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
        rec = bytes([16, (off >> 8) & 255, off & 255, 0]) + im[off:off+16]
        lines.append(":" + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return "\n".join(lines + [":00000001FF", ""])

def thumb_bl(at, target):
    delta = target - (at + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError("BL target out of range")
    imm = delta & 0x1FFFFFF
    s = (imm >> 24) & 1
    i1, i2 = (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = 1 ^ (i1 ^ s), 1 ^ (i2 ^ s)
    h1 = 0xF000 | (s << 10) | ((imm >> 12) & 0x3FF)
    h2 = 0xD000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7FF)
    return h1.to_bytes(2, "little") + h2.to_bytes(2, "little")

def thumb_b_wide(at, target):
    delta = target - (at + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError("B.W target out of range")
    imm = delta & 0x1FFFFFF
    s = (imm >> 24) & 1
    i1, i2 = (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = 1 ^ (i1 ^ s), 1 ^ (i2 ^ s)
    h1 = 0xF000 | (s << 10) | ((imm >> 12) & 0x3FF)
    h2 = 0x9000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7FF)
    return h1.to_bytes(2, "little") + h2.to_bytes(2, "little")

def thumb_b_short(at, target):
    delta = target - (at + 4)
    if delta & 1 or not -2048 <= delta <= 2046:
        raise ValueError("short B target out of range")
    return (0xE000 | ((delta >> 1) & 0x7FF)).to_bytes(2, "little")

def put(im, addr, data):
    off = addr - FLASH
    im[off:off+len(data)] = data

if hashlib.sha256(BASE.read_bytes()).hexdigest() != BASE_SHA:
    raise ValueError("base SHA mismatch")
im = decode(BASE)
original = bytes(im)

# The original state byte is reset on screen changes. This keeps the fill one-shot
# until the next transition, matching the firmware's existing page-entry guard.
assert im[STATE_HELPER-FLASH:STATE_HELPER-FLASH+16] == bytes.fromhex(
    "03 4B 1B 78 00 2B 02 D1 01 4B 01 22 1A 70 70 47")
assert im[SETTINGS_SLOT-FLASH:SETTINGS_SLOT-FLASH+8] == bytes.fromhex(
    "00 BF 00 BF 00 BF 00 BF")
assert im[CODE_CAVE-FLASH:CODE_CAVE-FLASH+16] == bytes.fromhex(
    "00 BF 00 BF 00 BF 00 BF 00 BF 00 BF 00 BF 00 BF")

# Rework the state helper: only the first call after the transition sets the byte
# and branches into the fill stub. Later calls return immediately.
state_code = bytes.fromhex("03 4B 1A 78 00 2A 02 D1 01 22 1A 70")
state_code += thumb_b_short(STATE_HELPER + 12, ROUTE_SLOT)
state_code += bytes.fromhex("70 47")
assert len(state_code) == 16
put(im, STATE_HELPER, state_code)

# Normal rendering skips the code stub. The guarded first-entry route goes to it.
put(im, SETTINGS_SLOT, thumb_b_short(SETTINGS_SLOT, 0x0800B31E))
put(im, ROUTE_SLOT, thumb_b_wide(ROUTE_SLOT, CODE_CAVE + 2))

# This NOP region is otherwise executed as padding. A short branch skips the helper
# during ordinary flow; the one-shot route enters at CODE_CAVE+2.
put(im, CODE_CAVE, thumb_b_short(CODE_CAVE, CODE_CAVE + 12))
stub = bytes.fromhex("19 20 00 02 25 30") + thumb_b_wide(CODE_CAVE + 2 + 6, GRAY_FILL)
put(im, CODE_CAVE + 2, stub)

OUT.write_text(encode(im))
check = decode(OUT)
if check != im:
    raise AssertionError("HEX roundtrip mismatch")
for line in OUT.read_text().splitlines():
    if sum(bytes.fromhex(line[1:])) & 0xFF:
        raise AssertionError("checksum failure")
changed = {i for i, (a, b) in enumerate(zip(original, check)) if a != b}
allowed = set(range(STATE_HELPER-FLASH, STATE_HELPER-FLASH+16))
allowed |= set(range(SETTINGS_SLOT-FLASH, SETTINGS_SLOT-FLASH+2))
allowed |= set(range(ROUTE_SLOT-FLASH, ROUTE_SLOT-FLASH+4))
allowed |= set(range(CODE_CAVE-FLASH, CODE_CAVE-FLASH+12))
if changed - allowed:
    raise AssertionError(f"unexpected patch bounds: {sorted(changed - allowed)}")
assert int.from_bytes(GRAY565.to_bytes(2, "little"), "little") == 0x1925
print("Output:", OUT)
print("SHA-256:", hashlib.sha256(OUT.read_bytes()).hexdigest())
print("One-shot settings clear uses the firmware's 0x1925 dark-gray full-screen color.")
print("The seven rectangle-fill calls remain disabled; option text and icon calls remain intact.")
print("HEX checksums, round-trip, state guard and patch bounds: OK")
