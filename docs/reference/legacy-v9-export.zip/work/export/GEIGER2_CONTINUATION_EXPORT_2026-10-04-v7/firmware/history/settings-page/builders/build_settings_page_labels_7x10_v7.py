#!/usr/bin/env python3
"""Restore SETTINGS labels to original raster-grid anchors and shared state slots."""
from pathlib import Path
import hashlib
FLASH=0x08000000
BASE=Path(__file__).resolve().parent/'port-20261004-1944-settings-page-labels-7x10-v6.hex'
OUT=Path(__file__).resolve().parent/'port-20261004-1947-settings-page-labels-7x10-v7.hex'
BASE_SHA='73a0eb92877c3b5b1a3a67f3d290c3043eba0decd76d7370dde1d3ae73fc1739'
CALLS={
 0x0800B406:(3,86,'sound ON'),
 0x0800B430:(4,109,'diode ON'),
 0x0800B4D2:(5,86,'sound OFF'),
 0x0800B4F6:(6,109,'diode OFF'),
 0x0800B51C:(0,60,'Sv'),
 0x0800B542:(1,60,'CPM'),
 0x0800B566:(2,60,'R'),
}
def decode(path):
 im=bytearray([255])*0x10000; upper=0
 for line in path.read_text().splitlines():
  if not line.startswith(':'): continue
  rec=bytes.fromhex(line[1:]); n,hi,lo,typ=rec[:4]; data=rec[4:-1]
  if sum(rec)&255 or len(data)!=n: raise ValueError('bad HEX record')
  if typ==4: upper=int.from_bytes(data,'big')<<16
  elif typ==0:
   off=upper+(hi<<8)+lo-FLASH
   im[off:off+n]=data
  elif typ==1: break
 return im
def encode(im):
 lines=[':020000040800F2']
 for off in range(0,len(im),16):
  rec=bytes([16,off>>8,off&255,0])+im[off:off+16]
  lines.append(':'+ (rec+bytes([(-sum(rec))&255])).hex().upper())
 return '\n'.join(lines+[':00000001FF',''])
if hashlib.sha256(BASE.read_bytes()).hexdigest()!=BASE_SHA: raise ValueError('base SHA mismatch')
im=decode(BASE)
# Helper y-coordinate literal: original screen raster row origin is 14 px.
assert im[0xF982:0xF984]==bytes.fromhex('18 21')
# Screenshot-derived LCD anchors: x=57 (units), 83 (speaker), 106 (sun).
# ON/OFF variants share one anchor per control, as required by the user.
for addr,(selector,x,name) in CALLS.items():
 off=addr-FLASH
 assert int.from_bytes(im[off-6:off-4],'little')==0x2000|selector, (hex(addr),name)
 im[off-4:off-2]=(0x2100|x).to_bytes(2,'little')
OUT.write_text(encode(im))
check=decode(OUT)
assert check==im
for line in OUT.read_text().splitlines():
 if sum(bytes.fromhex(line[1:]))&255: raise AssertionError('checksum')
print('Output:',OUT)
print('SHA-256:',hashlib.sha256(OUT.read_bytes()).hexdigest())
print('Coordinates: units x=60; speaker ON/OFF x=86; sun ON/OFF x=109; y=24.')
