#!/usr/bin/env python3
"""Keep SETTINGS icons/values, suppress repeat fills, and clear once on entry."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
BASE = Path(__file__).resolve().parent / "port-20261004-2043-settings-fill-probe-v1.hex"
OUT = Path(__file__).resolve().parent / "port-20261004-2207-settings-page-clear-v2.hex"
BASE_SHA = "fdf2055c37649edaa725c8df30127ca284688183c45a77fd354d404facb09205"
STATE = 0x0800B2D8
NORMAL_SKIP = 0x0800B316
FILL_STUB = 0x0800B318
FILL_CALL = 0x0800B31A
COLOR_LITERAL = 0x0800B5A4
FILL_SCREEN = 0x08008F70
FILL_CALLS = (0x0800B454, 0x0800B462, 0x0800B470, 0x0800B47E,
              0x0800B48C, 0x0800B49A, 0x0800B4A8)
LABEL_CALLS = (0x0800B406, 0x0800B430, 0x0800B4D2, 0x0800B4F6,
               0x0800B51C, 0x0800B542, 0x0800B566)
ASSET_CALLS = (0x0800B334, 0x0800B34C, 0x0800B36E, 0x0800B38A,
               0x0800B3B0, 0x0800B3DC)

def decode(path):
    im = bytearray([255]) * 0x10000
    upper = 0
    for line in path.read_text().splitlines():
        if not line.startswith(":"):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if len(data) != n or sum(rec) & 0xFF:
            raise ValueError("bad Intel HEX record")
        if typ == 4:
            upper = int.from_bytes(data, "big") << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(im):
                raise ValueError("record outside 64 KiB flash")
            im[off:off+n] = data
        elif typ == 1:
            break
    return im

def encode(im):
    lines = [":020000040800F2"]
    for off in range(0, len(im), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + im[off:off+16]
        lines.append(":" + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return "\n".join(lines + [":00000001FF", ""])

def thumb_bl(at, target):
    delta = target - (at + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError("BL target out of range")
    imm = delta & 0x1FFFFFF
    s = (imm >> 24) & 1
    i1, i2 = (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = 1 ^ (i1 ^ s), 1 ^ (i2 ^ s)
    h1 = 0xF000 | (s << 10) | ((imm >> 12) & 0x3FF)
    h2 = 0xD000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7FF)
    return h1.to_bytes(2, "little") + h2.to_bytes(2, "little")

def thumb_b_w(at, target):
    delta = target - (at + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError("B.W target out of range")
    imm = delta & 0x1FFFFFF
    s = (imm >> 24) & 1
    i1, i2 = (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = 1 ^ (i1 ^ s), 1 ^ (i2 ^ s)
    h1 = 0xF000 | (s << 10) | ((imm >> 12) & 0x3FF)
    h2 = 0x9000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7FF)
    return h1.to_bytes(2, "little") + h2.to_bytes(2, "little")

def bl_target(im, addr):
    off = addr - FLASH
    h1 = int.from_bytes(im[off:off+2], "little")
    h2 = int.from_bytes(im[off+2:off+4], "little")
    if h1 & 0xF800 != 0xF000 or h2 & 0xD000 != 0xD000:
        raise ValueError(f"not BL at {addr:#x}")
    s, j1, j2 = (h1 >> 10) & 1, (h2 >> 13) & 1, (h2 >> 11) & 1
    i1, i2 = 1 ^ (j1 ^ s), 1 ^ (j2 ^ s)
    imm = (s << 24) | (i1 << 23) | (i2 << 22) | ((h1 & 0x3FF) << 12) | ((h2 & 0x7FF) << 1)
    if s:
        imm -= 1 << 25
    return (addr + 4 + imm) & 0xFFFFFFFF

def b_w_target(im, addr):
    off = addr - FLASH
    h1 = int.from_bytes(im[off:off+2], "little")
    h2 = int.from_bytes(im[off+2:off+4], "little")
    if h1 & 0xF800 != 0xF000 or h2 & 0xD000 != 0x9000:
        raise ValueError(f"not B.W at {addr:#x}")
    s, j1, j2 = (h1 >> 10) & 1, (h2 >> 13) & 1, (h2 >> 11) & 1
    i1, i2 = 1 ^ (j1 ^ s), 1 ^ (j2 ^ s)
    imm = (s << 24) | (i1 << 23) | (i2 << 22) | ((h1 & 0x3FF) << 12) | ((h2 & 0x7FF) << 1)
    if s:
        imm -= 1 << 25
    return (addr + 4 + imm) & 0xFFFFFFFF

def short_b(at, target):
    delta = target - (at + 4)
    if delta & 1 or not -2048 <= delta <= 2046:
        raise ValueError("short branch out of range")
    return (0xE000 | ((delta >> 1) & 0x7FF)).to_bytes(2, "little")

if hashlib.sha256(BASE.read_bytes()).hexdigest() != BASE_SHA:
    raise ValueError("base SHA mismatch")
im = decode(BASE)
original = bytes(im)

# These are v11's original one-shot screen-transition flag operations.
assert im[STATE-FLASH:STATE-FLASH+16] == bytes.fromhex(
    "03 4B 1B 78 00 2B 02 D1 01 4B 01 22 1A 70 70 47")
# The former SETTINGS-title draw slot is eight bytes of NOPs.
assert im[NORMAL_SKIP-FLASH:NORMAL_SKIP-FLASH+8] == bytes.fromhex(
    "00 BF 00 BF 00 BF 00 BF")
# Reuse the nearby stock gray literal already used for normal page clears.
assert im[COLOR_LITERAL-FLASH:COLOR_LITERAL-FLASH+4] == bytes.fromhex("25 19 00 00")

# On first SETTINGS render after transition, set the existing state byte and branch
# to a compact clear stub. Subsequent redraws return without clearing.
state = bytes.fromhex("03 4B 1A 78 00 2A 02 D1 01 22 1A 70")
state += short_b(STATE + 12, FILL_STUB)
state += bytes.fromhex("70 47")
assert len(state) == 16
im[STATE-FLASH:STATE-FLASH+16] = state

# Regular renderer flow skips the stub. The one-shot path enters at FILL_STUB,
# loads the exact stock dark-gray color, then tail-branches to the screen-fill wrapper.
# The tail branch preserves the SETTINGS renderer's LR so the wrapper returns
# to the instruction after the one-shot guard.
im[NORMAL_SKIP-FLASH:NORMAL_SKIP-FLASH+2] = short_b(NORMAL_SKIP, 0x0800B31E)
pc = (FILL_STUB + 4) & ~3
ldr_delta = COLOR_LITERAL - pc
if ldr_delta < 0 or ldr_delta > 1020 or ldr_delta & 3:
    raise ValueError("gray literal is not reachable with Thumb LDR literal")
im[FILL_STUB-FLASH:FILL_STUB-FLASH+2] = (0x4800 | (ldr_delta // 4)).to_bytes(2, "little")
im[FILL_CALL-FLASH:FILL_CALL-FLASH+4] = thumb_b_w(FILL_CALL, FILL_SCREEN)

# Keep the seven additional small fills suppressed, and leave every icon and label call intact.
for addr in FILL_CALLS:
    if im[addr-FLASH:addr-FLASH+4] != bytes.fromhex("00 BF 00 BF"):
        raise ValueError(f"repeat-fill call was re-enabled at {addr:#x}")
for addr in ASSET_CALLS:
    if bl_target(im, addr) != 0x0800AFE4:
        raise ValueError(f"icon call changed at {addr:#x}")
for addr in LABEL_CALLS:
    if bl_target(im, addr) != 0x0800F970:
        raise ValueError(f"label call changed at {addr:#x}")
if b_w_target(im, FILL_CALL) != FILL_SCREEN:
    raise AssertionError("full-screen fill branch target mismatch")

OUT.write_text(encode(im))
check = decode(OUT)
if check != im:
    raise AssertionError("HEX round-trip mismatch")
for line in OUT.read_text().splitlines():
    if sum(bytes.fromhex(line[1:])) & 0xFF:
        raise AssertionError("Intel HEX checksum failure")
allowed = set(range(STATE-FLASH, STATE-FLASH+16))
allowed |= set(range(NORMAL_SKIP-FLASH, NORMAL_SKIP-FLASH+2))
allowed |= set(range(FILL_STUB-FLASH, FILL_STUB-FLASH+2))
allowed |= set(range(FILL_CALL-FLASH, FILL_CALL-FLASH+4))
changed = {i for i, (a, b) in enumerate(zip(original, check)) if a != b}
if changed - allowed:
    raise AssertionError(f"unexpected modified bytes: {sorted(changed-allowed)}")
print("Output:", OUT)
print("SHA-256:", hashlib.sha256(OUT.read_bytes()).hexdigest())
print("SETTINGS clears once per screen transition with the stock 0x1925 gray.")
print("Seven repeated rectangle fills stay disabled; icons and values stay intact.")
print("HEX checksums, round-trip, call targets, state guard and patch bounds: OK")
