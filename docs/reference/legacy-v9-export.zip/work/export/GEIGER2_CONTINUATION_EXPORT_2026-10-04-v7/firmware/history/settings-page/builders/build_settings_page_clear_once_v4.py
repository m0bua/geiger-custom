#!/usr/bin/env python3
"""Clear SETTINGS once per entry with the stock gray, using its existing entry guard."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
BASE = Path(__file__).resolve().parent / 'port-20261004-2043-settings-fill-probe-v1.hex'
OUT = Path(__file__).resolve().parent / 'port-20261004-2219-settings-page-clear-v4.hex'
BASE_SHA = 'fdf2055c37649edaa725c8df30127ca284688183c45a77fd354d404facb09205'
GUARD = 0x0800B2D8
SLOT = 0x0800B316
LDR = 0x0800B318
CALL = 0x0800B31A
RESUME = 0x0800B31E
GRAY_LITERAL = 0x0800B5A4
FILL_SCREEN = 0x08008F70


def decode(path):
    im = bytearray([255]) * 0x10000
    upper = 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:]); n, hi, lo, typ = rec[:4]; data = rec[4:-1]
        if len(data) != n or sum(rec) & 255:
            raise ValueError('bad Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(im):
                raise ValueError('record outside flash')
            im[off:off+n] = data
        elif typ == 1:
            break
    return im


def encode(im):
    lines = [':020000040800F2']
    for off in range(0, len(im), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + im[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])


def thumb_bl(at, target):
    delta = target - (at + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError('BL target out of range')
    imm = delta & 0x1ffffff
    s = (imm >> 24) & 1; i1 = (imm >> 23) & 1; i2 = (imm >> 22) & 1
    j1 = 1 ^ (i1 ^ s); j2 = 1 ^ (i2 ^ s)
    h1 = 0xf000 | (s << 10) | ((imm >> 12) & 0x3ff)
    h2 = 0xd000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7ff)
    return h1.to_bytes(2, 'little') + h2.to_bytes(2, 'little')


def bl_target(im, addr):
    off = addr - FLASH
    h1 = int.from_bytes(im[off:off+2], 'little'); h2 = int.from_bytes(im[off+2:off+4], 'little')
    if h1 & 0xf800 != 0xf000 or h2 & 0xd000 != 0xd000:
        raise ValueError('not a Thumb BL')
    s = (h1 >> 10) & 1; j1 = (h2 >> 13) & 1; j2 = (h2 >> 11) & 1
    i1 = 1 ^ (j1 ^ s); i2 = 1 ^ (j2 ^ s)
    imm = (s << 24) | (i1 << 23) | (i2 << 22) | ((h1 & 0x3ff) << 12) | ((h2 & 0x7ff) << 1)
    if s: imm -= 1 << 25
    return (addr + 4 + imm) & 0xffffffff

if hashlib.sha256(BASE.read_bytes()).hexdigest() != BASE_SHA:
    raise ValueError('base SHA mismatch')
im = decode(BASE); original = bytes(im)
# Original guard returns with Z=1 on the first entry and Z=0 on redraws.
assert im[GUARD-FLASH:GUARD-FLASH+16] == bytes.fromhex('03 4B 1B 78 00 2B 02 D1 01 4B 01 22 1A 70 70 47')
assert im[SLOT-FLASH:SLOT-FLASH+8] == bytes.fromhex('00 BF 00 BF 00 BF 00 BF')
assert im[GRAY_LITERAL-FLASH:GRAY_LITERAL-FLASH+4] == bytes.fromhex('25 19 00 00')
# BNE skips the clear after the entry guard has reported an already-rendered page.
delta = RESUME - (SLOT + 4)
assert delta == 4
im[SLOT-FLASH:SLOT-FLASH+2] = (0xd100 | ((delta >> 1) & 0xff)).to_bytes(2, 'little')
# First entry loads the same gray used by the firmware's ordinary page clearing,
# then calls (not branches to) the wrapper, returning to B31E and normal drawing.
pc = (LDR + 4) & ~3
literal_delta = GRAY_LITERAL - pc
assert literal_delta >= 0 and literal_delta <= 1020 and literal_delta % 4 == 0
im[LDR-FLASH:LDR-FLASH+2] = (0x4800 | (literal_delta // 4)).to_bytes(2, 'little')
im[CALL-FLASH:CALL-FLASH+4] = thumb_bl(CALL, FILL_SCREEN)
assert bl_target(im, CALL) == FILL_SCREEN
OUT.write_text(encode(im))
check = decode(OUT)
assert check == im
for line in OUT.read_text().splitlines():
    assert not (sum(bytes.fromhex(line[1:])) & 255)
changed = {i for i, (a,b) in enumerate(zip(original, check)) if a != b}
allowed = set(range(SLOT-FLASH, SLOT-FLASH+2)) | set(range(LDR-FLASH, LDR-FLASH+2)) | set(range(CALL-FLASH, CALL-FLASH+4))
assert changed <= allowed, sorted(changed-allowed)
print('Output:', OUT)
print('SHA-256:', hashlib.sha256(OUT.read_bytes()).hexdigest())
print('First SETTINGS entry: Z=1 -> load 0x1925 -> BL full clear -> resume render.')
print('Later redraws: Z=0 -> BNE skips clear. Guard and all seven disabled repeat fills remain unchanged.')
