#!/usr/bin/env python3
"""Use the stock screen-clear call at the SETTINGS renderer slot."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
BASE = Path(__file__).resolve().parent / "port-20261004-2043-settings-fill-probe-v1.hex"
OUT = Path(__file__).resolve().parent / "port-20261004-2210-settings-page-clear-v3.hex"
BASE_SHA = "fdf2055c37649edaa725c8df30127ca284688183c45a77fd354d404facb09205"
CALL = 0x0800B31A
FILL_SCREEN = 0x08008F70


def decode(path):
    im = bytearray([255]) * 0x10000
    upper = 0
    for line in path.read_text().splitlines():
        if not line.startswith(":"):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if len(data) != n or sum(rec) & 0xFF:
            raise ValueError("bad Intel HEX record")
        if typ == 4:
            upper = int.from_bytes(data, "big") << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(im):
                raise ValueError("record outside flash")
            im[off:off+n] = data
        elif typ == 1:
            break
    return im


def encode(im):
    lines = [":020000040800F2"]
    for off in range(0, len(im), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + im[off:off+16]
        lines.append(":" + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return "\n".join(lines + [":00000001FF", ""])


def thumb_bl(at, target):
    delta = target - (at + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError("BL target out of range")
    imm = delta & 0x1FFFFFF
    s = (imm >> 24) & 1
    i1, i2 = (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = 1 ^ (i1 ^ s), 1 ^ (i2 ^ s)
    h1 = 0xF000 | (s << 10) | ((imm >> 12) & 0x3FF)
    h2 = 0xD000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7FF)
    return h1.to_bytes(2, "little") + h2.to_bytes(2, "little")


def bl_target(im, addr):
    off = addr - FLASH
    h1 = int.from_bytes(im[off:off+2], "little")
    h2 = int.from_bytes(im[off+2:off+4], "little")
    if h1 & 0xF800 != 0xF000 or h2 & 0xD000 != 0xD000:
        raise ValueError("not Thumb BL")
    s, j1, j2 = (h1 >> 10) & 1, (h2 >> 13) & 1, (h2 >> 11) & 1
    i1, i2 = 1 ^ (j1 ^ s), 1 ^ (j2 ^ s)
    imm = (s << 24) | (i1 << 23) | (i2 << 22) | ((h1 & 0x3FF) << 12) | ((h2 & 0x7FF) << 1)
    if s:
        imm -= 1 << 25
    return (addr + 4 + imm) & 0xFFFFFFFF


if hashlib.sha256(BASE.read_bytes()).hexdigest() != BASE_SHA:
    raise ValueError("base SHA mismatch")
im = decode(BASE)
original = bytes(im)
off = CALL - FLASH
if im[off:off+4] != bytes.fromhex("00 BF 00 BF"):
    raise ValueError("expected unused 4-byte SETTINGS call slot")
im[off:off+4] = thumb_bl(CALL, FILL_SCREEN)
if bl_target(im, CALL) != FILL_SCREEN:
    raise AssertionError("wrong screen-clear target")
OUT.write_text(encode(im))
check = decode(OUT)
if check != im:
    raise AssertionError("HEX round-trip mismatch")
for line in OUT.read_text().splitlines():
    if sum(bytes.fromhex(line[1:])) & 255:
        raise AssertionError("Intel HEX checksum failure")
changed = {i for i, (a, b) in enumerate(zip(original, check)) if a != b}
if changed != set(range(off, off+4)):
    raise AssertionError("unexpected byte changes")
print("Output:", OUT)
print("SHA-256:", hashlib.sha256(OUT.read_bytes()).hexdigest())
print("Only SETTINGS renderer's 4-byte clear-call slot changed.")
print("The seven repeated rectangle fills remain disabled; HEX and target checks pass.")
