#!/usr/bin/env python3
"""Temporarily suppress SETTINGS-page rectangle fills while retaining options and icons."""
from pathlib import Path
import hashlib
FLASH=0x08000000
BASE=Path(__file__).resolve().parent/'port-20261004-2008-settings-page-labels-7x10-v11.hex'
OUT=Path(__file__).resolve().parent/'port-20261004-2043-settings-fill-probe-v1.hex'
BASE_SHA='5111dc7f978102ee1cea313a1318a1a765152db54f3b2a97951dfcba598f62fc'
FILL_CALLS=(0x0800B454,0x0800B462,0x0800B470,0x0800B47E,0x0800B48C,0x0800B49A,0x0800B4A8)
KEEP_ASSET_CALLS=(0x0800B334,0x0800B34C,0x0800B36E,0x0800B38A,0x0800B3B0,0x0800B3DC)
LABEL_CALLS=(0x0800B406,0x0800B430,0x0800B4D2,0x0800B4F6,0x0800B51C,0x0800B542,0x0800B566)
def decode(path):
 im=bytearray([255])*0x10000; upper=0
 for line in path.read_text().splitlines():
  if not line.startswith(':'): continue
  rec=bytes.fromhex(line[1:]); n,hi,lo,typ=rec[:4]; data=rec[4:-1]
  if len(data)!=n or sum(rec)&255: raise ValueError('bad Intel HEX record')
  if typ==4: upper=int.from_bytes(data,'big')<<16
  elif typ==0:
   off=upper+(hi<<8)+lo-FLASH
   if off<0 or off+n>len(im): raise ValueError('record outside flash')
   im[off:off+n]=data
  elif typ==1: break
 return im
def encode(im):
 lines=[':020000040800F2']
 for off in range(0,len(im),16):
  rec=bytes([16,off>>8,off&255,0])+im[off:off+16]
  lines.append(':'+ (rec+bytes([(-sum(rec))&255])).hex().upper())
 return '\n'.join(lines+[':00000001FF',''])
def bl_target(im,addr):
 off=addr-FLASH; h1=int.from_bytes(im[off:off+2],'little'); h2=int.from_bytes(im[off+2:off+4],'little')
 if h1&0xF800!=0xF000 or h2&0xD000!=0xD000: raise ValueError(f'not BL at {addr:#x}')
 s=(h1>>10)&1; j1=(h2>>13)&1; j2=(h2>>11)&1; i1=1^(j1^s); i2=1^(j2^s)
 imm=(s<<24)|(i1<<23)|(i2<<22)|((h1&0x3ff)<<12)|((h2&0x7ff)<<1)
 if s: imm-=1<<25
 return (addr+4+imm)&0xffffffff
if hashlib.sha256(BASE.read_bytes()).hexdigest()!=BASE_SHA: raise ValueError('base SHA mismatch')
im=decode(BASE); original=bytes(im)
for addr in FILL_CALLS:
 if bl_target(im,addr)!=0x08008ECC: raise ValueError(f'unexpected fill target at {addr:#x}')
 off=addr-FLASH; im[off:off+4]=bytes.fromhex('00 BF 00 BF')
# Keep gear artwork, small SETTINGS icons, and all seven text option renderers intact.
for addr in KEEP_ASSET_CALLS:
 if bl_target(im,addr)!=0x0800AFE4: raise ValueError(f'icon asset call changed at {addr:#x}')
for addr in LABEL_CALLS:
 if bl_target(im,addr)!=0x0800F970: raise ValueError(f'option text call changed at {addr:#x}')
OUT.write_text(encode(im)); check=decode(OUT)
if check!=im: raise AssertionError('HEX roundtrip mismatch')
for line in OUT.read_text().splitlines():
 if sum(bytes.fromhex(line[1:]))&255: raise AssertionError('checksum failure')
changed={i for i,(a,b) in enumerate(zip(original,check)) if a!=b}
allowed=set()
for addr in FILL_CALLS: allowed.update(range(addr-FLASH,addr-FLASH+4))
if changed!=allowed: raise AssertionError(f'unexpected changed-byte set: {sorted(changed^allowed)}')
print('Output:',OUT)
print('SHA-256:',hashlib.sha256(OUT.read_bytes()).hexdigest())
print('Disabled only the seven SETTINGS-page rectangle-fill calls to 0x08008ECC.')
print('Preserved the two gear artwork blocks, four small icon assets, and all seven option text calls.')
print('HEX checksums, round-trip, call targets and patch bounds: OK')
