#!/usr/bin/env python3
"""Spread unit labels over the left icon and retain state labels over center/right."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
BASE = Path(__file__).resolve().parent / "port-20261004-1925-settings-page-labels-7x10-v3.hex"
OUT = Path(__file__).resolve().parent / "port-20261004-1926-settings-page-labels-7x10-v4.hex"
BASE_SHA = "d53165008c2924fe112898c26b877562f6dc0bf65f4a450fa199c69fdaeca8d7"

HELPER = 0x0800F970
HELPER_END = 0x0800F9D4  # tiny-font table begins here
FONT = 0x0800F648
F_GLYPH = 0x0800F710    # replace unused 7x10 '#'
DRAW = 0x08008E48
TITLE_CALLS = [0x080093FE, 0x08009848, 0x0800B31A, 0x0800C614, 0x0800C706, 0x0800CD8A]
# selector, x, y-group, label. y-group 0=top unit row; 1=lower status row.
SETTINGS = [
    (0x0800B406, 3, 83, 0, "sound ON"),
    (0x0800B430, 4, 108, 0, "diode ON"),
    (0x0800B4D2, 5, 79, 0, "sound OFF"),
    (0x0800B4F6, 6, 104, 0, "diode OFF"),
    (0x0800B51C, 0, 12, 0, "Sv"),
    (0x0800B542, 1, 28, 0, "CPM"),
    (0x0800B566, 2, 51, 0, "R"),
]


def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        if not line.startswith(":"):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, kind = rec[:4]
        data = rec[4:-1]
        if len(data) != n or sum(rec) & 255:
            raise ValueError("invalid Intel HEX record")
        if kind == 4:
            upper = int.from_bytes(data, "big") << 16
        elif kind == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError("record outside flash image")
            image[off:off+n] = data
        elif kind == 1:
            break
    return image


def encode(image):
    lines = [":020000040800F2"]
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(":" + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return "\n".join(lines + [":00000001FF", ""])


def thumb_bl(at, target):
    delta = target - (at + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError("Thumb BL out of range")
    imm = delta & 0x1FFFFFF
    s, i1, i2 = (imm >> 24) & 1, (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = 1 ^ (i1 ^ s), 1 ^ (i2 ^ s)
    a = 0xF000 | (s << 10) | ((imm >> 12) & 0x3FF)
    b = 0xD000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7FF)
    return a.to_bytes(2, "little") + b.to_bytes(2, "little")


def bl_target(data, at):
    off = at - FLASH
    h1, h2 = int.from_bytes(data[off:off+2], "little"), int.from_bytes(data[off+2:off+4], "little")
    if h1 & 0xF800 != 0xF000 or h2 & 0xD000 != 0xD000:
        raise ValueError(f"not BL at {at:#x}")
    s, j1, j2 = (h1 >> 10) & 1, (h2 >> 13) & 1, (h2 >> 11) & 1
    i1, i2 = 1 ^ (j1 ^ s), 1 ^ (j2 ^ s)
    imm = (s << 24) | (i1 << 23) | (i2 << 22) | ((h1 & 0x3FF) << 12) | ((h2 & 0x7FF) << 1)
    if s:
        imm -= 1 << 25
    return (at + 4 + imm) & 0xFFFFFFFF


def make_glyph(rows):
    if len(rows) != 10 or any(len(r) != 7 for r in rows):
        raise ValueError("expected 7x10 glyph")
    out = bytearray()
    for row in rows:
        word = sum((c == "#") << (15-i) for i, c in enumerate(row))
        out.extend(word.to_bytes(2, "little"))
    return bytes(out)


if hashlib.sha256(BASE.read_bytes()).hexdigest() != BASE_SHA:
    raise ValueError("approved base SHA-256 mismatch")
image = decode(BASE)
original = bytes(image)

# Compact settings text renderer. Entry: r0=selector 0..6, r1=x.
# All labels share y=22; selectors route each string to a per-icon x coordinate.
code = bytearray()
labels, branches, literals = {}, [], []

def e16(v): code.extend(v.to_bytes(2, "little"))
def mark(n): labels[n] = len(code)
def branch(n, cond=None):
    at = len(code); e16(0); branches.append((at, n, cond))
def ldr(rd, value):
    at = len(code); e16(0x4800 | (rd << 8)); literals.append((at, value))

e16(0xB510)                 # push {r4,lr}
e16(0xB084)                 # sub sp,#16
e16(0x4604)                 # mov r4,r0 (selector)
e16(0x0080)                 # lsls r0,r0,#2
ldr(2, 0x0800F9B8)          # 4-byte string table
e16(0x1812)                 # adds r2,r2,r0
e16(0x4608)                 # mov r0,r1 (x)
e16(0x2C02)                 # cmp r4,#2
branch("lower", 8)         # bhi
e16(0x2116)                 # y=22
branch("coords")
mark("lower")
e16(0x211F)                 # y=31
mark("coords")
ldr(3, FONT)
e16(0x9300)                 # [sp]=7x10 glyph table
e16(0x2300)
e16(0x43DB)                 # mvns r3,r3 -> white foreground
e16(0x9301)                 # [sp+4]=foreground
ldr(3, 0x2945)              # tested dark-gray RGB565 background
e16(0x9302)                 # [sp+8]=background
e16(0x230A)
e16(0x021B)
e16(0x3307)                 # r3=(10<<8)|7
code.extend(thumb_bl(HELPER + len(code), DRAW))
e16(0xB004)                 # add sp,#16
e16(0xBD10)                 # pop {r4,pc}
while (HELPER + len(code)) & 3:
    code.append(0)
literal_start = len(code)
pool_positions = {}
for at, value in literals:
    pool_positions[at] = len(code)
    pos = len(code)
    code.extend(value.to_bytes(4, "little"))
for at, value in literals:
    pc = (HELPER + at + 4) & ~3
    delta = HELPER + pool_positions[at] - pc
    if delta < 0 or delta > 1020 or delta & 3:
        raise ValueError("literal pool out of LDR range")
    rd = (int.from_bytes(code[at:at+2], "little") >> 8) & 7
    code[at:at+2] = (0x4800 | (rd << 8) | (delta // 4)).to_bytes(2, "little")
for at, name, cond in branches:
    delta = labels[name] - (at + 4)
    if delta & 1: raise ValueError("unaligned branch")
    imm = delta // 2
    opcode = (0xD000 | (cond << 8) | (imm & 255)) if cond is not None else (0xE000 | (imm & 0x7FF))
    if cond is not None and not -128 <= imm <= 127: raise ValueError("conditional branch out of range")
    code[at:at+2] = opcode.to_bytes(2, "little")

# Let all seven selectors use the upper label row (cmp selector,#6).
code[14:16] = bytes.fromhex("06 2C")

strings = [
    bytes([0x3D,0x41,0,0]),       # Sv
    bytes([0x29,0x42,0x27,0]),    # CPM
    bytes([0x22,0,0,0]),          # R
    bytes([0x3C,0x21,0,0]),       # ON
    bytes([0x3C,0x21,0,0]),       # ON
    bytes([0x3C,0x2A,0x2A,0]),    # OFF (new F glyph)
    bytes([0x3C,0x2A,0x2A,0]),    # OFF
]
table = b"".join(strings)
if len(code) + len(table) > HELPER_END - HELPER:
    raise ValueError(f"helper+strings exceed title region: {len(code)+len(table)}")
region = bytearray([0xFF]) * (HELPER_END - HELPER)
region[:len(code)] = code
table_off = 0x0800F9B8 - HELPER
region[table_off:table_off+len(table)] = table
# Point helper's selector table at the strings.
for at, _ in literals:
    pc = (HELPER + at + 4) & ~3
    delta = HELPER + literal_start - pc
    poolpos = literal_start
    region[poolpos:poolpos+4] = (0x0800F9B8).to_bytes(4, "little")
image[HELPER-FLASH:HELPER_END-FLASH] = region

# Keep the v1 substitutions and tune only the four ON/OFF x positions.
for call, selector, x, _yg, _label in SETTINGS:
    if bl_target(original, call) != HELPER:
        raise ValueError(f"v1 settings text helper target changed at {call:#x}")
    off = call - FLASH
    expected_selector = (0x2000 | selector).to_bytes(2, "little")
    if image[off-6:off-4] != expected_selector or image[off-2:off] != bytes.fromhex("00 BF"):
        raise ValueError(f"unexpected v1 call setup at {call:#x}")
    image[off-4:off-2] = (0x2100 | x).to_bytes(2, "little")

# The six title calls were already removed in v1 and must stay disabled.
for call in TITLE_CALLS:
    off = call - FLASH
    if original[off:off+4] != bytes.fromhex("00 BF 00 BF"):
        raise ValueError(f"page-title call was not already disabled at {call:#x}")

frows = ["#######", "#......", "#......", "#####..", "#......", "#......", "#......", ".......", ".......", "......."]
if image[F_GLYPH-FLASH:F_GLYPH-FLASH+20] != make_glyph(frows):
    raise ValueError("the v1 F glyph changed unexpectedly")

OUT.write_text(encode(image))
check = decode(OUT)
if check != image: raise AssertionError("HEX round-trip mismatch")
for line in OUT.read_text().splitlines():
    if sum(bytes.fromhex(line[1:])) & 255: raise AssertionError("HEX checksum failure")
changed = {i for i,(a,b) in enumerate(zip(original,check)) if a != b}
allowed = set(range(HELPER-FLASH,HELPER_END-FLASH))
for call,*_ in SETTINGS: allowed.update(range(call-FLASH-4,call-FLASH-2))
for call in TITLE_CALLS:
    if check[call-FLASH:call-FLASH+4] != bytes.fromhex("00 BF 00 BF"): raise AssertionError("title call unexpectedly restored")
if changed - allowed: raise AssertionError(f"unexpected patch bytes: {sorted(changed-allowed)}")
for call,*_ in SETTINGS:
    if bl_target(check,call) != HELPER: raise AssertionError(f"missing text helper at {call:#x}")
for call in TITLE_CALLS:
    if check[call-FLASH:call-FLASH+4] != bytes.fromhex("00 BF 00 BF"): raise AssertionError("title call not disabled")
if check[0xF938:0xF944] != original[0xF938:0xF944]: raise AssertionError("dose strings changed")
for lo,hi,name in [(0x0800F4BC,0x0800F504,"battery helper"),(0x0800F91E,0x0800F944,"dose helper/strings")]:
    if check[lo-FLASH:hi-FLASH] != original[lo-FLASH:hi-FLASH]: raise AssertionError(f"{name} changed")
for call in (0x0800373C,0x0800A592):
    if bl_target(check,call) != 0x0800AFE4: raise AssertionError(f"logo path changed at {call:#x}")
for call in (0x0800A250,0x0800A278,0x0800A2A2):
    if check[call-FLASH:call-FLASH+4] != original[call-FLASH:call-FLASH+4]: raise AssertionError("dose-label call changed")
print("Output:", OUT)
print("Base SHA-256:", BASE_SHA)
print("Spread Sv/CPM/R left-to-right over the left icon; sound states above center; diode states above right.")
print("All labels use the same y row, white foreground and tested 0x2945 dark-gray background.")
print("Page titles remain removed; 7x10 F, dose labels, battery helper, logo and first-screen units are preserved.")
print("Changed bytes:",len(changed))
print("SHA-256:",hashlib.sha256(OUT.read_bytes()).hexdigest())
