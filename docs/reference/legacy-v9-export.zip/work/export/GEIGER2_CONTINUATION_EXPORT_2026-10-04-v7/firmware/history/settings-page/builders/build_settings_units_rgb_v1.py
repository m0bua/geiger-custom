#!/usr/bin/env python3
"""Probe the three SETTINGS unit-label callsites with red/green/blue fills."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
BASE = Path(__file__).resolve().parent / "GEIGER2_CONTINUATION_EXPORT_2026-10-04-v6/firmware/approved/port-20261004-1639-dose-labels-7x10-v2.hex"
OUT = Path(__file__).resolve().parent / "port-20261004-1735-settings-unit-rgb-v1.hex"
BASE_SHA256 = "4b77d5d1c9544e8af0d6396945fdf978afd907fcae09b68fb76fd681580608cc"
FILL_HELPER = 0x0800F91E
FILL = 0x08008ECC
SETTINGS_RENDERER = 0x0800FD90
DOSE_HELPER = 0x0800F4BC
NOP_PAIR = bytes.fromhex("00 BF 00 BF")
# callsite, original index setup, diagnostic x, color index, label
UNITS = [
    (0x0800BABE, bytes.fromhex("00 91 DB 00 04 20"), 0, 0, "Sv"),
    (0x0800BAE6, bytes.fromhex("00 91 DB 00 05 20"), 44, 1, "CPM"),
    (0x0800BB0E, bytes.fromhex("00 91 DB 00 06 20"), 88, 2, "R"),
]
# The current dose-label helper branches through F91E for these three selectors.
# In the diagnostic only, suppress those dose labels while F91E holds the fill helper.
DOSE_LABEL_CALLS = (0x0800A250, 0x0800A278, 0x0800A2A2)


def decode(path):
    image = bytearray([0xFF]) * 0x10000
    upper = 0
    for line in path.read_text().splitlines():
        if not line.startswith(":"):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, kind = rec[:4]
        data = rec[4:-1]
        if len(data) != n or sum(rec) & 0xFF:
            raise ValueError(f"invalid Intel HEX record: {line}")
        if kind == 4:
            upper = int.from_bytes(data, "big") << 16
        elif kind == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError("record outside MCU 64 KiB flash")
            image[off:off+n] = data
        elif kind == 1:
            break
    return image


def encode(image):
    lines = [":020000040800F2"]
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(":" + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return "\n".join(lines + [":00000001FF", ""])


def thumb_bl(at, target):
    delta = target - (at + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError("Thumb BL out of range")
    imm = delta & 0x1FFFFFF
    s, i1, i2 = (imm >> 24) & 1, (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = 1 ^ (i1 ^ s), 1 ^ (i2 ^ s)
    h1 = 0xF000 | (s << 10) | ((imm >> 12) & 0x3FF)
    h2 = 0xD000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7FF)
    return h1.to_bytes(2, "little") + h2.to_bytes(2, "little")


def bl_target(data, at):
    off = at - FLASH
    h1 = int.from_bytes(data[off:off+2], "little")
    h2 = int.from_bytes(data[off+2:off+4], "little")
    if h1 & 0xF800 != 0xF000 or h2 & 0xD000 != 0xD000:
        raise ValueError(f"not Thumb BL at {at:#010x}")
    s, j1, j2 = (h1 >> 10) & 1, (h2 >> 13) & 1, (h2 >> 11) & 1
    i1, i2 = 1 ^ (j1 ^ s), 1 ^ (j2 ^ s)
    imm = (s << 24) | (i1 << 23) | (i2 << 22) | ((h1 & 0x3FF) << 12) | ((h2 & 0x7FF) << 1)
    if s:
        imm -= 1 << 25
    return (at + 4 + imm) & 0xFFFFFFFF


if hashlib.sha256(BASE.read_bytes()).hexdigest() != BASE_SHA256:
    raise ValueError("approved v2 base SHA-256 mismatch")
image = decode(BASE)
original = bytes(image)

# This 36-byte code/data window currently contains the DOSE external-label helper.
# Reuse it only for this test; the three DOSE text callsites below are NOPed.
helper = bytearray.fromhex(
    "00 B5 81 B0 05 4B 52 00 9A 5A 00 92 28 22 17 23 "
    "00 F0 00 00 01 B0 00 BD"
)
helper[16:20] = thumb_bl(FILL_HELPER + 16, FILL)
payload = bytearray(helper)
while (FILL_HELPER + len(payload)) & 3:
    payload.append(0)
literal = FILL_HELPER + len(payload)
table = literal + 4
payload += table.to_bytes(4, "little")
payload += bytes.fromhex("00 F8 E0 07 1F 00")
if len(payload) != 36:
    raise AssertionError(f"unexpected helper size {len(payload)}")
image[FILL_HELPER-FLASH:FILL_HELPER-FLASH+36] = payload

for call, expected, x, color, label in UNITS:
    off = call - FLASH
    if bl_target(original, call) != SETTINGS_RENDERER:
        raise ValueError(f"{call:#010x} no longer routes through SETTINGS text helper")
    if image[off-6:off] != expected:
        raise ValueError(f"unexpected unit-label index setup at {call:#010x}")
    image[off-6:off] = b"".join(v.to_bytes(2, "little") for v in (0x2000 | x, 0x211D, 0x2200 | color))
    image[off:off+4] = thumb_bl(call, FILL_HELPER)

for call in DOSE_LABEL_CALLS:
    if bl_target(original, call) != DOSE_HELPER:
        raise ValueError(f"unexpected DOSE helper at {call:#010x}")
    off = call - FLASH
    image[off:off+4] = NOP_PAIR

# The logo remains enabled in this probe.
for call in (0x0800373C, 0x0800A592):
    if bl_target(image, call) != 0x0800AFE4:
        raise AssertionError(f"Mira logo call changed at {call:#010x}")

OUT.write_text(encode(image))
check = decode(OUT)
if check != image:
    raise AssertionError("Intel HEX round-trip mismatch")
for line in OUT.read_text().splitlines():
    if sum(bytes.fromhex(line[1:])) & 0xFF:
        raise AssertionError("Intel HEX checksum failure")
changed = {i for i, (a, b) in enumerate(zip(original, check)) if a != b}
allowed = set(range(FILL_HELPER-FLASH, FILL_HELPER-FLASH+36))
for call, *_ in UNITS:
    allowed.update(range(call-FLASH-6, call-FLASH+4))
for call in DOSE_LABEL_CALLS:
    allowed.update(range(call-FLASH, call-FLASH+4))
if not changed <= allowed:
    raise AssertionError(f"unexpected changed offsets: {sorted(changed - allowed)}")
for call, *_ in UNITS:
    if bl_target(check, call) != FILL_HELPER:
        raise AssertionError(f"unit overlay call target missing at {call:#010x}")
print("Output:", OUT)
print("Base SHA-256:", BASE_SHA256)
print("SETTINGS IDs 4/5/6 (Sv/CPM/R): red/green/blue diagnostic fills at x=0/44/88, y=29")
print("Dose labels are suppressed only in this temporary test (F91E reused as fill helper).")
print("Mira logo calls remain intact.")
print("Intel HEX round-trip, record checksums, targets and patch bounds: OK")
print("Changed bytes:", len(changed))
print("SHA-256:", hashlib.sha256(OUT.read_bytes()).hexdigest())
