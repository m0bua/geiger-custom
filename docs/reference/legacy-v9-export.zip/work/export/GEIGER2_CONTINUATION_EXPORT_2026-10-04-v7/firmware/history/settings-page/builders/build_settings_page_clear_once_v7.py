#!/usr/bin/env python3
"""Clear SETTINGS once on entry with gray 0x1925 and caller-saved state."""
from pathlib import Path
import hashlib
FLASH=0x08000000
BASE=Path(__file__).resolve().parent/'port-20261004-2043-settings-fill-probe-v1.hex'
OUT=Path(__file__).resolve().parent/'port-20261004-2227-settings-page-clear-v7.hex'
BASE_SHA='fdf2055c37649edaa725c8df30127ca284688183c45a77fd354d404facb09205'
GUARD=0x0800B2D8; ENTRY=0x0800B30E; LDR=0x0800B314; CALL=0x0800B316; RESUME=0x0800B31E
GRAY=0x0800B5A4; FILL=0x08008F70

def decode(p):
 im=bytearray([255])*0x10000; upper=0
 for line in p.read_text().splitlines():
  if not line.startswith(':'):continue
  rec=bytes.fromhex(line[1:]);n,hi,lo,typ=rec[:4];data=rec[4:-1]
  if len(data)!=n or sum(rec)&255:raise ValueError('bad Intel HEX record')
  if typ==4:upper=int.from_bytes(data,'big')<<16
  elif typ==0:
   off=upper+(hi<<8)+lo-FLASH
   if off<0 or off+n>len(im):raise ValueError('record outside flash')
   im[off:off+n]=data
  elif typ==1:break
 return im

def encode(im):
 lines=[':020000040800F2']
 for off in range(0,len(im),16):
  rec=bytes([16,off>>8,off&255,0])+im[off:off+16]
  lines.append(':'+ (rec+bytes([(-sum(rec))&255])).hex().upper())
 return '\n'.join(lines+[':00000001FF',''])

def thumb_bl(at,target):
 delta=target-(at+4)
 if delta&1 or not -(1<<24)<=delta<(1<<24):raise ValueError('BL range')
 imm=delta&0x1ffffff;s=imm>>24&1;i1=imm>>23&1;i2=imm>>22&1;j1=1^(i1^s);j2=1^(i2^s)
 h1=0xf000|(s<<10)|((imm>>12)&0x3ff);h2=0xd000|(j1<<13)|(j2<<11)|((imm>>1)&0x7ff)
 return h1.to_bytes(2,'little')+h2.to_bytes(2,'little')

def decode_bl_target(im,at):
 off=at-FLASH;h1=int.from_bytes(im[off:off+2],'little');h2=int.from_bytes(im[off+2:off+4],'little')
 if h1&0xf800!=0xf000 or h2&0xd000!=0xd000:raise ValueError('not BL')
 s=h1>>10&1;j1=h2>>13&1;j2=h2>>11&1;i1=1^(j1^s);i2=1^(j2^s)
 imm=(s<<24)|(i1<<23)|(i2<<22)|((h1&0x3ff)<<12)|((h2&0x7ff)<<1)
 if s:imm-=1<<25
 return (at+4+imm)&0xffffffff

if hashlib.sha256(BASE.read_bytes()).hexdigest()!=BASE_SHA:raise ValueError('base SHA mismatch')
im=decode(BASE); original=bytes(im)
assert im[GUARD-FLASH:GUARD-FLASH+16]==bytes.fromhex('03 4B 1B 78 00 2B 02 D1 01 4B 01 22 1A 70 70 47')
# B30E..B31D are the retired title call's argument setup and NOP slot.
assert im[ENTRY-FLASH:RESUME-FLASH]==bytes.fromhex('42 20 04 21 5E 22 0F 23 00 BF 00 BF 00 BF 00 BF')
assert im[GRAY-FLASH:GRAY-FLASH+4]==bytes.fromhex('25 19 00 00')
# Helper returns the prior state in caller-saved r12, sets transition byte to 1
# on first entry, and keeps the original return path and all callee-saved regs.
im[GUARD-FLASH:GUARD-FLASH+16]=bytes.fromhex('03 4B 1A 78 94 46 00 2A 02 D1 01 22 1A 70 70 47')
# MOV r3,r12; CMP r3,#0; BNE to normal continuation; first entry loads gray and BLs.
im[ENTRY-FLASH:ENTRY-FLASH+6]=bytes.fromhex('9C 46 00 2B 04 D1')
pc=(LDR+4)&~3;delta=GRAY-pc
assert 0<=delta<=1020 and delta%4==0
im[LDR-FLASH:LDR-FLASH+2]=(0x4800|delta//4).to_bytes(2,'little')
im[CALL-FLASH:CALL-FLASH+4]=thumb_bl(CALL,FILL)
assert decode_bl_target(im,CALL)==FILL
OUT.write_text(encode(im));check=decode(OUT);assert check==im
for line in OUT.read_text().splitlines():assert not(sum(bytes.fromhex(line[1:]))&255)
changed={i for i,(a,b) in enumerate(zip(original,check)) if a!=b}
allowed=set(range(GUARD-FLASH,GUARD-FLASH+16))|set(range(ENTRY-FLASH,ENTRY-FLASH+6))|set(range(LDR-FLASH,LDR-FLASH+2))|set(range(CALL-FLASH,CALL-FLASH+4))
assert changed<=allowed,sorted(changed-allowed)
print('Output:',OUT);print('SHA-256:',hashlib.sha256(OUT.read_bytes()).hexdigest())
print('State byte remains guarded/reset by firmware; first entry returns r12=0, redraw returns r12=1.')
print('Only first entry loads literal 0x1925 and calls the stock full-screen fill; no callee-saved regs changed.')
