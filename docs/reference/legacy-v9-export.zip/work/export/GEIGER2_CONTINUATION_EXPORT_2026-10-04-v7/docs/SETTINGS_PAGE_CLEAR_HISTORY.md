# SETTINGS page clear build history

| Build | Status | Observed / decision |
|---|---|---|
| `port-20261004-2008-settings-page-labels-7x10-v11.hex` | Confirmed layout base | User accepted the labels/layout; contained the seven repeated fills under investigation. |
| `port-20261004-2043-settings-fill-probe-v1.hex` | Diagnostic base for clear work | Seven repeated fills disabled; labels/icons retained. |
| `port-20261004-2210-settings-page-clear-v3.hex` | Rejected | Direct call caused green repeated/flickering fill. |
| `port-20261004-2219-settings-page-clear-v4.hex` | Rejected | Clear on entry did not work. |
| `port-20261004-2227-settings-page-clear-v5.hex` | Rejected | User reported reboot. |
| `port-20261004-2235-settings-page-clear-v6.hex` | **Approved and frozen** | User explicitly selected v6 as the basis. Preserve its exact bytes and name. |
| `port-20261004-2227-settings-page-clear-v7.hex` | Unapproved experiment | Generated after the user froze v6. Do not flash or use as a base. |

Other RGB identification builds, label builds, fill probes, and their builders
are retained in `firmware/history/settings-page/`. They are development history,
not approved firmware. Use v6 from `firmware/approved/` for continuation.
