# Geiger-2 continuation handoff — 2026-10-04 v6

## Current approved base

`firmware/approved/port-20261004-1639-dose-labels-7x10-v2.hex` is the latest user-confirmed working firmware. SHA-256: `4b77d5d1c9544e8af0d6396945fdf978afd907fcae09b68fb76fd681580608cc`. Use this as the starting point for follow-up work.

- Dose labels use the 7×10 font: red `µSv`, green `µR`, blue `CNT`. The user confirmed this mapping and approved v2. `µ` means micro (10⁻⁶); `CNT` labels event/click count, not counts per minute.
- v2 positions: red `µSv` `(118,38)`; green `µR` and blue `CNT` `(129,38)`. Relative to the first test, all were moved 4 px down; µR/CNT moved 11 px right and their call-to-label assignments were corrected.
- Foreground is white (`0xFFFF`) and glyph-cell background is tested dark gray RGB565 `0x2945`.
- Reproducible builders: `build_dose_labels_7x10_v1.py`, then `build_dose_labels_7x10_v2.py`. v2 is based on the v1 test.

## Dose raster mapping

RGB probe `firmware/experiments/port-20261004-1600-dose-raster-rgb-v10.hex` identified the three 21×20 raster blocks:

| Callsite | RGB probe color | Element |
|---|---|---|
| `0x0800A250` | Red | `µSv` |
| `0x0800A278` | Green | `µR` |
| `0x0800A2A2` | Blue | Click/trigger count (`CNT`) |

The RGB probe is diagnostic only. Text firmware is derived from `main-values-up5-v1`, not from the RGB probe. The v1 text test is retained under `firmware/experiments/`; v2 is approved.

## Font index and PNG cards

- Current extracted map: `docs/GEIGER2_FONT_MAP_2026-10-04-v7.md`. It was re-indexed from the approved v2 HEX; all four descriptors were checked against the firmware.
- Current PNG cards: `assets/GEIGER2_FONT_CARD_11x18_MEDIUM_v7.png`, `assets/GEIGER2_FONT_CARD_7x10_SMALL_v7.png`, and `assets/GEIGER2_FONT_CARD_5x8_TINY_v7.png`. They are rendered from the actual v2 raster bytes.
- 11×18 has 40 descriptor slots; slots 29–30 (`0x0800F4BC–0x0800F503`) now hold executable battery-helper code/literals, so only 38 are available as glyphs. They are not blank glyphs in current firmware.
- 7×10 has 35 table glyphs plus the custom `%` extension at `0x0800F904` (byte `0x43`). 5×8 has 12 glyphs. The active sets are selected glyph subsets, not full A–Z alphabets.
- Rerun `python3 reindex_geiger2_fonts_v7.py` and `python3 make_geiger2_font_cards_v7.py` from the export root to regenerate the map/cards.

## Other approved display behavior and protected blocks

- First-screen units remain 7×10 at `(80,61)` `µSv/h`, `(87,61)` `CPM`, `(83,61)` `µR/h`; glyph background RGB565 `0x2945` was confirmed on-device earlier.
- Main numeric/background readings in the current base are at `(81,33)`.
- Battery indicator helper selectors 8/9 remain active: gray percentage for battery and green percentage while charging. The v2 helper shares the same 7×10 draw setup; battery calls were preserved and checked.
- Confirmed do-not-change blocks and previous tests are in `docs/GEIGER2_BLOCK_MAP_2026-10-04-v2.md`. In particular, preserve ENERGY percentage blocks, dose progress bar, dose option icons/plaques, Mira startup logo, `LIMIT`, and the unknown first-screen element at `0x0800A53A`.
- Historical battery/ADC investigation and prior v5 details remain in `docs/GEIGER2_CONTINUATION_NOTES_2026-10-04-v5.md` and `docs/GEIGER2_BATTERY_CANDIDATES_2026-10-04.md`. No battery/solar voltage measurement is confirmed.

## Build validation

The v2 Intel HEX checksum/record validation, decode/encode round-trip, changed-byte bounds, renderer targets, and label byte strings passed. Device rendering was visually confirmed by the user, and v2 is accepted as the current basis.
