# Geiger‑2 continuation handoff — 2026‑10‑04 v5

## Попередня v13 основа для юнітів (тепер джерело v6)

Нижчеописана v13 залишається перевіреною базою фону та шрифтів, але поточна робоча основа для MAIN/battery — v6 green-charge з розділу наприкінці документа.

- Прилад: Mira Safety Geiger‑2, англійська прошивка 4.1.17; не змішувати з RU/EN HiStand гілкою.
- Попередня збірка: `firmware/source/port-20261004-1050-main-units-7x10-v13-darker-gray.hex`.
- SHA‑256: `86c47e1c2f4873ce0b585f644b8ae1cb7ce8d9eb1da1e3aa4a2313266ac64995`.
- Користувач прошив v13 та підтвердив фон; тепер v13 є вхідною версією для затвердженої v6 батарейної правки.
- v13 походить від v5; змінені тільки байти `0x0800A760–0x0800A761`, RGB565 фон гліфів `0x4A49 → 0x2945` (HEX байти `49 4A → 45 29`). Повна заливка 60×20 вимкнена й лишається вимкненою.

## Як виводяться одиниці на MAIN

- Виклик `0x0800AB34` викликає рендерер одиниць `0x0800A6F8`.
- Рендерер використовує 7×10 шрифт із `0x0800F648` і спільний `DRAW_STRING` за `0x08008E48`; монохромний rasterizer — `0x08008D64`, pixel writer — `0x08008BED`.
- До `DRAW_STRING` передаються таблиця шрифту, білий foreground `0xFFFF` і колір фону третього стекового аргументу. Фоновий літерал одиниць міститься за `0x0800A760`.
- `0x0800A758` — старий літерал повної прямокутної заливки. Інструкції цієї заливки замінені NOP, тому зміни там не змінюють фон символів. v7 помилково змінив саме `0x0800A758` і лишився візуально як v5.
- Розмір гліфа: 7×10. y=61. Позиції: `µSv/h` x=80, `CPM` x=87, `µR/h` x=83.
- Байт-коди рядків: `µSv/h` = `3F 3D 41 2F 40 00`; `CPM` = `29 42 27 00`; `µR/h` = `3F 22 2F 40 00`.
- У таблиці 7×10 індекс — код символу мінус `0x20`: `µ` = `0x3F`/31, `h` = `0x40`/32, `v` = `0x41`/33, `P` = `0x42`/34.
- Гліф `µ`: горизонтальна риска на рядку 6, як базова лінія `S`; хвостик на рядку 7.
- Перемальовка відбувається в циклі екрана. Окремий кеш для підписів не потрібен.

## Фон і як його підібрали

Колір тла ресурсного зображення в наданому HEX відсутній, тож точні RGB565 пікселі ресурсного фону з нього прочитати не вдалося. Проте колірний аргумент гліфів знайдено точно за кодом, а кінцевий відтінок підібрано на приладі:

- `0x08009252` малює основне числове значення через той самий `DRAW_STRING`.
- Перед числовим написом він використовує фон `0x0B6E`, завантажений із літерала близько `0x080092FC`; це ж значення використовується для сусідніх заливок. Користувач перевірив його на приладі: вийшов сіро-зелений тон.
- Для `0x0B6E` був зроблений нейтральний аналог тієї ж яскравості, потім кілька темніших проб.
- Переможний `0x2945` — нейтральний RGB565 приблизно `(41,40,41)`. Він застосований лише як фон клітинок символів, без 60×20 суцільної заливки.

| HEX/версія | Зміна | Результат |
|---|---|---|
| v5 `0x4A49` | Старий пробний сірий | Не збігався зі спільним тлом. |
| v6 | Прозорий sentinel/wrapper на растеризаторі | Напис зник, лишився смугоподібний артефакт. Не використовувати. |
| v7 | Помилково змінено `0x0800A758`, неактивний літерал | Видимого ефекту не було. |
| v8 `0x5AEB` | Світліший нейтральний | Користувач не побачив зміни. |
| v9 `0x0B6E` | Фон із числового рендерера | Сіро-зелений. |
| v10 `0x6B4D` | Нейтралізована яскравість v9 | Вигляд повернувся до попереднього; користувач попросив темніше. |
| v11 `0x5AEB` | Повтор цього RGB565 значення | Без видимої зміни. |
| v12 `0x39C7` | Темніший нейтральний | Користувач попросив ще темніше. |
| **v13 `0x2945`** | **Ще темніший нейтральний** | **Успіх, підтверджений користувачем. Робоча основа.** |

## Помилкову ресурсну зачіпку не відновлювати

Старий документ помилково трактував виклик `0x080091DC`, ресурс `0x236E`, як фонове зображення під юнітами. У попередньому continuation audit цей виклик віднесено до нижньої половини плитки меню 55×28; окреме вимкнення виклику не довело, що він малює юніти. Не чіпати його при наступних роботах над одиницями.

## Шрифти й візуальні карти

Повна таблиця гліфів і адрес наведена в `docs/GEIGER2_FONT_MAP_2026-10-04-v6.md`.

- 11×18 — середній набір за `0x0800F0A8`, 40 слотів; два дескриптори посилаються на нього. Старий 16×26 набір прибраний; `µ` і `h` у 11×18 очищені.
- 7×10 — малий набір за `0x0800F648`, 35 гліфів; цей набір іде на підписи MAIN.
- 5×8 — крихітний набір за `0x0800F9D4`, 12 гліфів.
- Рядки растру 16-бітні little-endian; біт 15 — піксель x=0.
- PNG карти всіх трьох наборів лежать у `assets/`.

## Історичне відтворення v13

Із кореня архіву запустити:

```sh
python3 build_main_units_7x10_v13_darker_gray.py
```

Скрипт бере `firmware/source/port-20261004-0915-main-units-7x10-v5.hex`, перевіряє SHA джерела й міняє лише два байти `0x0800A760–0x0800A761`. Після генерації перевірено всі Intel HEX checksums, round-trip декодування, список модифікованих байтів та SHA‑256.

## Вміст експорту

- `firmware/approved/`: v13 робоча HEX збірка.
- `firmware/source/`: v5 база, із якої відтворюється v13.
- `firmware/experiments/`: збережені v7–v12 для журналу; не використовувати як робочу прошивку.
- `docs/`: актуальна карта шрифтів v6 і цей handoff.
- `assets/`: PNG-карти середнього 11×18, малого 7×10 та крихітного 5×8 шрифтів.
- `history/`: попередній continuation export v3, збережений як історія. Цей handoff має пріоритет у питаннях першого екрана та фону юнітів.

## MAIN battery text alignment test — v4, 2026-10-04

- New layout test `port-20261004-1245-main-battery-text-v4-aligned.hex`, built from the user-confirmed v13 baseline.
- Selector 8 / `v2` draws fixed `100%` at `(3,5)`; selector 9 / `v3` draws lightning at `(17,5)`. The lightning string begins at `(3,5)` with two blank glyphs and ends with a blank glyph, so the same draw clears the old four-glyph percentage footprint. This remains a layout test; the live battery percentage is not yet connected.
- The custom 7×10 percent glyph now uses two solid 2×2 pixel blocks instead of ring-shaped dots. Foreground `0xC618`; background `0x2945`.
- Static firmware review: the EN 4.1.17-derived image contains references to STM32L0 ADC registers around `0x40012400` and `0x40012708`. This supports that ADC functionality exists, but does not yet identify the battery channel, voltage scaling, calibration, or percentage conversion path. The HEX contains executable code, not a history of runtime voltage readings.
- Solar: confirmed `v3` is the charging/bolt indicator. No independent solar-panel voltage measurement channel is confirmed yet; do not infer panel voltage from the icon alone. Need to trace ADC/GPIO sources and identify any divider/input before claiming measurement support.
- Earlier lab-supply voltage-to-percentage observations are recorded in the historical export's power section; they are empirical device readings and are not yet linked to this firmware's ADC conversion.
- Historical build script: `firmware/experiments/battery/` contains the v4/v5 HEX tests; only v6 is approved. SHA-256 for v4 HEX: `62c54606e998eb2c996f25f8a34fe72a501c808c7f5bc50eed84b831a1cbc77f`.

## Затверджена основа батарейного індикатора — v6, 2026-10-04

Користувач підтвердив `port-20261004-1305-battery-v6.hex` як нову основу для подальших правок першого екрана. Не повертатися до v13 як поточної робочої основи, якщо користувач окремо цього не попросить.

- SHA-256: `e0e7a86aa692fc19ac178aa894dbdd277b7cf0f6208d55320cdd97277374daaf`.
- База зібрана від підтвердженої v13; виклик `v2` (`0x0800A6DA`) відображає сірий `100%`, виклик `v3` (`0x0800A6B4`) — зелений `100%` для стану заряджання. Блискавку прибрано.
- Обидва написи починаються в `(3,5)` з однаковим темно-сірим фоном `0x2945`; кольори тексту: сірий `0xC618`, зелений RGB565 `0x07E0`.
- Відсотковий гліф — 7×10, верхній блок зсунений ліворуч, нижній піднятий на рядок.
- Це поки що статичний макет: `100%` не під’єднано до живого відсотка. Надалі дослідити ADC-шлях батареї; окремий вимір напруги сонячної панелі ще не підтверджений.
- Всі подальші HEX-зміни для MAIN/battery починати з цієї v6 основи.



## MAIN center value position test — v7, 2026-10-04

- Starting image: approved `port-20261004-1305-battery-v6.hex`. The battery display code is unchanged.
- The center numeric measurement and its character-cell background use the `DRAW_STRING` call at `0x08009252`. Its coordinates changed from x=63,y=26 to x=74,y=35.
- This is +11 px right (one medium-font 11×18 glyph) and +9 px down (half glyph height). The color/background arguments and font remain unchanged; the per-glyph background is drawn by the same call, so it follows the text.
- Test HEX: `firmware/experiments/main/port-20261004-1311-main-value-v7.hex`; builder: `build_main_value_position_v7.py`. HEX validation confirms only the two coordinate immediate bytes changed. User reported no visible movement after testing. The value draw call is therefore not yet confirmed as the visible source, or the exact test image was not applied; do not stack another positional patch until the active draw layer is identified.


## MAIN center value position — flashable v8, 2026-10-04

- Built explicitly from approved v6 `port-20261004-1305-battery-v6.hex`. Flash v8 to test the position change; v6 is only the source baseline.
- The central numeric value at `DRAW_STRING` call `0x08009252` moves from `(63,26)` to `(74,35)`, corresponding to +11 px right and +9 px down. Its 11×18 font, color and per-character background are unchanged; the background is drawn by the same call and follows the value.
- Only two coordinate-immediate bytes differ from v6. HEX checksums and round-trip decode pass. Device test pending.
- File: `firmware/experiments/main/port-20261004-1327-main-value-v8.hex`; builder: `build_main_value_position_v8.py`.
