# Geiger-2 continuation handoff — 2026-10-04 v7

## Current state

- Device firmware family: Mira Safety Geiger-2, EN 4.1.17.
- Frozen, user-approved working HEX: `firmware/approved/port-20261004-2235-settings-page-clear-v6.hex`.
- SHA-256: `f10069bdb4cd8f3084cf313c7bb3432aee6be89e5a9ee511b50b0efca00bcea6`.
- User's explicit direction: “фіксуєм версію 6”. The later v7 experiment was created after this approval and is **not** the base.
- Start future firmware work from SETTINGS v6. Preserve the user-confirmed Dose labels, main-screen units/background, battery behavior, fonts and protected raster blocks recorded in the maps.

## SETTINGS page behavior now frozen in v6

- The main SETTINGS page has seven text options: `Sv`, `CPM`, `R`, and the paired `ON`/`OFF` labels for sound and diode. The confirmed raster call mapping and coordinates are in `GEIGER2_BLOCK_MAP_2026-10-04-v2.md` and the archived SETTINGS build notes.
- Seven repeated rectangle-fill calls were disabled so the option tiles/icons and values remain without continuous fills.
- The SETTINGS screen uses the stock full-screen fill wrapper at `0x08008F70` with explicit RGB565 dark gray `0x1925` (literal at `0x0800B5A4`). The approved v6 includes the one-time transition clear; avoid reactivating the seven repeated fill calls.
- Approved v6 was built from `port-20261004-2043-settings-fill-probe-v1.hex` (based on the user-confirmed SETTINGS v11 labels build) and retains its one-shot transition handling. Reproducible builder and exact input are at the export root.

## SETTINGS test history and status

See `docs/SETTINGS_PAGE_CLEAR_HISTORY.md` and `firmware/history/settings-page/` for every SETTINGS HEX and builder from this iteration. Keep test builds separate from `firmware/approved/`.

- `port-20261004-2235-settings-page-clear-v6.hex` — **approved and frozen working base**.
- `port-20261004-2227-settings-page-clear-v7.hex` — generated after the v6 freeze; **unapproved, do not use as the base**.
- `port-20261004-2210-settings-page-clear-v3.hex` — direct repeated call produced the wrong green/flickering fill; rejected.
- `port-20261004-2219-settings-page-clear-v4.hex` — its clear did not trigger on entry; rejected.
- `port-20261004-2227-settings-page-clear-v5.hex` — user reported a reboot; rejected.

The user is frustrated by speculative patches, wrong or stale filenames, and prolonged analysis. Make only the requested change, check the exact selected base and output name, increment version/time, and provide a flashable HEX promptly. Communicate in Ukrainian. Do not say a device result is verified unless the user reports it.

## Prior approved display work retained

- Dose labels: `µSv`, `µR`, and `CNT` in the 7×10 font; positions and background are in v6 notes and the block map.
- Main-screen units/background and battery changes remain as documented in the previous continuation notes.
- Three current font cards and the re-indexed font map are included.
- Preserve ENERGY percentage blocks, Dose progress bar/menu icons, startup Mira logo, `LIMIT`, and unknown first-screen object as listed in the block map.

## Files for immediate continuation

- Approved base: `firmware/approved/port-20261004-2235-settings-page-clear-v6.hex`.
- Base input for rebuilding this exact v6 clear change: `port-20261004-2043-settings-fill-probe-v1.hex`.
- Builder: `build_settings_page_clear_once_v6.py`.
- Comprehensive maps and older context: `docs/` and `history/`.
