# Geiger-2 block map — 2026-10-04, v2

## Approved working base

- `port-20261004-1440-main-value-v9.hex`
- SHA-256: `a36435e0b0f9dbb27b2b6c0b343cdc27f069ba84dbe807168d6dfb2a9b6befac`
- User confirmed the result. At `0x0800A8E4`, the normal text draw is restored and shifted from `(70,29)` to `(81,38)` (+11,+9 px). Use v9 as the basis for subsequent work.

## Current working base

- `port-20261004-1540-main-values-up5-v1.hex`
- SHA-256: `f246ac3ad2ad31a93aae215bbdf45b5a068d842766bdfffdd5d298688bde55d1`
- User approved it as the new base. The stock numeric renderer is active for CPM (`0x0800A898`) and background value (`0x0800A8E4`), both at `(81,33)`.

## Confirmed blocks — do not change

| Callsite | Screen / location | What it is | Status |
|---|---|---|---|
| `0x08009538` | ENERGY `(132,30)` | One of the solar/battery percentage blocks | Confirmed by user; do not change |
| `0x08009594` | ENERGY `(132,45)` | The other solar/battery percentage block | Confirmed by user; do not change |
| `0x08009BE2` | Dose options menu, dynamic x / y=30 | Menu option block | Confirmed by user; do not change |
| `0x08009C0A` | Dose options menu, dynamic x / y=30 | Menu option block | Confirmed by user; do not change |
| `0x08009DF2` | Dose options menu, dynamic x / y=30 | Menu option block | Confirmed by user; do not change |
| `0x0800A8E4` | Background measurement, old `(70,29)` | Numeric background reading | Confirmed by user; v9 restores text and moves it to `(81,38)` |
| `0x0800A33C` | DOSE `(69,60)`, 60×20 | `LIMIT` | Previously confirmed; do not change |

The user has not assigned solar versus battery to the two ENERGY positions individually; keep the pair grouped.

## Known three raster unit assets from earlier work

These are the three 60×20 raster calls at the same main-screen position `(60,56)`. Their RGB test and mapping were already completed in earlier work. They are distinct from the `µSv` label on the accumulated-dose DOSE screen.

| Callsite | Resource offset | Unit | Current main-screen handling |
|---|---:|---|---|
| `0x0800A72E` | `0xB8A8` | `µSv/h` | Replaced by the 7×10 text renderer |
| `0x0800A752` | `0xCB68` | `CPM` | Replaced by the 7×10 text renderer |
| `0x0800A776` | `0xC208` | `µR/h` | Replaced by the 7×10 text renderer |

Do not repeat the color test on these three main-screen unit assets while searching the DOSE screen.

## Current DOSE-screen search

- Target: raster `µSv` unit beside the accumulated dose on the DOSE screen, shown in the historical export as `upload/02-image.png`.
- User's latest hypothesis: this target is probably a raster block; there may be three corresponding blocks for three quantities. Treat this as a lead, not a confirmed address mapping.
- Keep separate from the Dose **options menu**, the main-screen `µSv/h`/`µR/h`/`CPM` triplet, and the background-rate value.
- `0x08009B44` (47×27 at `(112,22)`) and `0x08009D6A` (47×27 at `(0,22)`) are the two upper plaques in DOSE; user confirmed both are not the target. Do not recolor.
- `0x0800A592` (69×20 at `(50,30)`) is the Mira startup logo; user confirmed it. Keep unchanged, retain as a possible future asset.

### Raster source path for the Mira logo (`0x0800A592`)

- `0x0800A592` is a Thumb `BL` to the resource dispatcher at `0x0800AFE4`; it is executable MCU code, not a bitmap address.
- Its arguments resolve to selector `r0=8`, resource offset `0x0000`, length `2760` bytes (`69 × 20 × 2`, RGB565), and destination `(50,30)`. The same selector, offset, byte length, and geometry are requested at `0x0800373C`; these two call sites therefore request the same raster resource. The observed Mira logo and the repeated request strongly support reuse of one asset across the two screens, though their exact boot/shutdown roles are not independently mapped here.
- Dispatcher `0x0800AFE4` routes the pixel buffer to the RGB565 blitter at `0x0800B04C` / `0x08008F86`. The resource reader path (`0x0800E43C`, reached through helpers) issues a block-read command with a 32-bit resource offset over SPI1 before blitting. The 2760 bitmap bytes are not present in the 64 KiB MCU Intel HEX image.
- This establishes an SPI-backed resource-read path external to the MCU firmware image. It does **not** identify the physical storage chip: the 8-pin `R80B 104AB` remains unverified, and the reader’s presence alone does not prove what component responds on the bus.
- Skipping either draw call can suppress that screen’s logo and avoid its resource read/blit. It will not free the 2760 raster bytes from the MCU HEX, because they are not stored there. Removing the data itself requires identifying and safely editing the backing resource storage. Startup-time savings would be limited to one resource read plus one 69×20 blit.
- `0x0800A31A` (80×25 at `(70,50)`) is also unknown and its prior disable test produced no visible change.
- `0x0800A33C` is `LIMIT`; leave it unchanged.

## Recent RGB probes

| Firmware / calls | Result |
|---|---|
| `dose-usv-rgb-v2`: `0x08009538` red; `0x08009594` green; `0x08009F9E` blue | User identified the first two as the ENERGY solar/battery percentage blocks. Do not change them. `0x08009F9E` is still unidentified. |
| `dose-usv-rgb-v3`: `0x08009BE2` red; `0x08009C0A` green; `0x08009DF2` blue | User identified these as Dose options-menu blocks. Do not change them. |
| `dose-usv-rgb-v4`: `0x0800A898` red at `(70,29)`; `0x0800A8E4` green at `(70,29)`; `0x0800A0B6` blue at dynamic x/y=30 | User identified green as background measurement and red as CPM. v9 moves the green background reading to `(81,38)`; the red CPM branch is being checked at the same position. Blue remains unidentified. |
| `dose-usv-rgb-v5` (local experiment only) | It probes text renderer calls `0x080099BC/0x080099EA/0x08009A14`. The user now suspects a raster asset; do not flash this text-oriented probe. |

## Earlier wrong candidates — exclude

- `0x0800AA30`: working lower half of a main-screen menu icon.
- `0x08009B2A`, `0x08009D4E`: working lower halves of colored menu tiles.
- `0x08009B5E`: confirmed Dose-menu plaque.
- These were touched in an early incorrect RGB experiment; never include them in future probes.

## Direction for next probe

Continue from approved v9. Inspect raster/resource-blitter calls on the DOSE screen and compare repeated dimensions, positions, and resource selection. Do not use text-renderer callsites as candidates until the raster-call mapping is checked. Record each tested callsite, geometry, observed screen/element, and user's identification before preparing the next HEX.

## Raster probe prepared after the user's clue

- HEX: `port-20261004-1445-dose-raster-rgb-v1.hex`; based on approved v9.
- The probe paints 33×18 diagnostic fills over three unclassified RGB565 asset calls. It does not yet claim these are the three unit variants.

| Callsite | Original asset geometry | Test color | Prior record |
|---|---|---|---|
| `0x08009B44` | 47×27 at `(112,22)` | Red | Earlier disable gave no visible change; now tested with an explicit overlay fill |
| `0x08009D6A` | 47×27 at `(0,22)` | Green | Earlier disable gave no visible change; now tested with an explicit overlay fill |
| `0x0800A592` | 69×20 at `(50,30)` | Blue | Earlier disable gave no visible change; now tested with an explicit overlay fill |

- The `0x0800A33C` `LIMIT` asset is excluded. The confirmed ENERGY percentage blocks, Dose-menu options and moved background value are unchanged.
- SHA-256: `b62d513228c2972deaacaca02d093885e8d72102b800dac118a5c6e50eb5d8d3`.
- Await the user's visual identification before labeling any of these candidates as the `µSv` unit or as one of three quantity variants.

## Latest user identification and raster probe

- User confirmed the red and green blocks in raster probe v1 are the two upper plaques in the DOSE screen; neither is the sought unit.
- User confirmed the blue block in raster probe v1 is the Mira startup logo. Preserve it for possible later use.
- Do not repeat any of those three callsites: `0x08009B44`, `0x08009D6A`, `0x0800A592`.
- User identified the red, green and blue overlays in raster probe v2 as fragments of the working DOSE progress bar. Preserve all three calls unchanged: `0x08009D84`, `0x0800A1DA`, `0x0800A1F2`.
- Next test HEX: `port-20261004-1500-dose-raster-rgb-v2.hex`, based on approved v9.
- v2 tests three previously unclassified resource-renderer calls. The test replaces each call with a 33×18 solid RGB565 overlay at an intentionally separated screen position, so the visible color identifies which call ran; positions are diagnostic overlay coordinates, not claims about the original asset coordinates.

| Callsite | Resource / original dimensions | Probe color and overlay `(x,y)` | Identification |
|---|---|---|---|
| `0x08009D84` | `0x99EA`, 47×28 | Red `(30,48)` | Dose progress-bar fragment; working, do not change |
| `0x0800A1DA` | `0x6000`, 55×27 | Green `(73,48)` | Dose progress-bar fragment; working, do not change |
| `0x0800A1F2` | `0x6B9A`, 55×28 | Blue `(116,48)` | Dose progress-bar fragment; working, do not change |

- SHA-256: `4cb2d9532605f77268e7ad929182301cf2f334b73ec2519cc91f9bf61355d398`.
- This probe is diagnostic, not an approved base. Confirmed ENERGY blocks, Dose-menu options, background value, `LIMIT`, both DOSE upper plaques, Mira boot logo and main-screen unit assets remain unchanged.

## Following raster probe

- v3 tests three other unclassified 80×18 RGB565 calls from the same general display-code region. Fill overlays are red/green/blue at `(28,48)`, `(71,48)`, `(114,48)`.
- Calls: `0x08009D00` (resource offset `0x4EC0`), `0x0800A07C` (`0x4EC0`), `0x0800A060` (`0xD99E`). These remain unclassified until the user observes the screen.
- Exclude all known working blocks above, including the progress-bar triplet.

## v3 probe result and next candidates

- User saw only a brief red element in the Dose menu; green and blue were not visible. The red call `0x08009D00` is therefore excluded from the unit search and must not be altered further. Exact menu element is not identified.
- v3 did not locate the target `µSv` unit on the second screen.
- Next HEX: `port-20261004-1520-dose-raster-rgb-v4.hex`, based on approved v9.

| Callsite | Resource and geometry | Probe overlay | Status |
|---|---|---|---|
| `0x08009F24` | `0x8ADE` dynamic, 80×18 | Red `(28,48)` | Dose progress-bar fragment; do not change |
| `0x08009F40` | `0x4380` dynamic, 80×18 | Green `(71,48)` | Dose progress-bar fragment; do not change |
| `0x0800A31A` | Dynamic resource, 80×25 | Blue `(114,48)` | Dose progress-bar fragment; do not change |

- Confirmed menu elements, Dose progress-bar fragments, boot logo, ENERGY values, background reading, `LIMIT`, and known unit assets are not modified.

## v4 probe result and next candidates

- User identified all three v4 overlays as other pieces of the working Dose progress bar. Do not alter `0x08009F24`, `0x08009F40`, or `0x0800A31A`.
- The target unit remains unidentified. All progress-bar calls found so far are excluded from further probes.
- Next HEX: `port-20261004-1507-dose-raster-rgb-v5.hex`, based on approved v9.

| Callsite | Resource notes | Probe overlay | Status |
|---|---|---|---|
| `0x08009EBC` | Resource length `0x866` | Red `(28,48)` | Awaiting observation |
| `0x08009ED2` | Resource length `0xA1E` | Green `(71,48)` | Awaiting observation |
| `0x08009F64` | Dynamic resource selection | Blue `(114,48)` | Awaiting observation |

- v5 result: user saw no visible colored blocks. These calls are not confirmed as the target; leave their purpose unknown and do not infer that the resources are absent.

## Next test: v6

- Based on the raster inventory, v6 tests two remaining unclassified calls in the same code region as the DOSE display. Both request resource `0x7800` with 55×27 geometry.
- `0x08009B0C` is red at `(34,48)`; `0x08009D30` is green at `(91,48)`. These are diagnostic overlay positions, not original asset positions.
- HEX: `port-20261004-1515-dose-raster-rgb-v6.hex`, based on approved v9. Their screen role is unknown pending observation.

- v6 result: user identified both overlays as the lower Dose plaques. Do not change `0x08009B0C` or `0x08009D30`.

## Next test: v7

- Raster probes so far have identified only plaques, progress-bar pieces, and the boot logo, or produced no visible result. v7 checks three candidate text-renderer calls that execute through `0x08008E48` in the DOSE display routine; it paints colored 33×18 fills at separated positions to reveal which calls run on the tested screen.
- Red `0x080099BC` at `(30,48)`, green `0x080099EA` at `(73,48)`, blue `0x08009A14` at `(116,48)`.
- This tests the revised possibility that the unit label is rendered as text; the user notes there may be two unit variants (`µSv` and `mSv`) and no CPM unit.
- HEX: `port-20261004-1520-dose-renderer-rgb-v7.hex`, based on approved v9.
- v7 result: all three calls are dose-value renderers, not unit labels. Red `0x080099BC` is the `µR` dose reading, green `0x080099EA` is the `µSv` dose reading, and blue `0x08009A14` is the CPM reading. Restore/use the v9 versions of all three; do not change these calls while searching for the unit text.
- User notes the DOSE page may need only two unit labels (`µSv` and `mSv`); CPM is dimensionless and needs no unit suffix.
- The unit label beside the dose number remains unlocated. Keep value rendering and the separate unit label as distinct targets.

## CPM position control build

- User identified the red `0x0800A898` branch from the earlier RGB test as CPM. Move it by the same delta as the green background value: from `(70,29)` to `(81,38)` (`+11,+9`).
- Diagnostic HEX `port-20261004-1535-main-value-cpm-shift-v1.hex` temporarily painted the CPM branch red at `(81,38)`.
- It is superseded by `port-20261004-1540-main-values-up5-v1.hex`, which restores numeric text and moves both readings up 5 px.

## Numeric position adjustment

- User rejected the red fill and requested the actual numbers back. New HEX restores the stock text renderer on both calls.
- `0x0800A898` (CPM path identified from the earlier red probe) moves from `(70,29)` to `(81,33)`.
- `0x0800A8E4` (background reading) moves from `(81,38)` to `(81,33)`.
- HEX `port-20261004-1540-main-values-up5-v1.hex` is based on the attached approved v9 and changes only three coordinate-immediate bytes. It moves both blocks 5 px upward while aligning them at x=81.

## Next raster candidates: v8

- Probe HEX `port-20261004-1545-dose-raster-rgb-v8.hex` is based on the newly approved `main-values-up5-v1`.
- It tests three remaining RGB565 asset calls associated with screen-group B, using separate 33×18 overlays at y=46:

| Callsite | Resource length | Probe color / overlay x | Status |
|---|---:|---|---|
| `0x08009DA4` | 456 bytes | Red / 28 | Dose options icon; do not change |
| `0x08009DC0` | 704 bytes | Green / 71 | Dose options icon; do not change |
| `0x0800A53A` | 450 bytes | Blue / 114 | Unknown first-screen item between value and unit |

- The already confirmed dose plaques, progress-bar calls, numeric dose renderers, moved CPM/background values, LIMIT, and boot logo are unchanged.
- v8 result: `0x08009DA4` red and `0x08009DC0` green are icons in the Dose options. Do not change either. `0x0800A53A` blue is an unknown element on the first screen between the number and unit; preserve as unknown and do not alter without a separate request.

## Next raster candidates: v9

- Probe HEX `port-20261004-1555-dose-raster-rgb-v9.hex` is based on the current approved `main-values-up5-v1`.

| Callsite | Resource length | Probe color / overlay x | Status |
|---|---:|---|---|
| `0x0800A51C` | 390 bytes | Red / 28 | Unknown element beneath an icon on the first screen |
| `0x0800A67C` | 576 bytes | Green / 71 | No visible result |
| `0x0800A92A` | 1,342 bytes | Blue / 114 | Visible around the same first-screen area as prior blue `0x0800A53A`; separate call on clean base, exact object unresolved |

- The Dose option icons, Dose plaques, progress bar, numeric renderers, moved CPM/background readings, `LIMIT`, Mira logo, and `0x0800A53A` are unchanged.

## Next raster candidates: v10

- Probe HEX `port-20261004-1600-dose-raster-rgb-v10.hex` is based on current approved `main-values-up5-v1`.
- It tests a set of three same-size 840-byte RGB565 asset variants in screen-group B:

| Callsite | Dynamic resource base | Probe color / overlay x | Status |
|---|---:|---|---|
| `0x0800A250` | `0x0690` | Red / 28 | Awaiting observation |
| `0x0800A278` | `0x09D8` | Green / 71 | Awaiting observation |
| `0x0800A2A2` | `0x0D20` | Blue / 114 | Awaiting observation |

- Dose menu icons and every previously identified block remain unchanged.

## Confirmed DOSE unit/count labels from v10

The user identified all three v10 color overlays:

| Callsite | v10 color | Confirmed meaning | Text label to use |
|---|---|---|---|
| `0x0800A250` | Red | `µSv` | `µSv` |
| `0x0800A278` | Green | `µR` | `µR` |
| `0x0800A2A2` | Blue | Click/trigger count | `CNT` (recommended; `C` is ambiguous and `CLC` is nonstandard) |

`µ` means micro (`10⁻⁶`), as in the user's clarification. The 7×10 font already has the needed µ/S/v/R/C/N/T glyph shapes, though its byte mapping is custom rather than ASCII. The proposed labels fit the 21-pixel slot: `µSv` and `CNT` are three glyphs; `µR` uses two. The user requested the same 7×10 font used for the first-screen labels.

The RGB probe `port-20261004-1600-dose-raster-rgb-v10.hex` is diagnostic only and is not an approved base. Continue from `port-20261004-1540-main-values-up5-v1.hex` (SHA-256 `f246ac3ad2ad31a93aae215bbdf45b5a068d842766bdfffdd5d298688bde55d1`). The v10 test overlay coordinates are artificial and must not be reused as label positions; the v1 text build estimates its position from the original DOSE screenshot.

### First text-render test build

- HEX: `port-20261004-1616-dose-labels-7x10-v1.hex`; SHA-256 `3774b850a7fef797c11ee9e59b41283eb537f59680f627c930b39181499e6acf`.
- Built from the approved `main-values-up5-v1` base, not from the RGB probe.
- The three confirmed calls now select custom 7×10 strings `µSv`, `CNT`, and `µR`. They use white foreground and the tested `0x2945` dark-gray character-cell background. `CNT` is shown for the count/click field; it is not `CPM`.
- The screen position `(118,34)` was estimated from the original DOSE screenshot and is the main visual point to check on-device. Font size is 7×10, so the 21-pixel-wide labels should fit the 21-pixel slot; `µR` occupies two glyph cells.
- The battery helper is shared by the new labels; its original selectors 8/9 and calls remain active for the battery percentage.
- Build script: `build_dose_labels_7x10_v1.py`. Intel HEX checksums, decode/encode round-trip, changed-byte bounds, call targets, string codes, and unchanged battery callsites were checked. Device rendering is not yet confirmed; treat v1 as a test build until flashed.

### Second text-render test build

- HEX: `port-20261004-1639-dose-labels-7x10-v2.hex`; SHA-256 `4b77d5d1c9544e8af0d6396945fdf978afd907fcae09b68fb76fd681580608cc`.
- Built incrementally from the v1 test HEX. The red `µSv` stays at x=118; the green and blue labels are swapped to `µR` and `CNT` respectively, per the corrected mapping.
- All three labels move down 4 px to y=38. Green `µR` and blue `CNT` also move right 11 px to x=129; red `µSv` remains at x=118.
- Build script: `build_dose_labels_7x10_v2.py`. Validation checks Intel HEX records and checksums, round-trip decoding, expected renderer call targets, string bytes, and the modified-byte boundary. Device rendering is not yet confirmed.

## Top-level SETTINGS page values — confirmed 2026-10-04

These are the seven RGB565 value blocks on the top-level SETTINGS page shown in the user screenshot. They are separate from the inner settings menu callsites around `0x0800B71A`–`0x0800C020`.

| Callsite | Meaning | Identified by |
|---|---|---|
| `0x0800B51C` | `Sv` unit option | v4 blue |
| `0x0800B542` | `CPM` unit option | v5 red |
| `0x0800B566` | `R` unit option | v5 green |
| `0x0800B406` | Sound `ON` | v3 green |
| `0x0800B4D2` | Sound `OFF` | v4 red |
| `0x0800B430` | Diode `ON` | v3 blue |
| `0x0800B4F6` | Diode `OFF` | v4 green |

RGB tests used the approved logo-on base `port-20261004-1639-dose-labels-7x10-v2.hex`. Diagnostic overlays were drawn along the bottom edge; dose labels were suppressed only in those temporary probes because their helper address was reused. The user has now identified all seven target blocks. The temporary tests are not approved firmware. The next implementation task is to replace these seven raster calls with the corresponding text values while retaining the existing inner settings menu and startup logo.

Other page-level candidates tested nearby but not yet identified: v2 `0x0800B36E` red, `0x0800B38A` green, `0x0800B3B0` blue; v3 `0x0800B3DC` red. User reported some visible object(s) on SETTINGS for v2 but not the target values; do not map these to the seven labels without another observation.

## User observations — 2026-10-06

- Color-probe v6 tested text call `0x08009F9E`; user identified it as a numeric field in the DOSE menu's number editor. Do not use it for ENERGY. The raster assets beside this field may be reviewed later.
- Color-probe v7 tested text call `0x0800A0B6`; user identified it as another numeric field in the DOSE menu's number editor. Do not use it for ENERGY. The raster assets beside this field may be reviewed later.
- Color-probe v8 tested `0x0800E0E6`; user identified it as the first two of four year digits in the TIME menu's year editor.
- Color-probe v9 marks five text-render calls in the nearby D/E code range in distinct colors: `0x0800DC74` red, `0x0800DD54` green, `0x0800DE38` blue, `0x0800E002` cyan, and `0x0800E0E6` dark red (reference field). Awaiting device observation.
- Color-probe v9 result: all five marked calls are in the TIME number editor, not ENERGY. User mapping: `0x0800DC74` red = hours; `0x0800DD54` green = minutes; `0x0800DE38` blue = days; `0x0800E002` violet = months; `0x0800E0E6` dark yellow = first half of year (first two of four digits). Exclude these five from further ENERGY searches.
- Color-probe v9 result from user: these are TIME number-editor fields, not the ENERGY target. Red=`hours`, green=`minutes`, blue=`days`, violet=`months`, dark yellow=`first half of year` (first two of four digits). These five are excluded from the ENERGY search. User requests using pink instead of repeating blue in later probes.
- Color-probe v10 result: the five marked calls `0x0800A2EC`, `0x0800A73E`, `0x0800AAA6`, `0x0800AAD2`, and `0x0800AAE8` belong to screens 1, 2, and 4; none is the ENERGY power-off-time value. Exclude them from that search. Pink replaced the second blue as requested.
- Color-probe v11 tests five separate, previously untested text-render calls: red `0x0800C986`, green `0x0800C9A6`, blue `0x0800C9C6`, pink `0x0800CA40`, and dark yellow `0x0800CA7C`. Probe HEX is `port-20261006-0015-energy-off-color-v11.hex`, based on `port-20261005-1751-energy-stats-5x8-v2.hex`; SHA-256 `6921985d8409331e624ed6f60e7c52ec3e5024d36dbd3be48f709b7c1072b882`. Awaiting device observation; do not treat these as ENERGY until confirmed.
