# Geiger-2: battery display search candidates

All candidates are diagnostic, not yet confirmed on the device. Each is built separately from the user-confirmed v13 baseline; do not combine them.

| File | Isolated draw call disabled | Size indicated by resource call | Reason to test |
|---|---:|---:|---|
| `port-20261004-main-battery-v2-dynamic-17x17.hex` | `0x0800A6DA` | Dynamic resource stride `0x0242` = 578 bytes = 17×17 RGB565 | A variable-selected series of same-size sprites is consistent with a stateful status icon. |
| `port-20261004-main-battery-v3-static-24x12.hex` | `0x0800A6B4` | 576 bytes = 24×12 RGB565 | A nearby fixed-size resource call in the same code region; test independently. |

The user confirmed the visual roles on the device: **v2 (`0x0800A6DA`) is the battery-level indicator; v3 (`0x0800A6B4`) is the charging icon.** The earlier isolated-call tests established those targets.

The geometry evidence needs careful interpretation before replacing either draw with text. v2 selects a frame with stride `0x0242` (578 bytes) while the inventory lists 576 image bytes per frame; this may mean a 576-byte payload plus 2-byte record/alignment overhead, so `17×17` must not be treated as confirmed solely from the stride. v3's 576-byte static resource is consistent with 24×12 RGB565. The bitmap contents and destination coordinates are not decoded in this export. The previous `battery-v1` test skipped two unrelated-size candidates (`0x080091A8` and `0x080091F8`); those are not included here.

## Confirmed replacement goal

- Add a lightning glyph to the tiny 5×8 font and draw it in place of v3.
- Replace v2's battery-level graphic with a numeric percentage, matching the ENERGY screen's number rendering.
- Preserve the live battery value; a hard-coded `100%` is useful only as a layout probe and is not an acceptable final indicator.
- Before building a combined HEX, identify the percentage value or its conversion path, and verify the draw coordinates and available glyph/code space. Do not infer image dimensions from the 578-byte stride alone.

## First text-renderer layout test

Built `port-20261004-1140-main-battery-text-v1-layout-test.hex` from the confirmed v13 base. The build redirects the two resource BL calls to a compact helper that uses the known `DRAW_STRING` interface:

- v3 call: draw one custom 5×8 lightning glyph.
- v2 call: draw fixed `100%` using custom 5×8 glyphs.
- Both strings start at `(0,0)`; white foreground and v13-tested RGB565 background `0x2945`.
- Custom glyph table: `0x0800F904`; helper: `0x0800F4BC`. The helper occupies the two cleared 11×18 glyph slots for `µ` and `h`; this is only safe if those removed medium-font glyphs are not needed elsewhere.
- This build is a **layout test**: `100%` is fixed. It does not yet display a live percentage and has not been tested on the device.

Build script: `build_main_battery_text_test_v1.py`. The script checks the v13 source hash, free-space contents, both Thumb BL targets, Intel HEX checksums, round-trip decoding, and that all modified bytes stay in the helper/glyph/callsite areas.

## Test order

1. Flash v2 and inspect only the first screen: battery, time, solar marker, and any leftover patch/blank area.
2. Restore v13 before testing v3, so each result is isolated.
3. If either candidate affects the battery icon, record any other element that disappeared or changed.

## Rebuild

From this directory run:

```sh
python3 firmware/experiments/battery/build_main_battery_candidates_v2_v3.py
```

The script validates the v13 SHA-256, checks each Thumb BL target, replaces only that one 4-byte call with two NOPs, validates Intel HEX checksums and round-trip decoding, and reports each output hash.


## Актуальний стан у continuation export v5

- Затверджена основа: `firmware/approved/port-20261004-1305-battery-v6.hex` (SHA-256 `e0e7a86aa692fc19ac178aa894dbdd277b7cf0f6208d55320cdd97277374daaf`).
- `v2` відображає сірий `100%`, `v3` під час заряджання — зелений `100%`; блискавку видалено. Координати обох рядків `(3,5)`, фон `0x2945`, кольори `0xC618` і `0x07E0`.
- Це все ще статичний макет `100%`. Живе значення батареї та вимір напруги сонячної панелі не під'єднані/не підтверджені. Див. continuation notes v5 для ADC-знахідок і наступних кроків.
- Попередні battery discovery HEX-и та проби розкладки v4/v5 збережені в `firmware/experiments/battery/`; це історичні експерименти, не основа.
