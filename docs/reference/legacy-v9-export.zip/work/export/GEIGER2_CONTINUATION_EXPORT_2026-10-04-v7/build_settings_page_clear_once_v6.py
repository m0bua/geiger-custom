#!/usr/bin/env python3
"""One gray SETTINGS clear per transition, without CBZ/CBNZ instructions."""
from pathlib import Path
import hashlib
FLASH=0x08000000
BASE=Path(__file__).resolve().parent/'port-20261004-2043-settings-fill-probe-v1.hex'
OUT=Path(__file__).resolve().parent/'port-20261004-2235-settings-page-clear-v6.hex'
SHA='fdf2055c37649edaa725c8df30127ca284688183c45a77fd354d404facb09205'
GUARD=0x0800B2D8; TEST=0x0800B314; SKIP=0x0800B316; LDR=0x0800B318; CALL=0x0800B31A; RESUME=0x0800B31E; GRAY=0x0800B5A4; FILL=0x08008F70

def dec(p):
 im=bytearray([255])*0x10000;u=0
 for l in p.read_text().splitlines():
  if not l.startswith(':'):continue
  r=bytes.fromhex(l[1:]);n,hi,lo,t=r[:4];d=r[4:-1]
  if len(d)!=n or sum(r)&255:raise ValueError('bad HEX')
  if t==4:u=int.from_bytes(d,'big')<<16
  elif t==0:
   o=u+(hi<<8)+lo-FLASH
   if not 0<=o<=len(im)-n:raise ValueError('range')
   im[o:o+n]=d
  elif t==1:break
 return im
def enc(im):
 out=[':020000040800F2']
 for o in range(0,len(im),16):
  r=bytes([16,o>>8,o&255,0])+im[o:o+16];out.append(':'+(r+bytes([(-sum(r))&255])).hex().upper())
 return '\n'.join(out+[':00000001FF',''])
def bl(a,t):
 d=t-(a+4)
 if d&1 or not -(1<<24)<=d<(1<<24):raise ValueError('BL range')
 x=d&0x1ffffff;s=x>>24&1;i=x>>23&1;j=x>>22&1;j1=1^(i^s);j2=1^(j^s)
 return (0xf000|(s<<10)|((x>>12)&0x3ff)).to_bytes(2,'little')+(0xd000|(j1<<13)|(j2<<11)|((x>>1)&0x7ff)).to_bytes(2,'little')
def target(im,a):
 o=a-FLASH;h1=int.from_bytes(im[o:o+2],'little');h2=int.from_bytes(im[o+2:o+4],'little')
 if h1&0xf800!=0xf000 or h2&0xd000!=0xd000:raise ValueError('not BL')
 s=h1>>10&1;j1=h2>>13&1;j2=h2>>11&1;i1=1^(j1^s);i2=1^(j2^s);x=(s<<24)|(i1<<23)|(i2<<22)|((h1&0x3ff)<<12)|((h2&0x7ff)<<1)
 return (a+4+(x-(1<<25) if s else x))&0xffffffff
if hashlib.sha256(BASE.read_bytes()).hexdigest()!=SHA:raise ValueError('base changed')
im=dec(BASE);old=bytes(im)
assert im[GUARD-FLASH:GUARD-FLASH+16]==bytes.fromhex('03 4B 1B 78 00 2B 02 D1 01 4B 01 22 1A 70 70 47')
assert im[TEST-FLASH:TEST-FLASH+10]==bytes.fromhex('0F 23 00 BF 00 BF 00 BF 00 BF')
assert im[GRAY-FLASH:GRAY-FLASH+4]==bytes.fromhex('25 19 00 00')
# The guard still owns the same state byte. Only use r6 to carry its pre-set value
# to B314; r6 is saved by the enclosing renderer and first written there at B320.
im[GUARD-FLASH:GUARD-FLASH+16]=bytes.fromhex('03 4B 1E 78 00 2E 02 D1 01 4B 01 22 1A 70 70 47')
# cmp r6,#0; bne B31E; ldr r0,[B5A4]; bl screen_fill. The retired title setup at
# B314 is safe space because its corresponding title call has been NOP since v11.
im[TEST-FLASH:TEST-FLASH+2]=bytes.fromhex('00 2E')
d=RESUME-(SKIP+4);assert d==4
im[SKIP-FLASH:SKIP-FLASH+2]=(0xd100|((d>>1)&0xff)).to_bytes(2,'little')
pc=(LDR+4)&~3;d=GRAY-pc;assert 0<=d<=1020 and d%4==0
im[LDR-FLASH:LDR-FLASH+2]=(0x4800|d//4).to_bytes(2,'little')
im[CALL-FLASH:CALL-FLASH+4]=bl(CALL,FILL);assert target(im,CALL)==FILL
OUT.write_text(enc(im));ck=dec(OUT);assert ck==im
for l in OUT.read_text().splitlines():assert not(sum(bytes.fromhex(l[1:]))&255)
changed={i for i,(a,b) in enumerate(zip(old,ck))if a!=b};allowed=set(range(GUARD-FLASH,GUARD-FLASH+16))|set(range(TEST-FLASH,TEST-FLASH+10));assert changed<=allowed, sorted(changed-allowed)
print('Output:',OUT);print('SHA-256:',hashlib.sha256(OUT.read_bytes()).hexdigest())
print('Entry r6=0: CMP falls through -> load 0x1925 -> BL full fill -> B31E.')
print('Redraw r6=1: BNE B31E, no fill. No CBZ/CBNZ or custom branch-through-return is used.')
