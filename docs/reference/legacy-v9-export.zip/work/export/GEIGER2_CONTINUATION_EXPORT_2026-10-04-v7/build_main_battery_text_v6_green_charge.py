#!/usr/bin/env python3
"""Test replacing MAIN battery/charge sprites with 7x10 text from v13.

Selector 9 (v3) -> fixed "100%" in green while charging.
Selector 8 (v2) -> fixed "100%" in light gray while discharging.
Both use the same origin (3,5), 7x10 glyphs, and dark background.
The percentage remains fixed in this layout test; no lightning glyph is used.
"""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('firmware/source/port-20261004-1050-main-units-7x10-v13-darker-gray.hex')
OUT = Path('firmware/approved/port-20261004-1305-battery-v6.hex')
SOURCE_SHA256 = '86c47e1c2f4873ce0b585f644b8ae1cb7ce8d9eb1da1e3aa4a2313266ac64995'
CHARGE_CALL = 0x0800A6B4
BATTERY_CALL = 0x0800A6DA
HELPER = 0x0800F4BC   # two now-unused 11x18 glyph slots (72 bytes)
HELPER_END = 0x0800F504
GLYPHS = 0x0800F904   # erased 64-byte code gap, now custom 5x8 font data
GLYPHS_END = 0x0800F944
BASE_GLYPHS = 0x0800F648
DRAW_STRING = 0x08008E48
BACKGROUND = 0x2945  # the v13-tested dark neutral gray
FOREGROUND = 0xC618  # light neutral gray, visually matched to the clock in user photo
CHARGE_FOREGROUND = 0x07E0  # standard full green in RGB565


def decode(path):
    image, upper = bytearray([0xFF]) * 0x10000, 0
    for line in path.read_text().splitlines():
        rec = bytes.fromhex(line[1:])
        n, hi, lo, kind = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 255:
            raise ValueError('invalid Intel HEX record')
        if kind == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif kind == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError('HEX record outside firmware image')
            image[off:off+n] = data
        elif kind == 1:
            break
    return image


def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])


def thumb_bl(address, target):
    delta = target - (address + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError('Thumb BL target out of range/alignment')
    imm = delta & 0x1ffffff
    s, i1, i2 = (imm >> 24) & 1, (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = 1 ^ (i1 ^ s), 1 ^ (i2 ^ s)
    h1 = 0xf000 | (s << 10) | ((imm >> 12) & 0x3ff)
    h2 = 0xd000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7ff)
    return h1.to_bytes(2, 'little') + h2.to_bytes(2, 'little')


def check_bl(image, address, target):
    off = address - FLASH
    h1 = int.from_bytes(image[off:off+2], 'little')
    h2 = int.from_bytes(image[off+2:off+4], 'little')
    if h1 & 0xf800 != 0xf000 or h2 & 0xd000 != 0xd000:
        raise ValueError(f'not Thumb BL at {address:#x}')
    s = (h1 >> 10) & 1
    j1, j2 = (h2 >> 13) & 1, (h2 >> 11) & 1
    i1, i2 = 1 ^ (j1 ^ s), 1 ^ (j2 ^ s)
    imm = (s << 24) | (i1 << 23) | (i2 << 22) | ((h1 & 0x3ff) << 12) | ((h2 & 0x7ff) << 1)
    if s:
        imm -= 1 << 25
    actual = (address + 4 + imm) & 0xfffffffe
    if actual != (target & 0xfffffffe):
        raise ValueError(f'BL {address:#x} targets {actual:#x}, wanted {target:#x}')


def glyph(rows):
    if len(rows) != 10 or any(len(row) != 7 for row in rows):
        raise ValueError('expected 7x10 glyph')
    out = bytearray()
    for row in rows:
        mask = sum((c == '#') << (15-x) for x, c in enumerate(row))
        out.extend(mask.to_bytes(2, 'little'))
    return bytes(out)


def make_helper():
    code = bytearray(); labels = {}; branches = []; literals = []
    def e16(v): code.extend(v.to_bytes(2, 'little'))
    def mark(name): labels[name] = len(code)
    def br(name, cond=False):
        at = len(code); e16(0); branches.append((at, name, cond))
    def ldr(rd, value, key=None):
        at = len(code); e16(0x4800 | rd << 8); literals.append((at, value, key))
    def bl(target): code.extend(thumb_bl(HELPER + len(code), target))

    e16(0xb510)                 # push {r4,lr}
    e16(0xb084)                 # sub sp,#16; keep 8-byte alignment at BL
    e16(0x2809)                 # cmp r0,#9; v3 uses selector 9
    br('charging', True)        # selector 9 is the charging indicator
    ldr(3, FOREGROUND)
    br('color_ready')
    mark('charging')
    ldr(3, CHARGE_FOREGROUND)
    mark('color_ready')
    e16(0x9301)                 # [sp+4] = gray or green foreground
    ldr(2, 0, 'percent')
    e16(0x2003)                 # x=3
    e16(0x2105)                 # y=5
    ldr(3, BASE_GLYPHS)
    e16(0x9300)                 # [sp] = glyph table
    ldr(3, BACKGROUND)
    e16(0x9302)                 # [sp+8] = v13-matched dark gray
    e16(0x230a); e16(0x021b); e16(0x3307) # r3=(10<<8)|7
    bl(DRAW_STRING)
    e16(0xb004)                 # add sp,#16
    e16(0xbd10)                 # pop {r4,pc}

    while (HELPER + len(code)) & 3: code.append(0)
    # Appended glyphs are slots 35/36 -> character codes 0x43/0x44.
    strings = {'percent': bytes([0x31,0x30,0x30,0x43,0])}
    string_addr = {'percent': GLYPHS + 20}
    extra_strings = b''.join(strings.values())
    while (HELPER + len(code)) & 3: code.append(0)
    pool_pos = {}
    for at, value, key in literals:
        pool_pos[(value,key)] = len(code)
        resolved = string_addr[key] if key else value
        code.extend(resolved.to_bytes(4, 'little'))
    for at, value, key in literals:
        pos = pool_pos[(value,key)]
        pc = (HELPER + at + 4) & ~3
        delta = HELPER + pos - pc
        if delta < 0 or delta > 1020 or delta & 3:
            raise ValueError('LDR literal out of range')
        rd = (int.from_bytes(code[at:at+2], 'little') >> 8) & 7
        code[at:at+2] = (0x4800 | rd << 8 | delta//4).to_bytes(2, 'little')
    for at, name, cond in branches:
        delta = labels[name] - (at + 4)
        if delta & 1: raise ValueError('unaligned branch')
        imm = delta // 2
        if cond:
            if not -128 <= imm <= 127: raise ValueError('conditional branch out of range')
            op = 0xd000 | imm
        else:
            if not -1024 <= imm <= 1023: raise ValueError('branch out of range')
            op = 0xe000 | (imm & 0x7ff)
        code[at:at+2] = op.to_bytes(2, 'little')
    if len(code) > HELPER_END - HELPER:
        raise ValueError(f'helper too large: {len(code)} > {HELPER_END-HELPER}')
    return bytes(code), {k:v for k,v in string_addr.items()}, extra_strings


if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
    raise ValueError('v13 source SHA-256 mismatch')
image = decode(SOURCE)
helper_off = HELPER - FLASH; glyph_off = GLYPHS - FLASH
if image[helper_off:HELPER_END-FLASH] != bytes(HELPER_END-HELPER):
    raise ValueError('medium h/µ slots are not cleared as expected')
if image[glyph_off:GLYPHS_END-FLASH] != bytes([0xff])*(GLYPHS_END-GLYPHS):
    raise ValueError('glyph/code gap is not erased')
for addr in (CHARGE_CALL, BATTERY_CALL): check_bl(image, addr, 0x0800AFE4)

# Slot 35 (character code 0x43) in the existing 7x10 table: percent.
font = glyph(['..##...','..##...','....#..','...#...','..#....','.#.....','#......','.##....','.##....','.......'])
image[glyph_off:glyph_off+len(font)] = font
helper, string_addresses, extra_strings = make_helper()
image[helper_off:helper_off+len(helper)] = helper
image[glyph_off+len(font):glyph_off+len(font)+len(extra_strings)] = extra_strings
for addr in (CHARGE_CALL, BATTERY_CALL):
    off=addr-FLASH; image[off:off+4]=thumb_bl(addr, HELPER)

OUT.write_text(encode(image))
check = decode(OUT)
if check != image: raise AssertionError('Intel HEX round-trip mismatch')
for line in OUT.read_text().splitlines():
    if sum(bytes.fromhex(line[1:])) & 255: raise AssertionError('Intel HEX checksum failure')
for addr in (CHARGE_CALL, BATTERY_CALL): check_bl(check, addr, HELPER)
changed=[i for i,(a,b) in enumerate(zip(decode(SOURCE),check)) if a!=b]
allowed=set(range(helper_off,helper_off+len(helper)))|set(range(glyph_off,glyph_off+len(font)+len(extra_strings)))
allowed |= set(range(CHARGE_CALL-FLASH,CHARGE_CALL-FLASH+4))|set(range(BATTERY_CALL-FLASH,BATTERY_CALL-FLASH+4))
if not set(changed) <= allowed: raise AssertionError(f'unexpected changed ranges: {changed[:20]}')
for addr in (CHARGE_CALL, BATTERY_CALL):
    if not set(range(addr-FLASH,addr-FLASH+4)) & set(changed):
        raise AssertionError(f'callsite at {addr:#x} did not change')
print('output:',OUT)
print('changed areas: v2/v3 BLs, appended 7x10 glyphs, compact draw helper')
print('v2 selector 8: gray 100% at x=3,y=5; v3 selector 9: green 100% at x=3,y=5')
print('font background RGB565 0x2945 (v13 tested); foreground gray 0xc618 / charge green 0x07e0; no lightning glyph')
print('helper bytes:',len(helper),'glyph bytes:',len(font))
print('SHA-256:',hashlib.sha256(OUT.read_bytes()).hexdigest())
