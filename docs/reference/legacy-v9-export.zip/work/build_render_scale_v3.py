#!/usr/bin/env python3
"""Per-call 16x27 Medium glyph renderer experiment for main value/time fields."""
from pathlib import Path
import hashlib

FLASH = 0x08000000
SOURCE = Path('work/port-20261005-1751-energy-stats-5x8-v2.hex')
OUT = Path('work/port-20261005-2144-render-scale-v3.hex')
SOURCE_SHA256 = 'caa155761d4a3fa452ce0cb4f992f79e5698d1a38c3cb89c3caab9915f8febd1'
DRAW = 0x08008E48
RASTER = 0x08008D64
# Temporary code/data storage in punctuation slots known not to be used by the
# target numeric strings. Keep mapped time-label letters and numeric glyphs intact.
BOOTSTRAP = 0x0800F0A8           # approved blank space glyph slot
HELPER = 0x0800F180              # apostrophe/quote/parenthesis slots only
HELPER_LIMIT = 0x0800F210
YMAP_ADDR = 0x0800F258           # comma glyph slot
XMAP_ADDR = 0x0800F474           # semicolon glyph slot
YPTR_WORD = 0x0800F484
XPTR_WORD = 0x0800F488
MEDIUM = 0x0800F0A8
MAIN_CALL = 0x08009252
TIME_CALLS = [
    0x0800D158, 0x0800D17E, 0x0800D1A4,
    0x0800D402, 0x0800D426, 0x0800D44C,
    0x0800D6B6, 0x0800D6DA, 0x0800D6FE,
    0x0800D972, 0x0800D996,
    0x0800DC74, 0x0800DD54,
]
CALLS = [MAIN_CALL, *TIME_CALLS]


def decode(path):
    image = bytearray([0xFF]) * 0x10000
    upper = 0
    for line in path.read_text().splitlines():
        if not line.startswith(':'):
            continue
        rec = bytes.fromhex(line[1:])
        n, hi, lo, typ = rec[:4]
        data = rec[4:-1]
        if n != len(data) or sum(rec) & 255:
            raise ValueError('invalid Intel HEX record')
        if typ == 4:
            upper = int.from_bytes(data, 'big') << 16
        elif typ == 0:
            off = upper + (hi << 8) + lo - FLASH
            if off < 0 or off + n > len(image):
                raise ValueError('record outside flash image')
            image[off:off+n] = data
        elif typ == 1:
            break
    return image


def encode(image):
    lines = [':020000040800F2']
    for off in range(0, len(image), 16):
        rec = bytes([16, off >> 8, off & 255, 0]) + image[off:off+16]
        lines.append(':' + (rec + bytes([(-sum(rec)) & 255])).hex().upper())
    return '\n'.join(lines + [':00000001FF', ''])


def thumb_bl(address, target):
    delta = target - (address + 4)
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError('Thumb BL range/alignment')
    imm = delta & 0x1FFFFFF
    s, i1, i2 = (imm >> 24) & 1, (imm >> 23) & 1, (imm >> 22) & 1
    j1, j2 = 1 ^ (i1 ^ s), 1 ^ (i2 ^ s)
    h1 = 0xF000 | (s << 10) | ((imm >> 12) & 0x3FF)
    h2 = 0xD000 | (j1 << 13) | (j2 << 11) | ((imm >> 1) & 0x7FF)
    return h1.to_bytes(2, 'little') + h2.to_bytes(2, 'little')


def bl_target(image, address):
    off = address - FLASH
    h1 = int.from_bytes(image[off:off+2], 'little')
    h2 = int.from_bytes(image[off+2:off+4], 'little')
    if h1 & 0xF800 != 0xF000 or h2 & 0xD000 != 0xD000:
        return None
    s, j1, j2 = (h1 >> 10) & 1, (h2 >> 13) & 1, (h2 >> 11) & 1
    i1, i2 = 1 ^ (j1 ^ s), 1 ^ (j2 ^ s)
    imm = (s << 24) | (i1 << 23) | (i2 << 22) | ((h1 & 1023) << 12) | ((h2 & 2047) << 1)
    if s:
        imm -= 1 << 25
    return (address + 4 + imm) & 0xFFFFFFFE


class Asm:
    def __init__(self, origin):
        self.origin = origin
        self.b = bytearray()
        self.labels = {}
        self.branches = []
        self.literals = []

    @property
    def pc(self): return self.origin + len(self.b)
    def h(self, v): self.b.extend(int(v).to_bytes(2, 'little'))
    def mark(self, n): self.labels[n] = self.pc
    def bto(self, n, cond=None):
        at = self.pc; self.h(0); self.branches.append((at, n, cond))
    def lit(self, rd, n):
        at = self.pc; self.h(0x4800 | (rd << 8)); self.literals.append((at, rd, n))
    def mov(self, d, s): self.h(0x4600 | ((d & 8) << 4) | (s << 3) | (d & 7))
    def mi(self, d, n): self.h(0x2000 | (d << 8) | (n & 255))
    def ci(self, r, n): self.h(0x2800 | (r << 8) | (n & 255))
    def ai(self, r, n): self.h(0x3000 | (r << 8) | (n & 255))
    def si(self, r, n): self.h(0x3800 | (r << 8) | (n & 255))
    def ar(self, d, n, m): self.h(0x1800 | (m << 6) | (n << 3) | d)
    def sh(self, d, n, imm): self.h(0x1E00 | (imm << 6) | (n << 3) | d)
    def lsl(self, d, s, imm): self.h((imm << 6) | (s << 3) | d)
    def alu(self, op, d, s): self.h(0x4000 | (op << 6) | (s << 3) | d)
    def ldsp(self, d, off): self.h(0x9800 | (d << 8) | (off // 4))
    def stsp(self, d, off): self.h(0x9000 | (d << 8) | (off // 4))
    def addsp(self, d, off): self.h(0xA800 | (d << 8) | (off // 4))
    def ldb(self, t, n, off=0): self.h(0x7800 | ((off // 1) << 6) | (n << 3) | t)
    def ldbr(self, t, n, m): self.h(0x5C00 | (m << 6) | (n << 3) | t)
    def ldhr(self, t, n, m): self.h(0x5A00 | (m << 6) | (n << 3) | t)
    def sth(self, t, n, off=0): self.h(0x8000 | ((off // 2) << 6) | (n << 3) | t)
    def push(self, mask, lr=False): self.h(0xB400 | mask | (0x100 if lr else 0))
    def pop(self, mask, pc=False): self.h(0xBC00 | mask | (0x100 if pc else 0))
    def subsp(self, amount): self.h(0xB080 | (amount // 4))
    def addspimm(self, amount): self.h(0xB000 | (amount // 4))

    def finish(self, data):
        if self.pc & 3: self.h(0xBF00)
        data_addr = {}
        for name, raw in data.items():
            data_addr[name] = self.pc
            self.b.extend(raw)
            if len(self.b) & 1: self.b.append(0)
        # The literal words hold the byte-map addresses.
        while self.pc & 3: self.h(0xBF00)
        word_addr = {}
        for name in data:
            word_addr[name] = self.pc
            self.b.extend(data_addr[name].to_bytes(4, 'little'))
        for at, name, cond in self.branches:
            d = self.labels[name] - (at + 4)
            if d & 1: raise ValueError('branch alignment')
            q = d // 2
            if cond is None:
                if not -1024 <= q <= 1023: raise ValueError('B range')
                op = 0xE000 | (q & 2047)
            else:
                if not -128 <= q <= 127: raise ValueError('Bcond range')
                op = 0xD000 | (cond << 8) | (q & 255)
            o = at - self.origin; self.b[o:o+2] = op.to_bytes(2, 'little')
        for at, rd, name in self.literals:
            base = (at + 4) & ~3; d = word_addr[name] - base
            if d < 0 or d & 3 or d > 1020: raise ValueError('literal range')
            o = at - self.origin; self.b[o:o+2] = (0x4800 | (rd << 8) | (d // 4)).to_bytes(2, 'little')
        return bytes(self.b)


def make_helper():
    a = Asm(HELPER)
    # r4=x, r5=y, r6=text; stack frame stays 8-byte aligned.
    a.push(0xF8, lr=True)               # r3-r7,lr
    a.subsp(88)
    a.b.extend(thumb_bl(a.pc, BOOTSTRAP))
    a.mark('char')
    a.ldb(2, 6)
    a.ci(2, 0); a.bto('done', 0)
    # Glyph base = table + (code-0x20)*36.
    a.mov(0, 2); a.si(0, 32); a.lsl(0, 0, 5)
    a.mov(1, 2); a.si(1, 32); a.lsl(1, 1, 2)
    a.ar(0, 0, 1); a.ldsp(7, 80); a.ar(0, 0, 7); a.stsp(0, 72)
    a.mi(0, 0); a.stsp(0, 76)          # destination row
    a.mark('row')
    a.ldsp(0, 76); a.lit(1, 'ymap')
    a.ldbr(1, 1, 0)
    a.ldsp(2, 72); a.ar(2, 2, 1); a.mi(0, 0); a.ldhr(7, 2, 0)
    a.mi(1, 0); a.mi(3, 0)             # x=0, output bits=0
    a.mark('x')
    a.ci(1, 16); a.bto('store_row', 10) # BGE
    a.lit(2, 'xmap'); a.ldbr(2, 2, 1)
    a.mi(0, 1); a.lsl(0, 0, 10); a.alu(3, 0, 2) # LSR 11-bit source mask (bit 10 is x=0)
    a.alu(8, 7, 0); a.bto('x_next', 0)  # TST / BEQ
    a.mi(0, 1); a.lsl(0, 0, 15); a.alu(3, 0, 1); a.alu(12, 3, 0)
    a.mark('x_next')
    a.ai(1, 1); a.bto('x')
    a.mark('store_row')
    a.addsp(0, 16); a.ldsp(1, 76); a.lsl(1, 1, 1); a.ar(0, 0, 1); a.sth(3, 0)
    a.ldsp(0, 76); a.ai(0, 1); a.stsp(0, 76)
    a.ci(0, 27); a.bto('row', 11)       # BLT
    # Rasterize temporary 16x27 glyph at current x/y.
    a.addsp(0, 16); a.stsp(0, 0)
    a.ldsp(0, 4); a.stsp(0, 4); a.ldsp(0, 8); a.stsp(0, 8)
    a.mov(0, 4); a.mov(1, 5); a.mi(2, 32)
    a.mi(3, 27); a.lsl(3, 3, 8); a.ai(3, 16) # packed width=16,height=27
    a.b.extend(thumb_bl(a.pc, RASTER))
    a.ai(4, 16); a.ai(6, 1); a.bto('char')
    a.mark('done')
    a.addspimm(88); a.pop(0xF8, pc=True)

    ymap = bytes(2 * ((y * 18) // 27) for y in range(27))
    xmap = bytes((x * 11) // 16 for x in range(16))
    full = a.finish({'ymap': ymap, 'xmap': xmap})
    marker = full.find(bytes.fromhex('16 B0 F8 BD'))
    if marker < 0:
        raise ValueError('renderer return sequence not found')
    code_end = marker + 4
    code = bytearray(full[:code_end])
    if code_end > HELPER_LIMIT - HELPER:
        raise ValueError(f'instruction body ({code_end} bytes) exceeds its code slots')
    # Place the mapping arrays and two pointer words in unused punctuation slots.
    # Split lookup maps across the user's approved comma and semicolon glyph slots.
    map_bytes = (ymap, xmap)
    bootstrap = Asm(BOOTSTRAP)
    bootstrap.mov(4, 0); bootstrap.mov(5, 1); bootstrap.mov(6, 2)
    bootstrap.ldsp(7, 112); bootstrap.stsp(7, 80)
    bootstrap.ldsp(0, 116); bootstrap.stsp(0, 4)
    bootstrap.ldsp(0, 120); bootstrap.stsp(0, 8)
    bootstrap.h(0x4770)                 # BX LR
    # Repoint the two LDR-literal instructions to the pointer words above.
    found = set()
    for off in range(0, code_end, 2):
        h = int.from_bytes(code[off:off+2], 'little')
        if h & 0xF800 != 0x4800:
            continue
        rd = (h >> 8) & 7
        name = 'ymap' if rd == 1 else 'xmap' if rd == 2 else None
        if name is None:
            continue
        at = HELPER + off
        target = YPTR_WORD if name == 'ymap' else XPTR_WORD
        delta = target - ((at + 4) & ~3)
        if delta < 0 or delta & 3 or delta > 1020:
            raise ValueError(f'literal target out of range: {name}')
        code[off:off+2] = (0x4800 | (rd << 8) | (delta // 4)).to_bytes(2, 'little')
        found.add(name)
    if found != {'ymap', 'xmap'}:
        raise ValueError(f'expected two map literals, found {found}')
    return bytes(code), map_bytes, bootstrap.b


def main():
    if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA256:
        raise ValueError('accepted base SHA mismatch')
    image = decode(SOURCE)
    original = bytes(image)
    helper, maps, bootstrap = make_helper()
    if HELPER + len(helper) > HELPER_LIMIT:
        raise ValueError(f'helper ({len(helper)} bytes) exceeds its code slots')
    for call in CALLS:
        if bl_target(image, call) != DRAW:
            raise ValueError(f'unexpected draw target at {call:#x}')
    # Store code/maps only in explicitly approved glyph slots; '+' and '-' remain intact.
    image[BOOTSTRAP-FLASH:BOOTSTRAP-FLASH+len(bootstrap)] = bootstrap
    image[HELPER-FLASH:HELPER-FLASH+len(helper)] = helper
    image[YMAP_ADDR-FLASH:YMAP_ADDR-FLASH+len(maps[0])] = maps[0]
    image[XMAP_ADDR-FLASH:XMAP_ADDR-FLASH+len(maps[1])] = maps[1]
    image[YPTR_WORD-FLASH:YPTR_WORD-FLASH+4] = YMAP_ADDR.to_bytes(4, 'little')
    image[XPTR_WORD-FLASH:XPTR_WORD-FLASH+4] = XMAP_ADDR.to_bytes(4, 'little')
    for call in CALLS:
        image[call-FLASH:call-FLASH+4] = thumb_bl(call, HELPER)
    OUT.write_text(encode(image))
    check = decode(OUT)
    assert check == image
    for line in OUT.read_text().splitlines():
        assert sum(bytes.fromhex(line[1:])) & 255 == 0
    changed = {i for i, (x, y) in enumerate(zip(original, check)) if x != y}
    allowed = set(range(BOOTSTRAP-FLASH, BOOTSTRAP-FLASH+len(bootstrap)))
    allowed.update(range(HELPER-FLASH, HELPER-FLASH+len(helper)))
    allowed.update(range(YMAP_ADDR-FLASH, YMAP_ADDR-FLASH+len(maps[0])))
    allowed.update(range(XMAP_ADDR-FLASH, XMAP_ADDR-FLASH+len(maps[1])))
    allowed.update(range(YPTR_WORD-FLASH, YPTR_WORD-FLASH+4))
    allowed.update(range(XPTR_WORD-FLASH, XPTR_WORD-FLASH+4))
    for call in CALLS: allowed.update(range(call-FLASH, call-FLASH+4))
    assert changed <= allowed
    assert all(bl_target(check, call) == HELPER for call in CALLS)
    # Numeric glyphs, plus/minus, period/colon, and letters remain byte-identical.
    for code in [0x21, 0x22, 0x23, 0x24, 0x25, 0x2B, 0x2D, *range(0x2E, 0x3B), *range(0x3C, 0x48)]:
        off = MEDIUM-FLASH + (code-0x20)*36
        assert check[off:off+36] == original[off:off+36]
    assert check[0x0800FCF8-FLASH:0x0800FD18-FLASH] == original[0x0800FCF8-FLASH:0x0800FD18-FLASH]
    print('output:', OUT)
    print('helper bytes:', len(helper), 'bootstrap bytes:', len(bootstrap))
    print('redirected main/time draw calls:', len(CALLS))
    print('changed bytes:', len(changed))
    print('sha256:', hashlib.sha256(OUT.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
